-- HealthGuard Database Initial Migration
-- This creates all the necessary tables and indexes for the health monitoring system

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create custom types/enums
CREATE TYPE gender_type AS ENUM ('male', 'female', 'other', 'prefer_not_to_say');
CREATE TYPE device_type AS ENUM ('google_fit', 'web_bluetooth', 'simulated');
CREATE TYPE vital_type AS ENUM ('heart_rate', 'blood_pressure', 'spO2', 'sleep');
CREATE TYPE emergency_action AS ENUM ('call_ambulance', 'go_er', 'see_gp', 'self_care', 'follow_up');

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    email_verified BOOLEAN DEFAULT FALSE,
    email_verification_code TEXT,
    email_verification_expires TIMESTAMP WITH TIME ZONE,
    phone TEXT,
    phone_verified BOOLEAN DEFAULT FALSE,
    phone_verification_code TEXT,
    phone_verification_expires TIMESTAMP WITH TIME ZONE,
    refresh_token TEXT,
    last_login TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User profiles table
CREATE TABLE user_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    preferred_name TEXT,
    gender gender_type,
    date_of_birth TIMESTAMP WITH TIME ZONE,
    height_cm DECIMAL(5,2),
    weight_kg DECIMAL(5,2),
    allergies JSONB DEFAULT '[]'::jsonb,
    medical_history JSONB DEFAULT '{"conditions": [], "notes": ""}'::jsonb,
    medications JSONB DEFAULT '[]'::jsonb,
    emergency_contacts JSONB DEFAULT '[]'::jsonb,
    consent JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT fk_user_profiles_user_id FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Devices table
CREATE TABLE devices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_type device_type NOT NULL,
    device_id TEXT NOT NULL,
    device_name TEXT,
    last_seen TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT TRUE,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT fk_devices_user_id FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Vitals table
CREATE TABLE vitals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_id UUID REFERENCES devices(id),
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    vital_type vital_type NOT NULL,
    value JSONB NOT NULL,
    source device_type NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT fk_vitals_user_id FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_vitals_device_id FOREIGN KEY (device_id) REFERENCES devices(id)
);

-- AI Events table
CREATE TABLE ai_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    vitals_snapshot JSONB NOT NULL,
    medical_history JSONB,
    symptoms TEXT,
    ai_output JSONB NOT NULL,
    ai_model TEXT DEFAULT 'gemini-2.5-flash',
    processing_time_ms INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT fk_ai_events_user_id FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Emergency Events table
CREATE TABLE emergency_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    ai_event_id UUID REFERENCES ai_events(id),
    trigger_type TEXT NOT NULL CHECK (trigger_type IN ('ai', 'manual')),
    actions_taken JSONB NOT NULL,
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT fk_emergency_events_user_id FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_emergency_events_ai_event_id FOREIGN KEY (ai_event_id) REFERENCES ai_events(id)
);

-- Email logs table
CREATE TABLE email_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    to_email TEXT NOT NULL,
    subject TEXT NOT NULL,
    template TEXT,
    status TEXT NOT NULL CHECK (status IN ('sent', 'failed', 'pending')),
    provider TEXT DEFAULT 'sendgrid',
    provider_id TEXT,
    error TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT fk_email_logs_user_id FOREIGN KEY (user_id) REFERENCES users(id)
);

-- SMS logs table
CREATE TABLE sms_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    to_phone TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('sent', 'failed', 'pending')),
    provider TEXT DEFAULT 'twilio',
    provider_id TEXT,
    error TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT fk_sms_logs_user_id FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Audit logs table
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    action TEXT NOT NULL,
    resource_type TEXT,
    resource_id TEXT,
    old_values JSONB,
    new_values JSONB,
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT fk_audit_logs_user_id FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Session store table (for connect-pg-simple)
CREATE TABLE session (
    sid VARCHAR NOT NULL COLLATE "default",
    sess JSON NOT NULL,
    expire TIMESTAMP(6) NOT NULL,
    PRIMARY KEY (sid)
);

-- Create indexes for performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_email_verified ON users(email_verified);
CREATE INDEX idx_users_phone_verified ON users(phone_verified);

CREATE UNIQUE INDEX idx_user_profiles_user_id ON user_profiles(user_id);

CREATE INDEX idx_devices_user_id ON devices(user_id);
CREATE INDEX idx_devices_type ON devices(device_type);
CREATE INDEX idx_devices_active ON devices(is_active);
CREATE UNIQUE INDEX idx_devices_user_device ON devices(user_id, device_type, device_id);

CREATE INDEX idx_vitals_user_id ON vitals(user_id);
CREATE INDEX idx_vitals_timestamp ON vitals(timestamp DESC);
CREATE INDEX idx_vitals_type ON vitals(vital_type);
CREATE INDEX idx_vitals_user_type_timestamp ON vitals(user_id, vital_type, timestamp DESC);
CREATE INDEX idx_vitals_source ON vitals(source);

CREATE INDEX idx_ai_events_user_id ON ai_events(user_id);
CREATE INDEX idx_ai_events_created_at ON ai_events(created_at DESC);

CREATE INDEX idx_emergency_events_user_id ON emergency_events(user_id);
CREATE INDEX idx_emergency_events_created_at ON emergency_events(created_at DESC);
CREATE INDEX idx_emergency_events_resolved ON emergency_events(resolved);

CREATE INDEX idx_email_logs_user_id ON email_logs(user_id);
CREATE INDEX idx_email_logs_created_at ON email_logs(created_at DESC);
CREATE INDEX idx_email_logs_status ON email_logs(status);

CREATE INDEX idx_sms_logs_user_id ON sms_logs(user_id);
CREATE INDEX idx_sms_logs_created_at ON sms_logs(created_at DESC);
CREATE INDEX idx_sms_logs_status ON sms_logs(status);

CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at DESC);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);

CREATE INDEX idx_session_expire ON session(expire);

-- Add triggers for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON user_profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Add constraints for data validation
ALTER TABLE user_profiles ADD CONSTRAINT check_height_positive 
    CHECK (height_cm IS NULL OR height_cm > 0);

ALTER TABLE user_profiles ADD CONSTRAINT check_weight_positive 
    CHECK (weight_kg IS NULL OR weight_kg > 0);

ALTER TABLE vitals ADD CONSTRAINT check_timestamp_not_future 
    CHECK (timestamp <= NOW() + INTERVAL '1 hour');

-- Add partial indexes for performance
CREATE INDEX idx_vitals_recent ON vitals(user_id, timestamp DESC) 
    WHERE timestamp > NOW() - INTERVAL '30 days';

CREATE INDEX idx_ai_events_recent ON ai_events(user_id, created_at DESC) 
    WHERE created_at > NOW() - INTERVAL '90 days';

-- Add GIN indexes for JSONB columns
CREATE INDEX idx_user_profiles_allergies ON user_profiles USING GIN (allergies);
CREATE INDEX idx_user_profiles_medical_history ON user_profiles USING GIN (medical_history);
CREATE INDEX idx_user_profiles_medications ON user_profiles USING GIN (medications);
CREATE INDEX idx_user_profiles_emergency_contacts ON user_profiles USING GIN (emergency_contacts);
CREATE INDEX idx_user_profiles_consent ON user_profiles USING GIN (consent);

CREATE INDEX idx_devices_metadata ON devices USING GIN (metadata);
CREATE INDEX idx_vitals_value ON vitals USING GIN (value);
CREATE INDEX idx_ai_events_vitals_snapshot ON ai_events USING GIN (vitals_snapshot);
CREATE INDEX idx_ai_events_ai_output ON ai_events USING GIN (ai_output);
CREATE INDEX idx_emergency_events_actions_taken ON emergency_events USING GIN (actions_taken);

-- Create views for common queries
CREATE VIEW user_latest_vitals AS
SELECT DISTINCT ON (v.user_id, v.vital_type) 
    v.user_id,
    v.vital_type,
    v.value,
    v.timestamp,
    v.source,
    d.device_name
FROM vitals v
LEFT JOIN devices d ON v.device_id = d.id
ORDER BY v.user_id, v.vital_type, v.timestamp DESC;

CREATE VIEW user_emergency_summary AS
SELECT 
    u.id as user_id,
    u.email,
    up.full_name,
    up.emergency_contacts,
    COUNT(ee.id) as total_emergencies,
    MAX(ee.created_at) as last_emergency
FROM users u
LEFT JOIN user_profiles up ON u.id = up.user_id
LEFT JOIN emergency_events ee ON u.id = ee.user_id
GROUP BY u.id, u.email, up.full_name, up.emergency_contacts;

-- Insert default data for development
INSERT INTO users (email, password_hash, email_verified) VALUES
('demo@healthguard.app', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4aHzm1OJX6', true);

-- Sample user profile for demo
INSERT INTO user_profiles (
    user_id, 
    full_name, 
    preferred_name, 
    gender, 
    height_cm, 
    weight_kg,
    emergency_contacts,
    consent
) 
SELECT 
    id,
    'Demo User',
    'Demo',
    'other',
    175.0,
    70.0,
    '[{"name": "Emergency Contact", "relationship": "Friend", "phone": "+1234567890", "email": "emergency@example.com"}]'::jsonb,
    '{"healthDataCollection": {"granted": true, "timestamp": "2024-01-01T00:00:00Z"}, "locationSharing": {"granted": true, "timestamp": "2024-01-01T00:00:00Z"}, "emergencyContactNotification": {"granted": true, "timestamp": "2024-01-01T00:00:00Z"}}'::jsonb
FROM users 
WHERE email = 'demo@healthguard.app';

-- Create a sample simulated device
INSERT INTO devices (user_id, device_type, device_id, device_name, metadata)
SELECT 
    u.id,
    'simulated',
    'demo-simulator-001',
    'Demo Health Simulator',
    '{"manufacturer": "HealthGuard", "model": "Simulator v1.0", "capabilities": ["heart_rate", "blood_pressure", "spO2"]}'::jsonb
FROM users u
WHERE u.email = 'demo@healthguard.app';

-- Add comments for documentation
COMMENT ON TABLE users IS 'Core user authentication and account information';
COMMENT ON TABLE user_profiles IS 'Extended user profile with medical information';
COMMENT ON TABLE devices IS 'Registered health monitoring devices';
COMMENT ON TABLE vitals IS 'Time-series vital signs data';
COMMENT ON TABLE ai_events IS 'AI health analysis events and results';
COMMENT ON TABLE emergency_events IS 'Emergency response events and actions taken';
COMMENT ON TABLE email_logs IS 'Email delivery logs for audit and debugging';
COMMENT ON TABLE sms_logs IS 'SMS delivery logs for audit and debugging';
COMMENT ON TABLE audit_logs IS 'System audit trail for security and compliance';

COMMENT ON COLUMN users.email_verification_code IS '6-digit email verification code';
COMMENT ON COLUMN users.phone_verification_code IS '4-digit SMS verification code';
COMMENT ON COLUMN user_profiles.consent IS 'User consent tracking with timestamps';
COMMENT ON COLUMN vitals.value IS 'JSONB containing vital sign measurements';
COMMENT ON COLUMN ai_events.ai_output IS 'Structured AI analysis results';
COMMENT ON COLUMN emergency_events.actions_taken IS 'Detailed log of emergency actions performed';

-- Grant permissions for application user
-- Note: In production, create a specific application user with limited permissions
GRANT USAGE ON SCHEMA public TO healthguard;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO healthguard;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO healthguard;

-- Final verification
SELECT 
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes 
WHERE schemaname = 'public' 
ORDER BY tablename, indexname;

-- Show table sizes for monitoring
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;

COMMIT;

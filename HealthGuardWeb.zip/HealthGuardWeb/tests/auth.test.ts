import { describe, it, expect, beforeAll, afterAll, beforeEach } from '@jest/globals';
import request from 'supertest';
import { app } from '../server/index';
import { storage } from '../server/storage';

describe('Authentication Endpoints', () => {
  let server: any;
  let agent: request.SuperAgentTest;

  beforeAll(async () => {
    // Setup test server
    server = app.listen(0);
    agent = request.agent(server);
  });

  afterAll(async () => {
    await server.close();
  });

  beforeEach(async () => {
    // Clean up test data before each test
    // Note: In a real test environment, you'd use a separate test database
  });

  describe('POST /api/register', () => {
    it('should register a new user successfully', async () => {
      const userData = {
        email: 'test@healthguard.app',
        password: 'testpassword123',
      };

      const response = await agent
        .post('/api/register')
        .send(userData)
        .expect(201);

      expect(response.body).toHaveProperty('id');
      expect(response.body).toHaveProperty('email', userData.email);
      expect(response.body).toHaveProperty('emailVerified', false);
      expect(response.body).not.toHaveProperty('passwordHash');
    });

    it('should reject registration with invalid email', async () => {
      const userData = {
        email: 'invalid-email',
        password: 'testpassword123',
      };

      await agent
        .post('/api/register')
        .send(userData)
        .expect(400);
    });

    it('should reject registration with weak password', async () => {
      const userData = {
        email: 'test2@healthguard.app',
        password: '123',
      };

      await agent
        .post('/api/register')
        .send(userData)
        .expect(400);
    });

    it('should reject duplicate email registration', async () => {
      const userData = {
        email: 'duplicate@healthguard.app',
        password: 'testpassword123',
      };

      // First registration
      await agent
        .post('/api/register')
        .send(userData)
        .expect(201);

      // Second registration with same email
      await agent
        .post('/api/register')
        .send(userData)
        .expect(400);
    });
  });

  describe('POST /api/login', () => {
    beforeEach(async () => {
      // Create a test user for login tests
      await agent
        .post('/api/register')
        .send({
          email: 'login-test@healthguard.app',
          password: 'testpassword123',
        });
    });

    it('should login successfully with correct credentials', async () => {
      const response = await agent
        .post('/api/login')
        .send({
          username: 'login-test@healthguard.app',
          password: 'testpassword123',
        })
        .expect(200);

      expect(response.body).toHaveProperty('id');
      expect(response.body).toHaveProperty('email', 'login-test@healthguard.app');
    });

    it('should reject login with incorrect password', async () => {
      await agent
        .post('/api/login')
        .send({
          username: 'login-test@healthguard.app',
          password: 'wrongpassword',
        })
        .expect(401);
    });

    it('should reject login with non-existent user', async () => {
      await agent
        .post('/api/login')
        .send({
          username: 'nonexistent@healthguard.app',
          password: 'testpassword123',
        })
        .expect(401);
    });
  });

  describe('GET /api/user', () => {
    it('should return user info when authenticated', async () => {
      // Register and login
      await agent
        .post('/api/register')
        .send({
          email: 'user-info@healthguard.app',
          password: 'testpassword123',
        });

      await agent
        .post('/api/login')
        .send({
          username: 'user-info@healthguard.app',
          password: 'testpassword123',
        });

      const response = await agent
        .get('/api/user')
        .expect(200);

      expect(response.body).toHaveProperty('email', 'user-info@healthguard.app');
      expect(response.body).toHaveProperty('emailVerified', false);
    });

    it('should return 401 when not authenticated', async () => {
      await request(server)
        .get('/api/user')
        .expect(401);
    });
  });

  describe('POST /api/logout', () => {
    it('should logout successfully', async () => {
      // Register and login first
      await agent
        .post('/api/register')
        .send({
          email: 'logout-test@healthguard.app',
          password: 'testpassword123',
        });

      await agent
        .post('/api/login')
        .send({
          username: 'logout-test@healthguard.app',
          password: 'testpassword123',
        });

      // Verify we're logged in
      await agent
        .get('/api/user')
        .expect(200);

      // Logout
      await agent
        .post('/api/logout')
        .expect(200);

      // Verify we're logged out
      await agent
        .get('/api/user')
        .expect(401);
    });
  });

  describe('Email Verification', () => {
    let userId: string;

    beforeEach(async () => {
      const response = await agent
        .post('/api/register')
        .send({
          email: 'verify-test@healthguard.app',
          password: 'testpassword123',
        });
      userId = response.body.id;
    });

    it('should send verification code', async () => {
      await agent
        .post('/api/resend-verification')
        .expect(200);
    });

    it('should verify email with correct code', async () => {
      // In a real test, you'd need to mock the email service or use a test code
      // For now, we'll test the endpoint structure
      const response = await agent
        .post('/api/verify-email')
        .send({ code: '123456' });

      // Expect either success (if we had a real verification code) or failure
      expect([200, 400]).toContain(response.status);
    });

    it('should reject invalid verification code format', async () => {
      await agent
        .post('/api/verify-email')
        .send({ code: '123' }) // Too short
        .expect(400);

      await agent
        .post('/api/verify-email')
        .send({ code: 'abcdef' }) // Non-numeric
        .expect(400);
    });
  });

  describe('Phone Verification', () => {
    beforeEach(async () => {
      await agent
        .post('/api/register')
        .send({
          email: 'phone-test@healthguard.app',
          password: 'testpassword123',
        });

      await agent
        .post('/api/login')
        .send({
          username: 'phone-test@healthguard.app',
          password: 'testpassword123',
        });
    });

    it('should initiate phone verification', async () => {
      const response = await agent
        .post('/api/verify-phone')
        .send({ phone: '+1234567890' });

      // Should succeed even in test mode
      expect([200, 400]).toContain(response.status);
    });

    it('should reject invalid phone format', async () => {
      await agent
        .post('/api/verify-phone')
        .send({ phone: 'invalid-phone' })
        .expect(400);
    });

    it('should confirm phone with correct code format', async () => {
      // First initiate verification
      await agent
        .post('/api/verify-phone')
        .send({ phone: '+1234567890' });

      const response = await agent
        .post('/api/confirm-phone')
        .send({ code: '1234' });

      // Expect either success or failure based on code validity
      expect([200, 400]).toContain(response.status);
    });

    it('should reject invalid phone confirmation code format', async () => {
      await agent
        .post('/api/confirm-phone')
        .send({ code: '123' }) // Too short
        .expect(400);

      await agent
        .post('/api/confirm-phone')
        .send({ code: 'abcd' }) // Non-numeric
        .expect(400);
    });
  });

  describe('Session Management', () => {
    it('should maintain session across requests', async () => {
      // Register user
      await agent
        .post('/api/register')
        .send({
          email: 'session-test@healthguard.app',
          password: 'testpassword123',
        });

      // Login
      await agent
        .post('/api/login')
        .send({
          username: 'session-test@healthguard.app',
          password: 'testpassword123',
        });

      // Multiple requests should work with same session
      await agent.get('/api/user').expect(200);
      await agent.get('/api/user').expect(200);
      await agent.get('/api/user').expect(200);
    });

    it('should handle concurrent sessions properly', async () => {
      const agent1 = request.agent(server);
      const agent2 = request.agent(server);

      // Register two users
      await agent1
        .post('/api/register')
        .send({
          email: 'concurrent1@healthguard.app',
          password: 'testpassword123',
        });

      await agent2
        .post('/api/register')
        .send({
          email: 'concurrent2@healthguard.app',
          password: 'testpassword123',
        });

      // Login both
      await agent1
        .post('/api/login')
        .send({
          username: 'concurrent1@healthguard.app',
          password: 'testpassword123',
        });

      await agent2
        .post('/api/login')
        .send({
          username: 'concurrent2@healthguard.app',
          password: 'testpassword123',
        });

      // Each should get their own user info
      const user1Response = await agent1.get('/api/user').expect(200);
      const user2Response = await agent2.get('/api/user').expect(200);

      expect(user1Response.body.email).toBe('concurrent1@healthguard.app');
      expect(user2Response.body.email).toBe('concurrent2@healthguard.app');
    });
  });

  describe('Security', () => {
    it('should hash passwords securely', async () => {
      const response = await agent
        .post('/api/register')
        .send({
          email: 'security-test@healthguard.app',
          password: 'testpassword123',
        });

      // Password should not be returned in response
      expect(response.body).not.toHaveProperty('password');
      expect(response.body).not.toHaveProperty('passwordHash');

      // Check that password is hashed in database
      const user = await storage.getUserByEmail('security-test@healthguard.app');
      expect(user?.passwordHash).toBeDefined();
      expect(user?.passwordHash).not.toBe('testpassword123');
      expect(user?.passwordHash.length).toBeGreaterThan(20); // bcrypt hashes are long
    });

    it('should rate limit registration attempts', async () => {
      // This would test rate limiting if implemented
      // For now, just ensure multiple rapid requests don't break anything
      const promises = Array.from({ length: 5 }, (_, i) =>
        agent
          .post('/api/register')
          .send({
            email: `ratelimit${i}@healthguard.app`,
            password: 'testpassword123',
          })
      );

      const results = await Promise.allSettled(promises);
      
      // At least some should succeed
      const successful = results.filter(r => r.status === 'fulfilled').length;
      expect(successful).toBeGreaterThan(0);
    });

    it('should sanitize input data', async () => {
      // Test XSS prevention
      const response = await agent
        .post('/api/register')
        .send({
          email: 'xss-test@healthguard.app',
          password: 'testpassword123<script>alert("xss")</script>',
        });

      if (response.status === 201) {
        const user = await storage.getUserByEmail('xss-test@healthguard.app');
        // Password should be hashed, not stored as plaintext with script
        expect(user?.passwordHash).not.toContain('<script>');
      }
    });
  });
});

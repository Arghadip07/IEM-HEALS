import { describe, it, expect, beforeAll, afterAll, beforeEach } from '@jest/globals';
import request from 'supertest';
import { app } from '../server/index';
import { storage } from '../server/storage';
import { VitalsPayload } from '@shared/schema';

describe('Vitals Endpoints', () => {
  let server: any;
  let agent: request.SuperAgentTest;
  let userId: string;
  let deviceId: string;

  beforeAll(async () => {
    server = app.listen(0);
    agent = request.agent(server);
  });

  afterAll(async () => {
    await server.close();
  });

  beforeEach(async () => {
    // Create authenticated user for each test
    const registerResponse = await agent
      .post('/api/register')
      .send({
        email: `vitals-test-${Date.now()}@healthguard.app`,
        password: 'testpassword123',
      });

    userId = registerResponse.body.id;

    await agent
      .post('/api/login')
      .send({
        username: registerResponse.body.email,
        password: 'testpassword123',
      });

    // Create a test device
    const deviceResponse = await agent
      .post('/api/devices')
      .send({
        deviceType: 'simulated',
        deviceId: `test-device-${Date.now()}`,
        deviceName: 'Test Device',
      });

    deviceId = deviceResponse.body.id;
  });

  describe('POST /api/vitals', () => {
    it('should submit heart rate vitals successfully', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            heartRate: 72,
          },
          source: 'simulated' as const,
        }],
      };

      const response = await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);

      expect(response.body).toHaveLength(1);
      expect(response.body[0]).toHaveProperty('id');
      expect(response.body[0]).toHaveProperty('vitalType', 'heart_rate');
      expect(response.body[0].value).toHaveProperty('heartRate', 72);
    });

    it('should submit blood pressure vitals successfully', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            bloodPressure: {
              systolic: 120,
              diastolic: 80,
            },
          },
          source: 'simulated' as const,
        }],
      };

      const response = await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);

      expect(response.body[0]).toHaveProperty('vitalType', 'blood_pressure');
      expect(response.body[0].value.bloodPressure).toEqual({
        systolic: 120,
        diastolic: 80,
      });
    });

    it('should submit SpO2 vitals successfully', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            spO2: 98,
          },
          source: 'webbluetooth' as const,
        }],
      };

      const response = await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);

      expect(response.body[0]).toHaveProperty('vitalType', 'spO2');
      expect(response.body[0].value).toHaveProperty('spO2', 98);
      expect(response.body[0]).toHaveProperty('source', 'webbluetooth');
    });

    it('should submit sleep data successfully', async () => {
      const now = new Date();
      const sleepStart = new Date(now.getTime() - 8 * 60 * 60 * 1000); // 8 hours ago

      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: now.toISOString(),
          vitals: {
            sleep: {
              start: sleepStart.toISOString(),
              end: now.toISOString(),
              stages: {
                deep: 120, // 2 hours in minutes
                light: 240, // 4 hours
                rem: 120, // 2 hours
              },
            },
          },
          source: 'googlefit' as const,
        }],
      };

      const response = await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);

      expect(response.body[0]).toHaveProperty('vitalType', 'sleep');
      expect(response.body[0].value.sleep.stages).toEqual({
        deep: 120,
        light: 240,
        rem: 120,
      });
    });

    it('should submit multiple vitals in one request', async () => {
      const vitalsPayload = {
        vitals: [
          {
            userId,
            deviceId: 'test-device',
            timestamp: new Date().toISOString(),
            vitals: { heartRate: 72 },
            source: 'simulated' as const,
          },
          {
            userId,
            deviceId: 'test-device',
            timestamp: new Date(Date.now() + 1000).toISOString(),
            vitals: { spO2: 98 },
            source: 'simulated' as const,
          },
        ],
      };

      const response = await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);

      expect(response.body).toHaveLength(2);
      expect(response.body[0]).toHaveProperty('vitalType', 'heart_rate');
      expect(response.body[1]).toHaveProperty('vitalType', 'spO2');
    });

    it('should reject invalid vital values', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            heartRate: 500, // Invalid - too high
          },
          source: 'simulated' as const,
        }],
      };

      await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(400);
    });

    it('should reject malformed timestamp', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: 'invalid-timestamp',
          vitals: { heartRate: 72 },
          source: 'simulated' as const,
        }],
      };

      await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(400);
    });

    it('should require authentication', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: { heartRate: 72 },
          source: 'simulated' as const,
        }],
      };

      await request(server)
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(401);
    });
  });

  describe('GET /api/vitals', () => {
    beforeEach(async () => {
      // Create some test vitals
      const testVitals = [
        {
          vitals: [{
            userId,
            deviceId: 'test-device',
            timestamp: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
            vitals: { heartRate: 70 },
            source: 'simulated' as const,
          }],
        },
        {
          vitals: [{
            userId,
            deviceId: 'test-device',
            timestamp: new Date(Date.now() - 1800000).toISOString(), // 30 min ago
            vitals: { heartRate: 75 },
            source: 'simulated' as const,
          }],
        },
        {
          vitals: [{
            userId,
            deviceId: 'test-device',
            timestamp: new Date().toISOString(),
            vitals: { spO2: 98 },
            source: 'simulated' as const,
          }],
        },
      ];

      for (const vital of testVitals) {
        await agent.post('/api/vitals').send(vital);
      }
    });

    it('should retrieve all vitals for user', async () => {
      const response = await agent
        .get('/api/vitals')
        .expect(200);

      expect(response.body).toHaveLength(3);
      expect(response.body.every((v: any) => v.userId === userId)).toBe(true);
    });

    it('should filter vitals by type', async () => {
      const response = await agent
        .get('/api/vitals?type=heart_rate')
        .expect(200);

      expect(response.body).toHaveLength(2);
      expect(response.body.every((v: any) => v.vitalType === 'heart_rate')).toBe(true);
    });

    it('should filter vitals by date range', async () => {
      const from = new Date(Date.now() - 3000000).toISOString(); // 50 min ago
      const to = new Date(Date.now() - 900000).toISOString(); // 15 min ago

      const response = await agent
        .get(`/api/vitals?from=${from}&to=${to}`)
        .expect(200);

      expect(response.body).toHaveLength(1);
      expect(response.body[0].value).toHaveProperty('heartRate', 75);
    });

    it('should return vitals in descending timestamp order', async () => {
      const response = await agent
        .get('/api/vitals')
        .expect(200);

      const timestamps = response.body.map((v: any) => new Date(v.timestamp).getTime());
      const sortedTimestamps = [...timestamps].sort((a, b) => b - a);
      expect(timestamps).toEqual(sortedTimestamps);
    });

    it('should require authentication', async () => {
      await request(server)
        .get('/api/vitals')
        .expect(401);
    });
  });

  describe('GET /api/vitals/latest', () => {
    beforeEach(async () => {
      // Create test vitals with different timestamps
      const testVitals = [
        {
          vitals: [{
            userId,
            deviceId: 'test-device',
            timestamp: new Date(Date.now() - 3600000).toISOString(),
            vitals: { heartRate: 70 },
            source: 'simulated' as const,
          }],
        },
        {
          vitals: [{
            userId,
            deviceId: 'test-device',
            timestamp: new Date().toISOString(),
            vitals: { heartRate: 80 },
            source: 'simulated' as const,
          }],
        },
      ];

      for (const vital of testVitals) {
        await agent.post('/api/vitals').send(vital);
      }
    });

    it('should return latest vital of any type', async () => {
      const response = await agent
        .get('/api/vitals/latest')
        .expect(200);

      expect(response.body).toHaveProperty('value');
      expect(response.body.value).toHaveProperty('heartRate', 80);
    });

    it('should return latest vital of specific type', async () => {
      const response = await agent
        .get('/api/vitals/latest?type=heart_rate')
        .expect(200);

      expect(response.body).toHaveProperty('vitalType', 'heart_rate');
      expect(response.body.value).toHaveProperty('heartRate', 80);
    });

    it('should return 404 when no vitals exist', async () => {
      // Create a new user with no vitals
      const newUserResponse = await agent
        .post('/api/register')
        .send({
          email: `no-vitals-${Date.now()}@healthguard.app`,
          password: 'testpassword123',
        });

      const newAgent = request.agent(server);
      await newAgent
        .post('/api/login')
        .send({
          username: newUserResponse.body.email,
          password: 'testpassword123',
        });

      await newAgent
        .get('/api/vitals/latest')
        .expect(404);
    });

    it('should require authentication', async () => {
      await request(server)
        .get('/api/vitals/latest')
        .expect(401);
    });
  });

  describe('Emergency Detection', () => {
    it('should trigger emergency for critical heart rate', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            heartRate: 200, // Critical high
          },
          source: 'simulated' as const,
        }],
      };

      const response = await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);

      // Emergency should be triggered (tested via WebSocket or emergency endpoint)
      expect(response.body[0].value).toHaveProperty('heartRate', 200);
    });

    it('should trigger emergency for critical SpO2', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            spO2: 80, // Critical low
          },
          source: 'simulated' as const,
        }],
      };

      await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);
    });

    it('should trigger emergency for critical blood pressure', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            bloodPressure: {
              systolic: 70, // Critical low
              diastolic: 40,
            },
          },
          source: 'simulated' as const,
        }],
      };

      await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);
    });
  });

  describe('Data Validation', () => {
    it('should validate heart rate ranges', async () => {
      const invalidVitals = [
        { heartRate: 25 }, // Too low
        { heartRate: 250 }, // Too high
        { heartRate: -10 }, // Negative
        { heartRate: 'invalid' }, // Not a number
      ];

      for (const vitals of invalidVitals) {
        const vitalsPayload = {
          vitals: [{
            userId,
            deviceId: 'test-device',
            timestamp: new Date().toISOString(),
            vitals,
            source: 'simulated' as const,
          }],
        };

        await agent
          .post('/api/vitals')
          .send(vitalsPayload)
          .expect(400);
      }
    });

    it('should validate blood pressure ranges', async () => {
      const invalidVitals = [
        { bloodPressure: { systolic: 50, diastolic: 30 } }, // Too low
        { bloodPressure: { systolic: 350, diastolic: 250 } }, // Too high
        { bloodPressure: { systolic: 120 } }, // Missing diastolic
        { bloodPressure: { diastolic: 80 } }, // Missing systolic
      ];

      for (const vitals of invalidVitals) {
        const vitalsPayload = {
          vitals: [{
            userId,
            deviceId: 'test-device',
            timestamp: new Date().toISOString(),
            vitals,
            source: 'simulated' as const,
          }],
        };

        await agent
          .post('/api/vitals')
          .send(vitalsPayload)
          .expect(400);
      }
    });

    it('should validate SpO2 ranges', async () => {
      const invalidVitals = [
        { spO2: 50 }, // Too low
        { spO2: 105 }, // Too high
        { spO2: -5 }, // Negative
        { spO2: 'invalid' }, // Not a number
      ];

      for (const vitals of invalidVitals) {
        const vitalsPayload = {
          vitals: [{
            userId,
            deviceId: 'test-device',
            timestamp: new Date().toISOString(),
            vitals,
            source: 'simulated' as const,
          }],
        };

        await agent
          .post('/api/vitals')
          .send(vitalsPayload)
          .expect(400);
      }
    });

    it('should validate sleep data structure', async () => {
      const invalidSleepData = [
        {
          sleep: {
            start: 'invalid-date',
            end: new Date().toISOString(),
            stages: { deep: 120, light: 240, rem: 120 },
          },
        },
        {
          sleep: {
            start: new Date().toISOString(),
            end: new Date().toISOString(),
            stages: { deep: -10, light: 240, rem: 120 }, // Negative values
          },
        },
        {
          sleep: {
            start: new Date().toISOString(),
            end: new Date().toISOString(),
            // Missing stages
          },
        },
      ];

      for (const vitals of invalidSleepData) {
        const vitalsPayload = {
          vitals: [{
            userId,
            deviceId: 'test-device',
            timestamp: new Date().toISOString(),
            vitals,
            source: 'simulated' as const,
          }],
        };

        await agent
          .post('/api/vitals')
          .send(vitalsPayload)
          .expect(400);
      }
    });
  });

  describe('Performance and Scale', () => {
    it('should handle large batch vitals submission', async () => {
      const largeVitalsPayload = {
        vitals: Array.from({ length: 100 }, (_, i) => ({
          userId,
          deviceId: 'test-device',
          timestamp: new Date(Date.now() + i * 1000).toISOString(),
          vitals: { heartRate: 70 + (i % 30) },
          source: 'simulated' as const,
        })),
      };

      const startTime = Date.now();
      const response = await agent
        .post('/api/vitals')
        .send(largeVitalsPayload)
        .expect(201);

      const endTime = Date.now();
      const processingTime = endTime - startTime;

      expect(response.body).toHaveLength(100);
      expect(processingTime).toBeLessThan(5000); // Should complete within 5 seconds
    });

    it('should efficiently query large datasets', async () => {
      // First, create a large dataset
      const batchSize = 50;
      for (let batch = 0; batch < 5; batch++) {
        const vitalsPayload = {
          vitals: Array.from({ length: batchSize }, (_, i) => ({
            userId,
            deviceId: 'test-device',
            timestamp: new Date(Date.now() - (batch * batchSize + i) * 60000).toISOString(),
            vitals: { heartRate: 60 + (i % 40) },
            source: 'simulated' as const,
          })),
        };

        await agent.post('/api/vitals').send(vitalsPayload);
      }

      // Now query with various filters
      const startTime = Date.now();
      
      const response = await agent
        .get('/api/vitals?type=heart_rate')
        .expect(200);

      const endTime = Date.now();
      const queryTime = endTime - startTime;

      expect(response.body.length).toBeGreaterThan(200);
      expect(queryTime).toBeLessThan(2000); // Should complete within 2 seconds
    });
  });
});

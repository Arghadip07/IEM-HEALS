import { describe, it, expect, beforeAll, afterAll, beforeEach } from '@jest/globals';
import request from 'supertest';
import { app } from '../server/index';
import { storage } from '../server/storage';
import { triggerEmergencyWorkflow } from '../server/services/emergency';

describe('Emergency Response System', () => {
  let server: any;
  let agent: request.SuperAgentTest;
  let userId: string;
  let userEmail: string;

  beforeAll(async () => {
    server = app.listen(0);
    agent = request.agent(server);
  });

  afterAll(async () => {
    await server.close();
  });

  beforeEach(async () => {
    // Create authenticated user with emergency profile
    userEmail = `emergency-test-${Date.now()}@healthguard.app`;
    const registerResponse = await agent
      .post('/api/register')
      .send({
        email: userEmail,
        password: 'testpassword123',
      });

    userId = registerResponse.body.id;

    await agent
      .post('/api/login')
      .send({
        username: userEmail,
        password: 'testpassword123',
      });

    // Create user profile with emergency contacts and consent
    await agent
      .post('/api/profile')
      .send({
        fullName: 'Emergency Test User',
        emergencyContacts: [
          {
            name: 'Test Emergency Contact',
            relationship: 'Friend',
            phone: '+1234567890',
            email: 'emergency@test.com',
          },
          {
            name: 'Test Family Contact',
            relationship: 'Family',
            phone: '+0987654321',
            email: 'family@test.com',
          },
        ],
        consent: {
          healthDataCollection: {
            granted: true,
            timestamp: new Date().toISOString(),
          },
          locationSharing: {
            granted: true,
            timestamp: new Date().toISOString(),
          },
          emergencyContactNotification: {
            granted: true,
            timestamp: new Date().toISOString(),
          },
        },
      });
  });

  describe('POST /api/emergency/trigger', () => {
    it('should trigger manual emergency successfully', async () => {
      const response = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('emergencyEventId');
      expect(response.body).toHaveProperty('actionsTaken');
      
      const { actionsTaken } = response.body;
      expect(actionsTaken).toHaveProperty('browserAlert');
      expect(actionsTaken).toHaveProperty('emailsSent');
      expect(actionsTaken).toHaveProperty('smsSent');
      expect(actionsTaken).toHaveProperty('hospitalsFound');
      
      expect(actionsTaken.browserAlert.sent).toBe(true);
      expect(actionsTaken.emailsSent).toHaveLength(2); // Two emergency contacts
      expect(actionsTaken.smsSent).toHaveLength(2);
    });

    it('should require authentication', async () => {
      await request(server)
        .post('/api/emergency/trigger')
        .expect(401);
    });

    it('should require emergency contact consent', async () => {
      // Create user without consent
      const noConsentResponse = await agent
        .post('/api/register')
        .send({
          email: `no-consent-${Date.now()}@healthguard.app`,
          password: 'testpassword123',
        });

      const noConsentAgent = request.agent(server);
      await noConsentAgent
        .post('/api/login')
        .send({
          username: noConsentResponse.body.email,
          password: 'testpassword123',
        });

      const response = await noConsentAgent
        .post('/api/emergency/trigger')
        .expect(500);

      expect(response.body).toHaveProperty('message');
      expect(response.body.message).toContain('consent');
    });
  });

  describe('Emergency Detection via Vitals', () => {
    it('should trigger emergency for critical heart rate', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            heartRate: 200, // Critical high
          },
          source: 'simulated' as const,
        }],
      };

      // Submit critical vitals
      await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);

      // Check that emergency was created
      // Note: In a real test, you'd need to check the database or use WebSocket testing
      // For now, we'll verify the vitals were stored
      const latestVitals = await agent
        .get('/api/vitals/latest')
        .expect(200);

      expect(latestVitals.body.value.heartRate).toBe(200);
    });

    it('should trigger emergency for critical SpO2', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            spO2: 80, // Critical low
          },
          source: 'simulated' as const,
        }],
      };

      await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);
    });

    it('should trigger emergency for critical blood pressure', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            bloodPressure: {
              systolic: 70, // Critical low
              diastolic: 40,
            },
          },
          source: 'simulated' as const,
        }],
      };

      await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);
    });

    it('should trigger emergency for combined critical conditions', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            heartRate: 130,
            spO2: 88, // Combined: high HR + low SpO2
          },
          source: 'simulated' as const,
        }],
      };

      await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);
    });

    it('should NOT trigger emergency for normal vitals', async () => {
      const vitalsPayload = {
        vitals: [{
          userId,
          deviceId: 'test-device',
          timestamp: new Date().toISOString(),
          vitals: {
            heartRate: 72,
            bloodPressure: {
              systolic: 120,
              diastolic: 80,
            },
            spO2: 98,
          },
          source: 'simulated' as const,
        }],
      };

      await agent
        .post('/api/vitals')
        .send(vitalsPayload)
        .expect(201);

      // Normal vitals should not trigger emergency
    });
  });

  describe('POST /api/emergency/:eventId/resolve', () => {
    it('should resolve emergency event', async () => {
      // First trigger an emergency
      const triggerResponse = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      const emergencyEventId = triggerResponse.body.emergencyEventId;

      // Then resolve it
      const resolveResponse = await agent
        .post(`/api/emergency/${emergencyEventId}/resolve`)
        .expect(200);

      expect(resolveResponse.body).toHaveProperty('message', 'Emergency resolved');
    });

    it('should reject invalid emergency event ID', async () => {
      const invalidId = '123e4567-e89b-12d3-a456-426614174000'; // Valid UUID format

      await agent
        .post(`/api/emergency/${invalidId}/resolve`)
        .expect(400);
    });

    it('should reject malformed emergency event ID', async () => {
      await agent
        .post('/api/emergency/invalid-id/resolve')
        .expect(400);
    });

    it('should require authentication', async () => {
      await request(server)
        .post('/api/emergency/some-id/resolve')
        .expect(401);
    });
  });

  describe('Emergency Service Integration', () => {
    it('should handle email service failures gracefully', async () => {
      // This would test what happens when SendGrid is down
      // In a real test, you'd mock the email service to fail
      
      const response = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      // Even if email fails, emergency should still be triggered
      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('actionsTaken');
    });

    it('should handle SMS service failures gracefully', async () => {
      // This would test what happens when Twilio is down
      // In a real test, you'd mock the SMS service to fail
      
      const response = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      expect(response.body).toHaveProperty('success', true);
    });

    it('should handle hospital lookup failures gracefully', async () => {
      // This would test what happens when Google Places API is down
      // In a real test, you'd mock the Places API to fail
      
      const response = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      expect(response.body).toHaveProperty('success', true);
    });
  });

  describe('Emergency Data Validation', () => {
    it('should validate emergency contact data', async () => {
      // Create profile with invalid emergency contact data
      await agent
        .post('/api/profile')
        .send({
          fullName: 'Test User',
          emergencyContacts: [
            {
              name: '', // Empty name
              relationship: 'Friend',
              phone: 'invalid-phone',
              email: 'invalid-email',
            },
          ],
          consent: {
            emergencyContactNotification: {
              granted: true,
              timestamp: new Date().toISOString(),
            },
          },
        });

      // Emergency should still trigger but may have issues with notifications
      const response = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      expect(response.body).toHaveProperty('success', true);
    });

    it('should handle missing emergency contacts', async () => {
      // Create profile without emergency contacts
      await agent
        .post('/api/profile')
        .send({
          fullName: 'Test User',
          emergencyContacts: [],
          consent: {
            emergencyContactNotification: {
              granted: true,
              timestamp: new Date().toISOString(),
            },
          },
        });

      const response = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      expect(response.body).toHaveProperty('success', true);
      expect(response.body.actionsTaken.emailsSent).toHaveLength(0);
      expect(response.body.actionsTaken.smsSent).toHaveLength(0);
    });
  });

  describe('Emergency Event Logging', () => {
    it('should create detailed emergency event log', async () => {
      const response = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      const emergencyEventId = response.body.emergencyEventId;
      expect(emergencyEventId).toBeDefined();

      // Verify the emergency event was logged in database
      // Note: In a real test, you'd query the database directly
      expect(response.body.actionsTaken).toHaveProperty('browserAlert');
      expect(response.body.actionsTaken.browserAlert).toHaveProperty('timestamp');
    });

    it('should log emergency resolution', async () => {
      // Trigger emergency
      const triggerResponse = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      const emergencyEventId = triggerResponse.body.emergencyEventId;

      // Resolve emergency
      await agent
        .post(`/api/emergency/${emergencyEventId}/resolve`)
        .expect(200);

      // Verify resolution was logged
      // In a real test, you'd check the database for resolved_at timestamp
    });

    it('should maintain audit trail for emergency events', async () => {
      // Trigger multiple emergencies
      const emergencies = [];
      for (let i = 0; i < 3; i++) {
        const response = await agent
          .post('/api/emergency/trigger')
          .expect(200);
        emergencies.push(response.body.emergencyEventId);
        
        // Wait a bit between emergencies
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      // All emergencies should be tracked
      expect(emergencies).toHaveLength(3);
      expect(emergencies.every(id => typeof id === 'string')).toBe(true);
    });
  });

  describe('Hospital Lookup', () => {
    it('should find nearest hospitals', async () => {
      const response = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      expect(response.body.actionsTaken.hospitalsFound).toBeDefined();
      expect(Array.isArray(response.body.actionsTaken.hospitalsFound)).toBe(true);
      
      if (response.body.actionsTaken.hospitalsFound.length > 0) {
        const hospital = response.body.actionsTaken.hospitalsFound[0];
        expect(hospital).toHaveProperty('name');
        expect(hospital).toHaveProperty('distance');
        expect(hospital).toHaveProperty('address');
      }
    });

    it('should handle location unavailable', async () => {
      // Create profile without location consent
      await agent
        .post('/api/profile')
        .send({
          fullName: 'No Location User',
          emergencyContacts: [
            {
              name: 'Test Contact',
              relationship: 'Friend',
              phone: '+1234567890',
              email: 'test@example.com',
            },
          ],
          consent: {
            healthDataCollection: {
              granted: true,
              timestamp: new Date().toISOString(),
            },
            locationSharing: {
              granted: false, // No location consent
              timestamp: new Date().toISOString(),
            },
            emergencyContactNotification: {
              granted: true,
              timestamp: new Date().toISOString(),
            },
          },
        });

      const response = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      // Should still succeed even without location
      expect(response.body).toHaveProperty('success', true);
    });
  });

  describe('Performance and Reliability', () => {
    it('should handle rapid emergency triggers', async () => {
      // Trigger multiple emergencies rapidly
      const promises = Array.from({ length: 5 }, () =>
        agent.post('/api/emergency/trigger')
      );

      const responses = await Promise.all(promises);
      
      // All should succeed
      responses.forEach(response => {
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('success', true);
      });
    });

    it('should complete emergency workflow within time limit', async () => {
      const startTime = Date.now();
      
      const response = await agent
        .post('/api/emergency/trigger')
        .expect(200);

      const endTime = Date.now();
      const processingTime = endTime - startTime;

      expect(response.body).toHaveProperty('success', true);
      expect(processingTime).toBeLessThan(10000); // Should complete within 10 seconds
    });

    it('should handle concurrent emergency scenarios', async () => {
      // Create multiple users and trigger emergencies concurrently
      const users = [];
      
      for (let i = 0; i < 3; i++) {
        const email = `concurrent-emergency-${i}-${Date.now()}@test.com`;
        const registerResponse = await agent
          .post('/api/register')
          .send({
            email,
            password: 'testpassword123',
          });

        const userAgent = request.agent(server);
        await userAgent
          .post('/api/login')
          .send({
            username: email,
            password: 'testpassword123',
          });

        await userAgent
          .post('/api/profile')
          .send({
            fullName: `User ${i}`,
            emergencyContacts: [{
              name: 'Emergency Contact',
              relationship: 'Friend',
              phone: '+1234567890',
              email: 'emergency@test.com',
            }],
            consent: {
              emergencyContactNotification: {
                granted: true,
                timestamp: new Date().toISOString(),
              },
            },
          });

        users.push(userAgent);
      }

      // Trigger emergencies concurrently
      const emergencyPromises = users.map(userAgent =>
        userAgent.post('/api/emergency/trigger')
      );

      const responses = await Promise.all(emergencyPromises);

      // All should succeed
      responses.forEach(response => {
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('success', true);
      });
    });
  });
});

import { Client } from '@googlemaps/google-maps-services-js';

const client = new Client();

export interface Hospital {
  name: string;
  address: string;
  distance: number; // in miles
  placeId: string;
  rating?: number;
  phone?: string;
  website?: string;
  emergencyServices?: boolean;
}

export interface Location {
  lat: number;
  lng: number;
}

export async function findNearestHospitals(
  location: Location, 
  radius = 25000, // 25km in meters
  maxResults = 5
): Promise<{ success: boolean; hospitals?: Hospital[]; error?: string }> {
  try {
    if (!process.env.GOOGLE_PLACES_API_KEY) {
      console.warn('Google Places API key not found, returning mock data');
      return {
        success: true,
        hospitals: [
          {
            name: 'City General Hospital',
            address: '123 Main St, City, State 12345',
            distance: 2.3,
            placeId: 'mock_place_id_1',
            rating: 4.2,
            phone: '+1 (555) 123-4567',
            emergencyServices: true,
          },
          {
            name: "St. Mary's Medical Center",
            address: '456 Healthcare Blvd, City, State 12345',
            distance: 3.7,
            placeId: 'mock_place_id_2',
            rating: 4.5,
            phone: '+1 (555) 234-5678',
            emergencyServices: true,
          },
          {
            name: 'Regional Emergency Hospital',
            address: '789 Emergency Dr, City, State 12345',
            distance: 4.1,
            placeId: 'mock_place_id_3',
            rating: 4.1,
            phone: '+1 (555) 345-6789',
            emergencyServices: true,
          }
        ]
      };
    }

    const response = await client.placesNearby({
      params: {
        key: process.env.GOOGLE_PLACES_API_KEY,
        location,
        radius,
        type: 'hospital',
        keyword: 'emergency',
      }
    });

    if (!response.data.results || response.data.results.length === 0) {
      return { success: true, hospitals: [] };
    }

    const hospitals: Hospital[] = [];

    for (const place of response.data.results.slice(0, maxResults)) {
      if (!place.geometry?.location || !place.place_id) continue;

      const distance = calculateDistance(
        location.lat,
        location.lng,
        place.geometry.location.lat,
        place.geometry.location.lng
      );

      // Get additional details
      let phone: string | undefined;
      let website: string | undefined;
      let emergencyServices: boolean | undefined;

      try {
        const detailsResponse = await client.placeDetails({
          params: {
            key: process.env.GOOGLE_PLACES_API_KEY!,
            place_id: place.place_id,
            fields: ['formatted_phone_number', 'website', 'types'],
          }
        });

        phone = detailsResponse.data.result.formatted_phone_number;
        website = detailsResponse.data.result.website;
        emergencyServices = detailsResponse.data.result.types?.includes('hospital') || 
                          detailsResponse.data.result.types?.includes('health');
      } catch (detailError) {
        console.warn('Could not fetch place details:', detailError);
      }

      hospitals.push({
        name: place.name || 'Unknown Hospital',
        address: place.vicinity || place.formatted_address || 'Address not available',
        distance,
        placeId: place.place_id,
        rating: place.rating,
        phone,
        website,
        emergencyServices: emergencyServices ?? true, // Assume true for hospitals
      });
    }

    // Sort by distance
    hospitals.sort((a, b) => a.distance - b.distance);

    return { success: true, hospitals };
  } catch (error: any) {
    console.error('Google Places API error:', error);
    return { success: false, error: error.message };
  }
}

function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

export async function getCurrentLocation(): Promise<{ success: boolean; location?: Location; error?: string }> {
  // In a real implementation, this would use IP geolocation or browser location
  // For now, return a default location (e.g., downtown of a major city)
  return {
    success: true,
    location: {
      lat: 40.7128, // New York City
      lng: -74.0060
    }
  };
}

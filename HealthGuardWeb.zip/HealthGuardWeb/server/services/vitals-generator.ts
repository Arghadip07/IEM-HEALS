import { storage } from '../storage';
import { VitalsPayload } from '@shared/schema';
import { WebSocketServer, WebSocket } from 'ws';

interface SimulationConfig {
  userId: string;
  deviceId: string;
  duration: number; // minutes
  interval: number; // seconds between readings
  scenario: 'normal' | 'elevated_risk' | 'immediate_emergency';
  enableRealTime?: boolean;
}

interface VitalRanges {
  heartRate: { min: number; max: number; emergency?: number };
  systolic: { min: number; max: number; emergency?: number };
  diastolic: { min: number; max: number; emergency?: number };
  spO2: { min: number; max: number; emergency?: number };
}

const SCENARIOS: Record<string, VitalRanges> = {
  normal: {
    heartRate: { min: 60, max: 100 },
    systolic: { min: 110, max: 140 },
    diastolic: { min: 70, max: 90 },
    spO2: { min: 95, max: 100 },
  },
  elevated_risk: {
    heartRate: { min: 100, max: 120 },
    systolic: { min: 140, max: 160 },
    diastolic: { min: 90, max: 100 },
    spO2: { min: 90, max: 95 },
  },
  immediate_emergency: {
    heartRate: { min: 150, max: 180, emergency: 200 },
    systolic: { min: 200, max: 250, emergency: 80 },
    diastolic: { min: 120, max: 140, emergency: 50 },
    spO2: { min: 70, max: 85, emergency: 75 },
  },
};

export class VitalsSimulator {
  private config: SimulationConfig;
  private isRunning: boolean = false;
  private intervalId: NodeJS.Timeout | null = null;
  private startTime: Date = new Date();
  private wss?: WebSocketServer;

  constructor(config: SimulationConfig, wss?: WebSocketServer) {
    this.config = config;
    this.wss = wss;
  }

  private getRandomValue(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  private addVariation(value: number, variationPercent: number = 5): number {
    const variation = value * (variationPercent / 100);
    const randomVariation = (Math.random() - 0.5) * 2 * variation;
    return Math.round(value + randomVariation);
  }

  private generateVitals(): VitalsPayload['vitals'] {
    const ranges = SCENARIOS[this.config.scenario];
    const elapsedMinutes = (Date.now() - this.startTime.getTime()) / (1000 * 60);
    
    let vitals: VitalsPayload['vitals'] = {};

    // Generate heart rate with progressive deterioration for emergency scenario
    let heartRate = this.getRandomValue(ranges.heartRate.min, ranges.heartRate.max);
    
    if (this.config.scenario === 'immediate_emergency') {
      // Progressive worsening over time
      const progressionFactor = Math.min(elapsedMinutes / 10, 1); // Worsen over 10 minutes
      if (Math.random() < 0.3 + (progressionFactor * 0.4)) {
        heartRate = ranges.heartRate.emergency || heartRate;
      }
    }
    
    heartRate = this.addVariation(heartRate, 3);
    vitals.heartRate = Math.max(30, Math.min(220, heartRate));

    // Generate blood pressure with emergency scenarios
    let systolic = this.getRandomValue(ranges.systolic.min, ranges.systolic.max);
    let diastolic = this.getRandomValue(ranges.diastolic.min, ranges.diastolic.max);
    
    if (this.config.scenario === 'immediate_emergency' && Math.random() < 0.4) {
      if (Math.random() < 0.5) {
        // Hypertensive crisis
        systolic = ranges.systolic.max + 20;
        diastolic = ranges.diastolic.max + 10;
      } else {
        // Hypotensive shock
        systolic = ranges.systolic.emergency || 80;
        diastolic = ranges.diastolic.emergency || 50;
      }
    }
    
    systolic = this.addVariation(systolic, 4);
    diastolic = this.addVariation(diastolic, 4);
    
    // Ensure diastolic is lower than systolic
    if (diastolic >= systolic) {
      diastolic = systolic - 20;
    }
    
    vitals.bloodPressure = {
      systolic: Math.max(60, Math.min(300, systolic)),
      diastolic: Math.max(40, Math.min(200, diastolic)),
    };

    // Generate SpO2 with critical drops
    let spO2 = this.getRandomValue(ranges.spO2.min, ranges.spO2.max);
    
    if (this.config.scenario === 'immediate_emergency' && Math.random() < 0.25) {
      spO2 = ranges.spO2.emergency || spO2;
    }
    
    spO2 = this.addVariation(spO2, 2);
    vitals.spO2 = Math.max(70, Math.min(100, spO2));

    // Generate sleep data occasionally (simulate overnight readings)
    if (Math.random() < 0.05) { // 5% chance for sleep data
      const sleepQuality = this.config.scenario === 'normal' ? 'good' : 'poor';
      const sleepHours = sleepQuality === 'good' ? 
        this.getRandomValue(7, 9) : 
        this.getRandomValue(3, 6);
      
      const totalMinutes = sleepHours * 60;
      const deepPercent = sleepQuality === 'good' ? 0.25 : 0.15;
      const remPercent = sleepQuality === 'good' ? 0.20 : 0.15;
      
      const deepMinutes = Math.floor(totalMinutes * deepPercent);
      const remMinutes = Math.floor(totalMinutes * remPercent);
      const lightMinutes = totalMinutes - deepMinutes - remMinutes;
      
      const now = new Date();
      const sleepStart = new Date(now.getTime() - (sleepHours * 60 * 60 * 1000));
      
      vitals.sleep = {
        start: sleepStart.toISOString(),
        end: now.toISOString(),
        stages: {
          deep: deepMinutes,
          light: lightMinutes,
          rem: remMinutes,
        },
      };
    }

    return vitals;
  }

  private async sendVitals(vitals: VitalsPayload['vitals']): Promise<void> {
    try {
      // Find or create simulated device
      const devices = await storage.getUserDevices(this.config.userId);
      let device = devices.find(d => d.deviceId === this.config.deviceId);
      
      if (!device) {
        device = await storage.createDevice({
          userId: this.config.userId,
          deviceType: 'simulated',
          deviceId: this.config.deviceId,
          deviceName: `Simulated Device - ${this.config.scenario}`,
          metadata: {
            scenario: this.config.scenario,
            startTime: this.startTime.toISOString(),
          },
        });
      }

      // Determine vital type based on primary measurement
      let vitalType: 'heart_rate' | 'blood_pressure' | 'spO2' | 'sleep' = 'heart_rate';
      if (vitals.sleep) {
        vitalType = 'sleep';
      } else if (vitals.bloodPressure && !vitals.heartRate) {
        vitalType = 'blood_pressure';
      } else if (vitals.spO2 && !vitals.heartRate && !vitals.bloodPressure) {
        vitalType = 'spO2';
      }

      // Store in database
      const storedVital = await storage.createVitals({
        userId: this.config.userId,
        deviceId: device.id,
        timestamp: new Date(),
        vitalType,
        value: vitals,
        source: 'simulated',
      });

      // Send real-time update via WebSocket if enabled
      if (this.config.enableRealTime && this.wss) {
        const message = {
          type: 'vitals_update',
          userId: this.config.userId,
          vitals,
          scenario: this.config.scenario,
          timestamp: new Date().toISOString(),
          vitalId: storedVital.id,
        };

        this.wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(message));
          }
        });
      }

      console.log(`📊 Generated ${this.config.scenario} vitals:`, {
        heartRate: vitals.heartRate,
        bloodPressure: vitals.bloodPressure,
        spO2: vitals.spO2,
        sleep: vitals.sleep ? 'included' : 'none',
        timestamp: new Date().toISOString(),
      });

    } catch (error) {
      console.error('Failed to store simulated vitals:', error);
      throw error;
    }
  }

  public async start(): Promise<void> {
    if (this.isRunning) {
      throw new Error('Simulator is already running');
    }

    // Verify user exists
    const user = await storage.getUser(this.config.userId);
    if (!user) {
      throw new Error(`User ${this.config.userId} not found`);
    }

    this.isRunning = true;
    this.startTime = new Date();
    
    console.log(`🚀 Starting vitals simulation for user ${user.email}:`);
    console.log(`   Scenario: ${this.config.scenario}`);
    console.log(`   Duration: ${this.config.duration} minutes`);
    console.log(`   Interval: ${this.config.interval} seconds`);
    console.log(`   Device ID: ${this.config.deviceId}`);
    console.log(`   Real-time: ${this.config.enableRealTime ? 'enabled' : 'disabled'}`);

    // Send initial reading
    await this.sendVitals(this.generateVitals());

    // Set up recurring readings
    this.intervalId = setInterval(async () => {
      try {
        const elapsedMinutes = (Date.now() - this.startTime.getTime()) / (1000 * 60);
        
        if (elapsedMinutes >= this.config.duration) {
          await this.stop();
          return;
        }

        await this.sendVitals(this.generateVitals());
      } catch (error) {
        console.error('Error generating vitals:', error);
      }
    }, this.config.interval * 1000);
  }

  public async stop(): Promise<void> {
    if (!this.isRunning) {
      return;
    }

    this.isRunning = false;
    
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    console.log('⏹️  Vitals simulation stopped');
    
    // Send final WebSocket message
    if (this.config.enableRealTime && this.wss) {
      const message = {
        type: 'simulation_stopped',
        userId: this.config.userId,
        scenario: this.config.scenario,
        timestamp: new Date().toISOString(),
      };

      this.wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(message));
        }
      });
    }
  }

  public getStatus(): { 
    isRunning: boolean; 
    elapsedMinutes: number; 
    scenario: string;
    remainingMinutes: number;
  } {
    const elapsedMinutes = this.isRunning ? 
      (Date.now() - this.startTime.getTime()) / (1000 * 60) : 0;
    
    return {
      isRunning: this.isRunning,
      elapsedMinutes: Math.round(elapsedMinutes * 100) / 100,
      scenario: this.config.scenario,
      remainingMinutes: Math.max(0, this.config.duration - elapsedMinutes),
    };
  }
}

// Simulation manager for multiple concurrent simulations
export class SimulationManager {
  private simulations: Map<string, VitalsSimulator> = new Map();
  private wss?: WebSocketServer;

  constructor(wss?: WebSocketServer) {
    this.wss = wss;
  }

  public async startSimulation(config: SimulationConfig): Promise<string> {
    const simulationId = `${config.userId}-${Date.now()}`;
    
    if (this.simulations.has(simulationId)) {
      throw new Error('Simulation already exists');
    }

    const simulator = new VitalsSimulator({
      ...config,
      enableRealTime: config.enableRealTime !== false, // Default to true
    }, this.wss);

    await simulator.start();
    this.simulations.set(simulationId, simulator);

    return simulationId;
  }

  public async stopSimulation(simulationId: string): Promise<void> {
    const simulator = this.simulations.get(simulationId);
    if (!simulator) {
      throw new Error('Simulation not found');
    }

    await simulator.stop();
    this.simulations.delete(simulationId);
  }

  public getSimulationStatus(simulationId: string) {
    const simulator = this.simulations.get(simulationId);
    if (!simulator) {
      return null;
    }

    return simulator.getStatus();
  }

  public getAllSimulations(): Record<string, any> {
    const status: Record<string, any> = {};
    
    for (const [id, simulator] of this.simulations.entries()) {
      status[id] = simulator.getStatus();
    }

    return status;
  }

  public async stopAllSimulations(): Promise<void> {
    const promises = Array.from(this.simulations.values()).map(sim => sim.stop());
    await Promise.all(promises);
    this.simulations.clear();
  }
}

// Predefined simulation scenarios for quick testing
export const PRESET_SCENARIOS = {
  // Quick emergency test (2 minutes, critical vitals)
  emergencyDemo: {
    duration: 2,
    interval: 10,
    scenario: 'immediate_emergency' as const,
  },
  
  // Normal health monitoring (10 minutes, stable vitals)
  healthyDemo: {
    duration: 10,
    interval: 30,
    scenario: 'normal' as const,
  },
  
  // Gradual deterioration (15 minutes, worsening vitals)
  deterioratingDemo: {
    duration: 15,
    interval: 20,
    scenario: 'elevated_risk' as const,
  },
  
  // Long-term monitoring (60 minutes, mixed scenarios)
  longTermDemo: {
    duration: 60,
    interval: 60,
    scenario: 'normal' as const,
  },
};

// Utility function to generate batch vitals for historical data
export async function generateHistoricalVitals(
  userId: string,
  days: number = 30,
  pointsPerDay: number = 24
): Promise<void> {
  console.log(`📈 Generating ${days} days of historical vitals for user ${userId}`);
  
  const vitalsToCreate: any[] = [];
  const now = new Date();
  
  // Find or create a simulated device
  const devices = await storage.getUserDevices(userId);
  let device = devices.find(d => d.deviceType === 'simulated');
  
  if (!device) {
    device = await storage.createDevice({
      userId,
      deviceType: 'simulated',
      deviceId: 'historical-generator',
      deviceName: 'Historical Data Generator',
      metadata: { purpose: 'historical_data_generation' },
    });
  }

  for (let day = 0; day < days; day++) {
    const dayScenario = Math.random() < 0.9 ? 'normal' : 'elevated_risk'; // 10% elevated risk
    const ranges = SCENARIOS[dayScenario];
    
    for (let point = 0; point < pointsPerDay; point++) {
      const timestamp = new Date(now.getTime() - (day * 24 * 60 * 60 * 1000) + (point * 60 * 60 * 1000));
      
      // Generate heart rate data
      const heartRate = Math.floor(Math.random() * (ranges.heartRate.max - ranges.heartRate.min + 1)) + ranges.heartRate.min;
      vitalsToCreate.push({
        userId,
        deviceId: device.id,
        timestamp,
        vitalType: 'heart_rate',
        value: { heartRate },
        source: 'simulated',
      });

      // Generate blood pressure data (less frequent)
      if (point % 6 === 0) { // Every 6 hours
        const systolic = Math.floor(Math.random() * (ranges.systolic.max - ranges.systolic.min + 1)) + ranges.systolic.min;
        const diastolic = Math.floor(Math.random() * (ranges.diastolic.max - ranges.diastolic.min + 1)) + ranges.diastolic.min;
        
        vitalsToCreate.push({
          userId,
          deviceId: device.id,
          timestamp: new Date(timestamp.getTime() + 10 * 60 * 1000), // 10 minutes after HR
          vitalType: 'blood_pressure',
          value: { bloodPressure: { systolic, diastolic } },
          source: 'simulated',
        });
      }

      // Generate SpO2 data
      if (point % 2 === 0) { // Every 2 hours
        const spO2 = Math.floor(Math.random() * (ranges.spO2.max - ranges.spO2.min + 1)) + ranges.spO2.min;
        vitalsToCreate.push({
          userId,
          deviceId: device.id,
          timestamp: new Date(timestamp.getTime() + 5 * 60 * 1000), // 5 minutes after HR
          vitalType: 'spO2',
          value: { spO2 },
          source: 'simulated',
        });
      }
    }

    // Add sleep data for each day
    const sleepHours = dayScenario === 'normal' ? 7.5 : 5.5;
    const sleepStart = new Date(now.getTime() - (day * 24 * 60 * 60 * 1000) + (22 * 60 * 60 * 1000)); // 10 PM
    const sleepEnd = new Date(sleepStart.getTime() + (sleepHours * 60 * 60 * 1000));
    
    const totalMinutes = sleepHours * 60;
    const deepMinutes = Math.floor(totalMinutes * (dayScenario === 'normal' ? 0.25 : 0.15));
    const remMinutes = Math.floor(totalMinutes * (dayScenario === 'normal' ? 0.20 : 0.15));
    const lightMinutes = totalMinutes - deepMinutes - remMinutes;
    
    vitalsToCreate.push({
      userId,
      deviceId: device.id,
      timestamp: sleepEnd,
      vitalType: 'sleep',
      value: {
        sleep: {
          start: sleepStart.toISOString(),
          end: sleepEnd.toISOString(),
          stages: {
            deep: deepMinutes,
            light: lightMinutes,
            rem: remMinutes,
          },
        },
      },
      source: 'simulated',
    });
  }

  // Bulk insert all vitals
  await storage.bulkCreateVitals(vitalsToCreate);
  
  console.log(`✅ Generated ${vitalsToCreate.length} historical vital readings`);
}

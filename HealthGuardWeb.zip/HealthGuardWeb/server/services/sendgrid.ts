import { MailService } from '@sendgrid/mail';
import { storage } from '../storage';

if (!process.env.SENDGRID_API_KEY) {
  console.warn("SENDGRID_API_KEY not found, email sending will be simulated");
}

const mailService = new MailService();
if (process.env.SENDGRID_API_KEY) {
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

const FROM_EMAIL = process.env.FROM_EMAIL || 'noreply@healthguard.app';
const isDevelopment = process.env.NODE_ENV === 'development';

export interface EmailParams {
  to: string;
  subject: string;
  text?: string;
  html?: string;
  template?: string;
  userId?: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  const { to, subject, text, html, template, userId } = params;
  
  try {
    if (isDevelopment || !process.env.SENDGRID_API_KEY) {
      console.log(`[DEV] Email would be sent to: ${to}`);
      console.log(`[DEV] Subject: ${subject}`);
      console.log(`[DEV] Content: ${text || html?.slice(0, 100)}...`);
      
      // Log as sent in development
      await storage.logEmail({
        userId,
        to,
        subject,
        template,
        status: 'sent',
        provider: 'sendgrid-dev',
      });
      
      return true;
    }

    const [response] = await mailService.send({
      to,
      from: FROM_EMAIL,
      subject,
      text,
      html,
    });

    await storage.logEmail({
      userId,
      to,
      subject,
      template,
      status: 'sent',
      provider: 'sendgrid',
      providerId: response.headers['x-message-id'] as string,
    });

    return true;
  } catch (error: any) {
    console.error('SendGrid email error:', error);
    
    await storage.logEmail({
      userId,
      to,
      subject,
      template,
      status: 'failed',
      provider: 'sendgrid',
      error: error.message,
    });
    
    return false;
  }
}

export async function sendVerificationEmail(email: string, code: string, userId?: string): Promise<boolean> {
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Verify Your HealthGuard Account</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #0D9488; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
        .code { font-size: 32px; font-weight: bold; color: #0D9488; text-align: center; letter-spacing: 8px; margin: 20px 0; }
        .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>HealthGuard Email Verification</h1>
        </div>
        <div class="content">
          <p>Welcome to HealthGuard! Please verify your email address by entering this code:</p>
          <div class="code">${code}</div>
          <p>This code will expire in 15 minutes. If you didn't create a HealthGuard account, please ignore this email.</p>
        </div>
        <div class="footer">
          <p>HealthGuard - Personal Health Monitoring System</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return sendEmail({
    to: email,
    subject: 'Verify Your HealthGuard Account - Code: ' + code,
    html,
    text: `Welcome to HealthGuard! Your verification code is: ${code}. This code expires in 15 minutes.`,
    template: 'email_verification',
    userId,
  });
}

export async function sendEmergencyEmail(
  to: string, 
  patientName: string, 
  alertText: string, 
  vitals: any, 
  location?: { lat: number, lng: number },
  hospitals?: { name: string, address: string, distance: number }[],
  userId?: string
): Promise<boolean> {
  const locationText = location 
    ? `Location: https://maps.google.com/maps?q=${location.lat},${location.lng}`
    : 'Location: Not available';

  const hospitalsText = hospitals && hospitals.length > 0
    ? hospitals.map(h => `• ${h.name} - ${h.distance.toFixed(1)} miles\n  ${h.address}`).join('\n')
    : 'Hospital information not available';

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>🚨 EMERGENCY ALERT - ${patientName}</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .emergency-header { background: #DC2626; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
        .content { background: #FEE2E2; padding: 30px; border-radius: 0 0 8px 8px; border: 2px solid #DC2626; }
        .alert-box { background: white; border: 1px solid #DC2626; padding: 20px; margin: 20px 0; border-radius: 4px; }
        .vitals { background: #F3F4F6; padding: 15px; margin: 15px 0; border-radius: 4px; }
        .hospitals { background: #EFF6FF; padding: 15px; margin: 15px 0; border-radius: 4px; }
        .action-button { background: #DC2626; color: white; padding: 15px 30px; text-decoration: none; border-radius: 4px; display: inline-block; margin: 10px 0; font-weight: bold; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="emergency-header">
          <h1>🚨 EMERGENCY ALERT</h1>
          <p>${patientName} needs immediate assistance</p>
        </div>
        <div class="content">
          <div class="alert-box">
            <h3>Alert Details:</h3>
            <p><strong>${alertText}</strong></p>
            <p><strong>Time:</strong> ${new Date().toLocaleString()}</p>
          </div>
          
          <div class="vitals">
            <h3>Latest Vital Signs:</h3>
            <pre>${JSON.stringify(vitals, null, 2)}</pre>
          </div>
          
          <div>
            <h3>Patient Location:</h3>
            <p>${locationText}</p>
          </div>
          
          <div class="hospitals">
            <h3>Nearest Hospitals:</h3>
            <pre>${hospitalsText}</pre>
          </div>
          
          <p><strong>IMPORTANT:</strong> This is an automated emergency alert from HealthGuard. If this is a life-threatening emergency, call 911 immediately.</p>
          
          <a href="tel:911" class="action-button">📞 CALL 911</a>
        </div>
      </div>
    </body>
    </html>
  `;

  const text = `🚨 EMERGENCY ALERT - ${patientName}

${alertText}

Time: ${new Date().toLocaleString()}

Latest Vitals: ${JSON.stringify(vitals)}

${locationText}

Nearest Hospitals:
${hospitalsText}

IMPORTANT: This is an automated emergency alert. If this is life-threatening, call 911 immediately.`;

  return sendEmail({
    to,
    subject: `🚨 EMERGENCY - ${patientName} - ${alertText.slice(0, 50)}...`,
    html,
    text,
    template: 'emergency_alert',
    userId,
  });
}

export async function sendWelcomeEmail(email: string, name: string, userId?: string): Promise<boolean> {
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Welcome to HealthGuard!</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #0D9488; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
        .feature { margin: 15px 0; }
        .cta { background: #0D9488; color: white; padding: 15px 30px; text-decoration: none; border-radius: 4px; display: inline-block; margin: 20px 0; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Welcome to HealthGuard, ${name}!</h1>
        </div>
        <div class="content">
          <p>Congratulations on successfully verifying your account! You now have access to our comprehensive health monitoring platform.</p>
          
          <h3>What you can do with HealthGuard:</h3>
          <div class="feature">📱 Connect your devices (Google Fit, Bluetooth monitors)</div>
          <div class="feature">📊 Monitor your vital signs in real-time</div>
          <div class="feature">🤖 Get AI-powered health insights</div>
          <div class="feature">🚨 Automatic emergency detection and alerts</div>
          <div class="feature">👥 Emergency contact management</div>
          
          <p>To get started, complete your medical profile and connect your first device.</p>
          
          <a href="${process.env.APP_URL || 'http://localhost:5000'}/dashboard" class="cta">Go to Dashboard</a>
          
          <p>If you have any questions, our support team is here to help.</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return sendEmail({
    to: email,
    subject: 'Welcome to HealthGuard - Your Health Monitoring Journey Begins!',
    html,
    template: 'welcome',
    userId,
  });
}

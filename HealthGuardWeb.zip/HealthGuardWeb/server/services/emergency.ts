import { storage } from '../storage';
import { sendEmergencyEmail } from './sendgrid';
import { sendEmergencySms } from './twilio';
import { findNearestHospitals, getCurrentLocation, type Location } from './places';
import type { GeminiOutput, AiEvent } from '@shared/schema';

export interface EmergencyTrigger {
  userId: string;
  aiEvent?: AiEvent;
  manualTrigger?: boolean;
  location?: Location;
}

export interface EmergencyResponse {
  success: boolean;
  emergencyEventId?: string;
  actionsTaken: {
    browserAlert: { sent: boolean; timestamp: string };
    emailsSent: { contact: string; status: string; timestamp: string }[];
    smsSent: { contact: string; status: string; timestamp: string }[];
    hospitalsFound: { name: string; distance: number; address: string }[];
  };
  error?: string;
}

export async function triggerEmergencyWorkflow(trigger: EmergencyTrigger): Promise<EmergencyResponse> {
  const { userId, aiEvent, manualTrigger, location } = trigger;
  const timestamp = new Date().toISOString();

  try {
    // Get user profile for emergency contacts and consent
    const userProfile = await storage.getUserProfile(userId);
    const user = await storage.getUser(userId);
    
    if (!userProfile || !user) {
      return {
        success: false,
        error: 'User or profile not found',
        actionsTaken: {
          browserAlert: { sent: false, timestamp },
          emailsSent: [],
          smsSent: [],
          hospitalsFound: [],
        }
      };
    }

    // Check consent for emergency actions
    const consent = userProfile.consent;
    if (!consent?.emergencyContactNotification?.granted) {
      return {
        success: false,
        error: 'User has not consented to emergency contact notifications',
        actionsTaken: {
          browserAlert: { sent: false, timestamp },
          emailsSent: [],
          smsSent: [],
          hospitalsFound: [],
        }
      };
    }

    const actionsTaken: EmergencyResponse['actionsTaken'] = {
      browserAlert: { sent: true, timestamp }, // Browser alert assumed to be handled by WebSocket
      emailsSent: [],
      smsSent: [],
      hospitalsFound: [],
    };

    // Get patient info
    const patientName = userProfile.fullName || user.email;
    
    // Prepare alert text
    let alertText: string;
    let vitalsData: any = {};

    if (aiEvent?.aiOutput) {
      alertText = aiEvent.aiOutput.structuredAlertText;
      vitalsData = aiEvent.vitalsSnapshot;
    } else if (manualTrigger) {
      alertText = 'Manual emergency alert triggered by user';
      // Get latest vitals
      const latestVitals = await storage.getLatestVitals(userId);
      if (latestVitals) {
        vitalsData = latestVitals.value;
      }
    } else {
      alertText = 'Emergency condition detected';
    }

    // Get current location or use provided location
    let currentLocation = location;
    if (!currentLocation && consent?.locationSharing?.granted) {
      const locationResult = await getCurrentLocation();
      if (locationResult.success && locationResult.location) {
        currentLocation = locationResult.location;
      }
    }

    // Find nearest hospitals
    let hospitals: any[] = [];
    if (currentLocation) {
      const hospitalResult = await findNearestHospitals(currentLocation);
      if (hospitalResult.success && hospitalResult.hospitals) {
        hospitals = hospitalResult.hospitals.slice(0, 3).map(h => ({
          name: h.name,
          distance: h.distance,
          address: h.address,
        }));
        actionsTaken.hospitalsFound = hospitals;
      }
    }

    // Send emergency emails
    if (userProfile.emergencyContacts && userProfile.emergencyContacts.length > 0) {
      for (const contact of userProfile.emergencyContacts) {
        if (contact.email) {
          try {
            const emailSent = await sendEmergencyEmail(
              contact.email,
              patientName,
              alertText,
              vitalsData,
              currentLocation,
              hospitals.map(h => ({ name: h.name, address: h.address, distance: h.distance })),
              userId
            );

            actionsTaken.emailsSent.push({
              contact: `${contact.name} (${contact.email})`,
              status: emailSent ? 'sent' : 'failed',
              timestamp: new Date().toISOString(),
            });
          } catch (error) {
            console.error(`Failed to send emergency email to ${contact.email}:`, error);
            actionsTaken.emailsSent.push({
              contact: `${contact.name} (${contact.email})`,
              status: 'failed',
              timestamp: new Date().toISOString(),
            });
          }
        }
      }
    }

    // Send emergency SMS
    if (userProfile.emergencyContacts && userProfile.emergencyContacts.length > 0) {
      const dashboardUrl = `${process.env.APP_URL || 'http://localhost:5000'}/dashboard`;
      
      for (const contact of userProfile.emergencyContacts) {
        if (contact.phone) {
          try {
            const smsSent = await sendEmergencySms(
              contact.phone,
              patientName,
              alertText,
              dashboardUrl,
              userId
            );

            actionsTaken.smsSent.push({
              contact: `${contact.name} (${contact.phone})`,
              status: smsSent ? 'sent' : 'failed',
              timestamp: new Date().toISOString(),
            });
          } catch (error) {
            console.error(`Failed to send emergency SMS to ${contact.phone}:`, error);
            actionsTaken.smsSent.push({
              contact: `${contact.name} (${contact.phone})`,
              status: 'failed',
              timestamp: new Date().toISOString(),
            });
          }
        }
      }
    }

    // Create emergency event record
    const emergencyEvent = await storage.createEmergencyEvent({
      userId,
      aiEventId: aiEvent?.id,
      triggerType: manualTrigger ? 'manual' : 'ai',
      actionsTaken,
      resolved: false,
    });

    // Log audit trail
    await storage.logAudit({
      userId,
      action: 'emergency_triggered',
      resourceType: 'emergency_event',
      resourceId: emergencyEvent.id,
      newValues: { triggerType: manualTrigger ? 'manual' : 'ai', actionsTaken },
    });

    return {
      success: true,
      emergencyEventId: emergencyEvent.id,
      actionsTaken,
    };

  } catch (error: any) {
    console.error('Emergency workflow error:', error);
    
    return {
      success: false,
      error: error.message,
      actionsTaken: {
        browserAlert: { sent: false, timestamp },
        emailsSent: [],
        smsSent: [],
        hospitalsFound: [],
      },
    };
  }
}

export async function resolveEmergencyEvent(emergencyEventId: string, userId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const updatedEvent = await storage.updateEmergencyEvent(emergencyEventId, {
      resolved: true,
      resolvedAt: new Date(),
    });

    if (!updatedEvent) {
      return { success: false, error: 'Emergency event not found' };
    }

    // Log resolution
    await storage.logAudit({
      userId,
      action: 'emergency_resolved',
      resourceType: 'emergency_event',
      resourceId: emergencyEventId,
      newValues: { resolved: true, resolvedAt: new Date() },
    });

    return { success: true };
  } catch (error: any) {
    console.error('Emergency resolution error:', error);
    return { success: false, error: error.message };
  }
}

export function isDeterministicEmergency(vitals: any): boolean {
  if (!vitals) return false;

  // Critical SpO2 levels
  if (vitals.spO2 && vitals.spO2 < 85) {
    return true;
  }

  // Critical heart rate
  if (vitals.heartRate && (vitals.heartRate > 150 || vitals.heartRate < 40)) {
    return true;
  }

  // Critical blood pressure
  if (vitals.bloodPressure) {
    const { systolic, diastolic } = vitals.bloodPressure;
    if (systolic < 90 || systolic > 200 || diastolic < 50 || diastolic > 120) {
      return true;
    }
  }

  // Combined conditions
  if (vitals.spO2 && vitals.spO2 < 90 && vitals.heartRate && vitals.heartRate > 120) {
    return true;
  }

  return false;
}

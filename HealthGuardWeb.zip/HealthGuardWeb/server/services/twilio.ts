import { Twilio } from 'twilio';
import { storage } from '../storage';

const isDevelopment = process.env.NODE_ENV === 'development';

let twilioClient: Twilio | undefined;

if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
  twilioClient = new Twilio(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_AUTH_TOKEN
  );
} else {
  console.warn("Twilio credentials not found, SMS sending will be simulated");
}

const FROM_PHONE = process.env.TWILIO_FROM_NUMBER || '+1234567890';

export interface SmsParams {
  to: string;
  message: string;
  userId?: string;
}

export async function sendSms(params: SmsParams): Promise<boolean> {
  const { to, message, userId } = params;

  try {
    if (isDevelopment || !twilioClient) {
      console.log(`[DEV] SMS would be sent to: ${to}`);
      console.log(`[DEV] Message: ${message}`);
      
      // Log as sent in development
      await storage.logSms({
        userId,
        to,
        message,
        status: 'sent',
        provider: 'twilio-dev',
      });
      
      return true;
    }

    const twilioMessage = await twilioClient.messages.create({
      body: message,
      from: FROM_PHONE,
      to,
    });

    await storage.logSms({
      userId,
      to,
      message,
      status: 'sent',
      provider: 'twilio',
      providerId: twilioMessage.sid,
    });

    return true;
  } catch (error: any) {
    console.error('Twilio SMS error:', error);
    
    await storage.logSms({
      userId,
      to,
      message,
      status: 'failed',
      provider: 'twilio',
      error: error.message,
    });
    
    return false;
  }
}

export async function sendVerificationSms(phone: string, code: string, userId?: string): Promise<boolean> {
  const message = `Your HealthGuard verification code is: ${code}. This code expires in 15 minutes.`;
  
  return sendSms({
    to: phone,
    message,
    userId,
  });
}

export async function sendEmergencySms(
  to: string,
  patientName: string,
  alertText: string,
  dashboardUrl?: string,
  userId?: string
): Promise<boolean> {
  const url = dashboardUrl || (process.env.APP_URL ? `${process.env.APP_URL}/dashboard` : 'HealthGuard Dashboard');
  
  const message = `🚨 EMERGENCY: ${patientName} - ${alertText}. View details: ${url}. If life-threatening, call 911 immediately.`;

  return sendSms({
    to,
    message,
    userId,
  });
}

export function formatPhoneNumber(phone: string): string {
  // Remove all non-numeric characters
  const cleaned = phone.replace(/\D/g, '');
  
  // Add country code if not present
  if (cleaned.length === 10) {
    return `+1${cleaned}`;
  } else if (cleaned.length === 11 && cleaned.startsWith('1')) {
    return `+${cleaned}`;
  }
  
  return phone; // Return as-is if already formatted or international
}

export function generateVerificationCode(): string {
  return Math.floor(1000 + Math.random() * 9000).toString();
}

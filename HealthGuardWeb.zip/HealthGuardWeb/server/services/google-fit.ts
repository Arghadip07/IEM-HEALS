import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';
import { storage } from '../storage';

const oauth2Client = new OAuth2Client(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI
);

const fitness = google.fitness('v1');

export interface GoogleFitScopes {
  heartRate: 'https://www.googleapis.com/auth/fitness.heart_rate.read';
  bloodPressure: 'https://www.googleapis.com/auth/fitness.blood_pressure.read';
  sleep: 'https://www.googleapis.com/auth/fitness.sleep.read';
  activity: 'https://www.googleapis.com/auth/fitness.activity.read';
}

export const GOOGLE_FIT_SCOPES = [
  'https://www.googleapis.com/auth/fitness.heart_rate.read',
  'https://www.googleapis.com/auth/fitness.blood_pressure.read',
  'https://www.googleapis.com/auth/fitness.sleep.read',
  'https://www.googleapis.com/auth/fitness.activity.read',
];

export function getAuthUrl(userId: string): string {
  return oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: GOOGLE_FIT_SCOPES,
    state: userId, // Include user ID for callback handling
    prompt: 'consent', // Force consent to get refresh token
  });
}

export async function exchangeCodeForTokens(code: string, userId: string): Promise<{ success: boolean, error?: string }> {
  try {
    const { tokens } = await oauth2Client.getAccessToken(code);
    
    if (!tokens.refresh_token) {
      return { success: false, error: 'No refresh token received. User may need to revoke access and re-authorize.' };
    }

    // Store encrypted refresh token
    const device = await storage.createDevice({
      userId,
      deviceType: 'google_fit',
      deviceId: 'google_fit',
      deviceName: 'Google Fit',
      lastSeen: new Date(),
      metadata: {
        refreshToken: tokens.refresh_token, // In production, encrypt this
        accessToken: tokens.access_token,
        expiryDate: tokens.expiry_date,
        scopes: GOOGLE_FIT_SCOPES,
      }
    });

    return { success: true };
  } catch (error: any) {
    console.error('Google Fit token exchange error:', error);
    return { success: false, error: error.message };
  }
}

export async function refreshGoogleFitTokens(userId: string): Promise<{ success: boolean, tokens?: any, error?: string }> {
  try {
    const devices = await storage.getUserDevices(userId);
    const googleFitDevice = devices.find(d => d.deviceType === 'google_fit');
    
    if (!googleFitDevice || !googleFitDevice.metadata?.refreshToken) {
      return { success: false, error: 'Google Fit not connected or no refresh token available' };
    }

    oauth2Client.setCredentials({
      refresh_token: googleFitDevice.metadata.refreshToken,
    });

    const { credentials } = await oauth2Client.refreshAccessToken();
    
    // Update stored tokens
    await storage.updateDevice(googleFitDevice.id, {
      metadata: {
        ...googleFitDevice.metadata,
        accessToken: credentials.access_token,
        expiryDate: credentials.expiry_date,
      },
      lastSeen: new Date(),
    });

    return { success: true, tokens: credentials };
  } catch (error: any) {
    console.error('Google Fit token refresh error:', error);
    return { success: false, error: error.message };
  }
}

export async function fetchGoogleFitData(userId: string, dataType: 'heartRate' | 'bloodPressure' | 'sleep', startTime: Date, endTime: Date): Promise<{ success: boolean, data?: any[], error?: string }> {
  try {
    // Get valid tokens
    const tokenResult = await refreshGoogleFitTokens(userId);
    if (!tokenResult.success) {
      return { success: false, error: tokenResult.error };
    }

    oauth2Client.setCredentials(tokenResult.tokens);

    const dataTypeMappings = {
      heartRate: 'com.google.heart_rate.bpm',
      bloodPressure: 'com.google.blood_pressure',
      sleep: 'com.google.sleep.segment',
    };

    const dataSourceId = `derived:${dataTypeMappings[dataType]}:com.google.android.gms:merge_heart_rate_bpm`;
    
    const response = await fitness.users.dataSources.dataPointChanges.list({
      auth: oauth2Client,
      userId: 'me',
      dataSourceId,
      startTimeNanos: (startTime.getTime() * 1000000).toString(),
      endTimeNanos: (endTime.getTime() * 1000000).toString(),
    });

    if (!response.data.insertedDataPoint) {
      return { success: true, data: [] };
    }

    const processedData = response.data.insertedDataPoint.map((point: any) => {
      const timestamp = new Date(parseInt(point.startTimeNanos) / 1000000);
      
      if (dataType === 'heartRate') {
        return {
          timestamp,
          value: { heartRate: point.value?.[0]?.fpVal || point.value?.[0]?.intVal },
          source: 'google_fit',
        };
      } else if (dataType === 'bloodPressure') {
        return {
          timestamp,
          value: {
            bloodPressure: {
              systolic: point.value?.[0]?.fpVal || point.value?.[0]?.intVal,
              diastolic: point.value?.[1]?.fpVal || point.value?.[1]?.intVal,
            }
          },
          source: 'google_fit',
        };
      } else if (dataType === 'sleep') {
        return {
          timestamp,
          value: {
            sleep: {
              start: new Date(parseInt(point.startTimeNanos) / 1000000).toISOString(),
              end: new Date(parseInt(point.endTimeNanos) / 1000000).toISOString(),
              stages: {
                deep: point.value?.[0]?.intVal || 0,
                light: point.value?.[1]?.intVal || 0,
                rem: point.value?.[2]?.intVal || 0,
              }
            }
          },
          source: 'google_fit',
        };
      }

      return null;
    }).filter(Boolean);

    return { success: true, data: processedData };
  } catch (error: any) {
    console.error('Google Fit data fetch error:', error);
    return { success: false, error: error.message };
  }
}

export async function syncGoogleFitData(userId: string): Promise<{ success: boolean, synced?: number, error?: string }> {
  try {
    const endTime = new Date();
    const startTime = new Date(endTime.getTime() - (24 * 60 * 60 * 1000)); // Last 24 hours

    let totalSynced = 0;
    const dataTypes: ('heartRate' | 'bloodPressure' | 'sleep')[] = ['heartRate', 'bloodPressure', 'sleep'];

    for (const dataType of dataTypes) {
      const result = await fetchGoogleFitData(userId, dataType, startTime, endTime);
      
      if (result.success && result.data && result.data.length > 0) {
        // Find the Google Fit device
        const devices = await storage.getUserDevices(userId);
        const googleFitDevice = devices.find(d => d.deviceType === 'google_fit');
        
        if (googleFitDevice) {
          const vitalsToInsert = result.data.map(item => ({
            userId,
            deviceId: googleFitDevice.id,
            timestamp: item.timestamp,
            vitalType: dataType === 'heartRate' ? 'heart_rate' : dataType === 'bloodPressure' ? 'blood_pressure' : 'sleep',
            value: item.value,
            source: 'googlefit' as const,
          }));

          await storage.bulkCreateVitals(vitalsToInsert);
          totalSynced += vitalsToInsert.length;
        }
      }
    }

    return { success: true, synced: totalSynced };
  } catch (error: any) {
    console.error('Google Fit sync error:', error);
    return { success: false, error: error.message };
  }
}

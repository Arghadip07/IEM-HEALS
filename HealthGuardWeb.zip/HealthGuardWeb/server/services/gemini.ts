import { GoogleGenAI } from "@google/genai";
import { geminiOutputSchema, type GeminiOutput } from "@shared/schema";
import { z } from "zod";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface VitalsAnalysisInput {
  vitalsWindow: any[];
  medicalHistory: any;
  symptoms?: string;
}

export interface AnalysisResult {
  success: boolean;
  data?: GeminiOutput;
  error?: string;
  fallbackUsed?: boolean;
  processingTimeMs: number;
}

const SYSTEM_PROMPT = `You are a clinical triage assistant that MUST respond ONLY with valid JSON matching the schema:
{
"immediate_emergency": boolean,
"risk_score": number, // 0-100
"recommended_action": "call_ambulance" | "go_er" | "see_gp" | "self_care" | "follow_up",
"confidence": number, // 0.0-1.0
"explanation": string,
"contributing_factors": [string],
"structured_alert_text": string
}
Use units: bpm for heart rate, mmHg for blood pressure, % for SpO2. Return short and factual explanation. No markdown, no extra keys, no commentary. If uncertain, set recommended_action to 'follow_up' and confidence < 0.5.`;

export async function analyzeVitals(input: VitalsAnalysisInput): Promise<AnalysisResult> {
  const startTime = Date.now();
  
  try {
    // First attempt with Gemini
    const userContent = `medical_history: ${JSON.stringify(input.medicalHistory)}
vitals_window: ${JSON.stringify(input.vitalsWindow)}
symptoms: ${input.symptoms || "none reported"}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: SYSTEM_PROMPT,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            immediate_emergency: { type: "boolean" },
            risk_score: { type: "number", minimum: 0, maximum: 100 },
            recommended_action: { 
              type: "string", 
              enum: ["call_ambulance", "go_er", "see_gp", "self_care", "follow_up"] 
            },
            confidence: { type: "number", minimum: 0, maximum: 1 },
            explanation: { type: "string" },
            contributing_factors: { type: "array", items: { type: "string" } },
            structured_alert_text: { type: "string" }
          },
          required: ["immediate_emergency", "risk_score", "recommended_action", "confidence", "explanation", "contributing_factors", "structured_alert_text"]
        }
      },
      contents: userContent,
    });

    const rawJson = response.text;
    if (!rawJson) {
      throw new Error("Empty response from Gemini");
    }

    // Validate the response
    const parsedResponse = JSON.parse(rawJson);
    const validatedData = geminiOutputSchema.parse(parsedResponse);

    return {
      success: true,
      data: validatedData,
      processingTimeMs: Date.now() - startTime,
    };

  } catch (error) {
    console.error("Gemini analysis failed, trying fallback:", error);

    // Retry once with stricter prompt
    try {
      const stricterPrompt = `${SYSTEM_PROMPT}\n\nIMPORTANT: You MUST return valid JSON only. No explanations outside the JSON structure.`;

      const retryResponse = await ai.models.generateContent({
        model: "gemini-2.5-pro",
        config: {
          systemInstruction: stricterPrompt,
          responseMimeType: "application/json",
        },
        contents: `Analyze these vitals and return JSON: ${JSON.stringify(input.vitalsWindow)}`,
      });

      if (retryResponse.text) {
        const parsedRetry = JSON.parse(retryResponse.text);
        const validatedRetry = geminiOutputSchema.parse(parsedRetry);
        
        return {
          success: true,
          data: validatedRetry,
          processingTimeMs: Date.now() - startTime,
        };
      }
    } catch (retryError) {
      console.error("Gemini retry failed, using fallback rules:", retryError);
    }

    // Use deterministic fallback rules
    const fallbackResult = applyDeterministicRules(input.vitalsWindow);
    return {
      success: true,
      data: fallbackResult,
      fallbackUsed: true,
      processingTimeMs: Date.now() - startTime,
    };
  }
}

function applyDeterministicRules(vitalsWindow: any[]): GeminiOutput {
  if (!vitalsWindow || vitalsWindow.length === 0) {
    return {
      immediate_emergency: false,
      risk_score: 0,
      recommended_action: "follow_up",
      confidence: 0.1,
      explanation: "No vital signs data available for analysis",
      contributing_factors: [],
      structured_alert_text: "No data available for health assessment"
    };
  }

  const latestVitals = vitalsWindow[vitalsWindow.length - 1];
  const vitals = latestVitals.value || latestVitals.vitals || {};

  let immediateEmergency = false;
  let riskScore = 0;
  let recommendedAction: GeminiOutput["recommended_action"] = "self_care";
  const contributingFactors: string[] = [];

  // Critical emergency conditions
  if (vitals.spO2 && vitals.spO2 < 85) {
    immediateEmergency = true;
    riskScore = 95;
    recommendedAction = "call_ambulance";
    contributingFactors.push("spO2");
  }

  if (vitals.heartRate && (vitals.heartRate > 150 || vitals.heartRate < 40)) {
    immediateEmergency = true;
    riskScore = Math.max(riskScore, 90);
    recommendedAction = "call_ambulance";
    contributingFactors.push("heart_rate");
  }

  if (vitals.bloodPressure) {
    const { systolic, diastolic } = vitals.bloodPressure;
    if (systolic < 90 || systolic > 200 || diastolic < 50 || diastolic > 120) {
      immediateEmergency = true;
      riskScore = Math.max(riskScore, 85);
      recommendedAction = "call_ambulance";
      contributingFactors.push("blood_pressure");
    }
  }

  // Combined emergency conditions
  if (vitals.spO2 && vitals.spO2 < 90 && vitals.heartRate && vitals.heartRate > 120) {
    immediateEmergency = true;
    riskScore = Math.max(riskScore, 90);
    recommendedAction = "call_ambulance";
    if (!contributingFactors.includes("spO2")) contributingFactors.push("spO2");
    if (!contributingFactors.includes("heart_rate")) contributingFactors.push("heart_rate");
  }

  // Elevated risk conditions
  if (!immediateEmergency) {
    if (vitals.spO2 && vitals.spO2 >= 85 && vitals.spO2 <= 90) {
      riskScore = Math.max(riskScore, 70);
      recommendedAction = "go_er";
      contributingFactors.push("spO2");
    }

    if (vitals.heartRate && ((vitals.heartRate >= 110 && vitals.heartRate <= 120) || (vitals.heartRate >= 40 && vitals.heartRate <= 50))) {
      riskScore = Math.max(riskScore, 60);
      recommendedAction = recommendedAction === "self_care" ? "see_gp" : recommendedAction;
      contributingFactors.push("heart_rate");
    }

    if (vitals.bloodPressure) {
      const { systolic, diastolic } = vitals.bloodPressure;
      if ((systolic >= 90 && systolic <= 100) || (systolic >= 160 && systolic <= 180)) {
        riskScore = Math.max(riskScore, 65);
        recommendedAction = recommendedAction === "self_care" ? "see_gp" : recommendedAction;
        contributingFactors.push("blood_pressure");
      }
    }
  }

  // Default to normal if no concerning values
  if (riskScore === 0) {
    riskScore = 15;
    recommendedAction = "self_care";
  }

  const explanation = immediateEmergency 
    ? `Critical vital signs detected: ${contributingFactors.join(", ")}. Immediate medical attention required.`
    : riskScore > 50 
    ? `Elevated vital signs detected: ${contributingFactors.join(", ")}. Medical consultation recommended.`
    : "Vital signs within normal parameters.";

  const structuredAlertText = immediateEmergency
    ? `EMERGENCY: ${contributingFactors.includes("heart_rate") ? `HR ${vitals.heartRate} bpm` : ""}${contributingFactors.includes("blood_pressure") ? ` BP ${vitals.bloodPressure?.systolic}/${vitals.bloodPressure?.diastolic} mmHg` : ""}${contributingFactors.includes("spO2") ? ` SpO2 ${vitals.spO2}%` : ""}. Call 911 immediately.`
    : `Health Alert: ${explanation}`;

  return {
    immediate_emergency: immediateEmergency,
    risk_score: riskScore,
    recommended_action: recommendedAction,
    confidence: immediateEmergency ? 0.95 : 0.75,
    explanation,
    contributing_factors: contributingFactors,
    structured_alert_text: structuredAlertText,
  };
}

// Sample requests for documentation
export const sampleAnalysisRequests = [
  {
    medicalHistory: { diabetes: true, hypertension: true },
    vitalsWindow: [
      {
        timestamp: "2024-09-01T10:00:00Z",
        heartRate: 140,
        bloodPressure: { systolic: 85, diastolic: 55 },
        spO2: 82
      }
    ],
    symptoms: "severe shortness of breath, dizziness"
  },
  {
    medicalHistory: { conditions: [], notes: "healthy adult" },
    vitalsWindow: [
      {
        timestamp: "2024-09-01T10:00:00Z",
        heartRate: 75,
        bloodPressure: { systolic: 120, diastolic: 80 },
        spO2: 98
      }
    ]
  }
];

export const sampleAnalysisResponses = [
  {
    immediate_emergency: true,
    risk_score: 94,
    recommended_action: "call_ambulance",
    confidence: 0.95,
    explanation: "Very high heart rate, hypotension and severe hypoxemia indicating shock and respiratory failure risk.",
    contributing_factors: ["heart_rate", "blood_pressure", "spO2"],
    structured_alert_text: "Emergency: HR 140 bpm, BP 85/55 mmHg, SpO2 82%. Recommend ambulance immediately."
  },
  {
    immediate_emergency: false,
    risk_score: 15,
    recommended_action: "self_care",
    confidence: 0.85,
    explanation: "All vital signs within normal ranges. Continue monitoring.",
    contributing_factors: [],
    structured_alert_text: "Health status: Normal vital signs, continue regular monitoring."
  }
];

import { 
  users, userProfiles, devices, vitals, aiEvents, emergencyEvents, 
  emailLogs, smsLogs, auditLogs,
  type User, type InsertUser, type UserProfile, type InsertUserProfile,
  type Device, type InsertDevice, type Vitals, type InsertVitals,
  type AiEvent, type EmergencyEvent, type EmailLog, type SmsLog, type AuditLog
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  
  // User profile operations
  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile & { userId: string }): Promise<UserProfile>;
  updateUserProfile(userId: string, updates: Partial<InsertUserProfile>): Promise<UserProfile | undefined>;
  
  // Device operations
  getUserDevices(userId: string): Promise<Device[]>;
  getDevice(id: string): Promise<Device | undefined>;
  createDevice(device: InsertDevice & { userId: string }): Promise<Device>;
  updateDevice(id: string, updates: Partial<Device>): Promise<Device | undefined>;
  
  // Vitals operations
  getVitals(userId: string, type?: string, from?: Date, to?: Date): Promise<Vitals[]>;
  getLatestVitals(userId: string, type?: string): Promise<Vitals | undefined>;
  createVitals(vitals: InsertVitals & { userId: string }): Promise<Vitals>;
  bulkCreateVitals(vitals: (InsertVitals & { userId: string })[]): Promise<Vitals[]>;
  
  // AI Events operations
  createAiEvent(event: Omit<AiEvent, 'id' | 'createdAt'>): Promise<AiEvent>;
  getAiEvents(userId: string, limit?: number): Promise<AiEvent[]>;
  
  // Emergency Events operations
  createEmergencyEvent(event: Omit<EmergencyEvent, 'id' | 'createdAt'>): Promise<EmergencyEvent>;
  updateEmergencyEvent(id: string, updates: Partial<EmergencyEvent>): Promise<EmergencyEvent | undefined>;
  
  // Logging operations
  logEmail(log: Omit<EmailLog, 'id' | 'createdAt'>): Promise<EmailLog>;
  logSms(log: Omit<SmsLog, 'id' | 'createdAt'>): Promise<SmsLog>;
  logAudit(log: Omit<AuditLog, 'id' | 'createdAt'>): Promise<AuditLog>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        email: insertUser.email,
        passwordHash: insertUser.passwordHash,
      })
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    const [profile] = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
    return profile || undefined;
  }

  async createUserProfile(profile: InsertUserProfile & { userId: string }): Promise<UserProfile> {
    const [newProfile] = await db
      .insert(userProfiles)
      .values(profile)
      .returning();
    return newProfile;
  }

  async updateUserProfile(userId: string, updates: Partial<InsertUserProfile>): Promise<UserProfile | undefined> {
    const [profile] = await db
      .update(userProfiles)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(userProfiles.userId, userId))
      .returning();
    return profile || undefined;
  }

  async getUserDevices(userId: string): Promise<Device[]> {
    return db.select().from(devices).where(eq(devices.userId, userId));
  }

  async getDevice(id: string): Promise<Device | undefined> {
    const [device] = await db.select().from(devices).where(eq(devices.id, id));
    return device || undefined;
  }

  async createDevice(device: InsertDevice & { userId: string }): Promise<Device> {
    const [newDevice] = await db
      .insert(devices)
      .values(device)
      .returning();
    return newDevice;
  }

  async updateDevice(id: string, updates: Partial<Device>): Promise<Device | undefined> {
    const [device] = await db
      .update(devices)
      .set(updates)
      .where(eq(devices.id, id))
      .returning();
    return device || undefined;
  }

  async getVitals(userId: string, type?: string, from?: Date, to?: Date): Promise<Vitals[]> {
    let query = db.select().from(vitals).where(eq(vitals.userId, userId));
    
    if (type) {
      query = query.where(and(eq(vitals.userId, userId), eq(vitals.vitalType, type as any)));
    }
    
    if (from) {
      query = query.where(and(eq(vitals.userId, userId), gte(vitals.timestamp, from)));
    }
    
    if (to) {
      query = query.where(and(eq(vitals.userId, userId), lte(vitals.timestamp, to)));
    }
    
    return query.orderBy(desc(vitals.timestamp));
  }

  async getLatestVitals(userId: string, type?: string): Promise<Vitals | undefined> {
    let query = db.select().from(vitals).where(eq(vitals.userId, userId));
    
    if (type) {
      query = query.where(and(eq(vitals.userId, userId), eq(vitals.vitalType, type as any)));
    }
    
    const [vital] = await query.orderBy(desc(vitals.timestamp)).limit(1);
    return vital || undefined;
  }

  async createVitals(vital: InsertVitals & { userId: string }): Promise<Vitals> {
    const [newVital] = await db
      .insert(vitals)
      .values(vital)
      .returning();
    return newVital;
  }

  async bulkCreateVitals(vitalsList: (InsertVitals & { userId: string })[]): Promise<Vitals[]> {
    return db
      .insert(vitals)
      .values(vitalsList)
      .returning();
  }

  async createAiEvent(event: Omit<AiEvent, 'id' | 'createdAt'>): Promise<AiEvent> {
    const [aiEvent] = await db
      .insert(aiEvents)
      .values(event)
      .returning();
    return aiEvent;
  }

  async getAiEvents(userId: string, limit = 10): Promise<AiEvent[]> {
    return db
      .select()
      .from(aiEvents)
      .where(eq(aiEvents.userId, userId))
      .orderBy(desc(aiEvents.createdAt))
      .limit(limit);
  }

  async createEmergencyEvent(event: Omit<EmergencyEvent, 'id' | 'createdAt'>): Promise<EmergencyEvent> {
    const [emergencyEvent] = await db
      .insert(emergencyEvents)
      .values(event)
      .returning();
    return emergencyEvent;
  }

  async updateEmergencyEvent(id: string, updates: Partial<EmergencyEvent>): Promise<EmergencyEvent | undefined> {
    const [event] = await db
      .update(emergencyEvents)
      .set(updates)
      .where(eq(emergencyEvents.id, id))
      .returning();
    return event || undefined;
  }

  async logEmail(log: Omit<EmailLog, 'id' | 'createdAt'>): Promise<EmailLog> {
    const [emailLog] = await db
      .insert(emailLogs)
      .values(log)
      .returning();
    return emailLog;
  }

  async logSms(log: Omit<SmsLog, 'id' | 'createdAt'>): Promise<SmsLog> {
    const [smsLog] = await db
      .insert(smsLogs)
      .values(log)
      .returning();
    return smsLog;
  }

  async logAudit(log: Omit<AuditLog, 'id' | 'createdAt'>): Promise<AuditLog> {
    const [auditLog] = await db
      .insert(auditLogs)
      .values(log)
      .returning();
    return auditLog;
  }
}

export const storage = new DatabaseStorage();

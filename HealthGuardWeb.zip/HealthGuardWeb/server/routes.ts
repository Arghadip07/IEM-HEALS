import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from 'ws';
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { validateBody, validateQuery, validateParams, requireAuth, commonSchemas, generateVerificationCode, isCodeExpired } from "./utils/validation";
import { analyzeVitals } from "./services/gemini";
import { sendVerificationEmail, sendWelcomeEmail } from "./services/sendgrid";
import { sendVerificationSms, formatPhoneNumber } from "./services/twilio";
import { getAuthUrl, exchangeCodeForTokens, syncGoogleFitData } from "./services/google-fit";
import { triggerEmergencyWorkflow, resolveEmergencyEvent, isDeterministicEmergency } from "./services/emergency";
import { vitalsPayloadSchema, insertUserProfileSchema, insertDeviceSchema, insertVitalsSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Email verification routes
  app.post('/api/verify-email', requireAuth, validateBody(z.object({
    code: z.string().length(6, "Verification code must be 6 digits")
  })), async (req, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      
      if (!user || !user.emailVerificationCode || !user.emailVerificationExpires) {
        return res.status(400).json({ message: "No verification code found" });
      }

      if (isCodeExpired(user.emailVerificationExpires)) {
        return res.status(400).json({ message: "Verification code has expired" });
      }

      if (user.emailVerificationCode !== req.body.code) {
        return res.status(400).json({ message: "Invalid verification code" });
      }

      // Mark email as verified
      const updatedUser = await storage.updateUser(user.id, {
        emailVerified: true,
        emailVerificationCode: null,
        emailVerificationExpires: null,
      });

      // Send welcome email
      if (updatedUser) {
        await sendWelcomeEmail(updatedUser.email, updatedUser.email.split('@')[0], updatedUser.id);
      }

      res.json({ message: "Email verified successfully" });
    } catch (error: any) {
      console.error("Email verification error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post('/api/resend-verification', requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.emailVerified) {
        return res.status(400).json({ message: "Email already verified" });
      }

      const code = generateVerificationCode(6);
      const expires = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

      await storage.updateUser(user.id, {
        emailVerificationCode: code,
        emailVerificationExpires: expires,
      });

      await sendVerificationEmail(user.email, code, user.id);

      res.json({ message: "Verification code sent" });
    } catch (error: any) {
      console.error("Resend verification error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Phone verification routes
  app.post('/api/verify-phone', requireAuth, validateBody(z.object({
    phone: commonSchemas.phone,
  })), async (req, res) => {
    try {
      const phone = formatPhoneNumber(req.body.phone);
      const code = generateVerificationCode(4);
      const expires = new Date(Date.now() + 15 * 60 * 1000);

      await storage.updateUser(req.user!.id, {
        phone,
        phoneVerificationCode: code,
        phoneVerificationExpires: expires,
      });

      await sendVerificationSms(phone, code, req.user!.id);

      res.json({ message: "Verification code sent to phone" });
    } catch (error: any) {
      console.error("Phone verification error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post('/api/confirm-phone', requireAuth, validateBody(z.object({
    code: z.string().length(4, "Phone verification code must be 4 digits")
  })), async (req, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      
      if (!user || !user.phoneVerificationCode || !user.phoneVerificationExpires) {
        return res.status(400).json({ message: "No phone verification code found" });
      }

      if (isCodeExpired(user.phoneVerificationExpires)) {
        return res.status(400).json({ message: "Verification code has expired" });
      }

      if (user.phoneVerificationCode !== req.body.code) {
        return res.status(400).json({ message: "Invalid verification code" });
      }

      await storage.updateUser(user.id, {
        phoneVerified: true,
        phoneVerificationCode: null,
        phoneVerificationExpires: null,
      });

      res.json({ message: "Phone verified successfully" });
    } catch (error: any) {
      console.error("Phone confirmation error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // User profile routes
  app.get('/api/profile', requireAuth, async (req, res) => {
    try {
      const profile = await storage.getUserProfile(req.user!.id);
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      res.json(profile);
    } catch (error: any) {
      console.error("Get profile error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post('/api/profile', requireAuth, validateBody(insertUserProfileSchema), async (req, res) => {
    try {
      const existingProfile = await storage.getUserProfile(req.user!.id);
      
      if (existingProfile) {
        const updatedProfile = await storage.updateUserProfile(req.user!.id, req.body);
        return res.json(updatedProfile);
      } else {
        const newProfile = await storage.createUserProfile({
          ...req.body,
          userId: req.user!.id,
        });
        return res.status(201).json(newProfile);
      }
    } catch (error: any) {
      console.error("Profile creation/update error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Device management routes
  app.get('/api/devices', requireAuth, async (req, res) => {
    try {
      const devices = await storage.getUserDevices(req.user!.id);
      res.json(devices);
    } catch (error: any) {
      console.error("Get devices error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post('/api/devices', requireAuth, validateBody(insertDeviceSchema), async (req, res) => {
    try {
      const device = await storage.createDevice({
        ...req.body,
        userId: req.user!.id,
      });
      res.status(201).json(device);
    } catch (error: any) {
      console.error("Create device error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Vitals routes
  app.get('/api/vitals', requireAuth, validateQuery(commonSchemas.vitalsQuery.merge(commonSchemas.pagination)), async (req, res) => {
    try {
      const { type, from, to } = req.query as any;
      const fromDate = from ? new Date(from) : undefined;
      const toDate = to ? new Date(to) : undefined;
      
      const vitals = await storage.getVitals(req.user!.id, type, fromDate, toDate);
      res.json(vitals);
    } catch (error: any) {
      console.error("Get vitals error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get('/api/vitals/latest', requireAuth, validateQuery(z.object({ type: z.string().optional() })), async (req, res) => {
    try {
      const vital = await storage.getLatestVitals(req.user!.id, req.query.type as string);
      if (!vital) {
        return res.status(404).json({ message: "No vitals found" });
      }
      res.json(vital);
    } catch (error: any) {
      console.error("Get latest vitals error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post('/api/vitals', requireAuth, validateBody(z.object({
    vitals: z.array(vitalsPayloadSchema).min(1, "At least one vital reading required")
  })), async (req, res) => {
    try {
      const vitalsData = req.body.vitals.map((vital: any) => ({
        userId: req.user!.id,
        deviceId: vital.deviceId,
        timestamp: new Date(vital.timestamp),
        vitalType: Object.keys(vital.vitals)[0] as any, // Determine type from first vital
        value: vital.vitals,
        source: vital.source,
      }));

      const createdVitals = await storage.bulkCreateVitals(vitalsData);
      
      // Check for emergency conditions on the latest vitals
      const latestVital = createdVitals[createdVitals.length - 1];
      if (latestVital && isDeterministicEmergency(latestVital.value)) {
        // Trigger emergency workflow asynchronously
        setImmediate(async () => {
          try {
            await triggerEmergencyWorkflow({
              userId: req.user!.id,
              manualTrigger: false,
            });
            
            // Broadcast emergency via WebSocket
            wss.clients.forEach((client) => {
              if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({
                  type: 'emergency_alert',
                  userId: req.user!.id,
                  vitals: latestVital.value,
                  timestamp: new Date().toISOString(),
                }));
              }
            });
          } catch (emergencyError) {
            console.error("Emergency workflow error:", emergencyError);
          }
        });
      }

      res.status(201).json(createdVitals);
    } catch (error: any) {
      console.error("Create vitals error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // AI analysis routes
  app.post('/api/ai/analyze', requireAuth, validateBody(z.object({
    vitalsWindow: z.array(z.any()).min(1, "At least one vital reading required"),
    symptoms: z.string().optional(),
  })), async (req, res) => {
    try {
      const userProfile = await storage.getUserProfile(req.user!.id);
      const medicalHistory = userProfile?.medicalHistory || {};

      const analysis = await analyzeVitals({
        vitalsWindow: req.body.vitalsWindow,
        medicalHistory,
        symptoms: req.body.symptoms,
      });

      if (!analysis.success) {
        return res.status(500).json({ 
          message: "Analysis failed", 
          error: analysis.error 
        });
      }

      // Store AI event
      const aiEvent = await storage.createAiEvent({
        userId: req.user!.id,
        vitalsSnapshot: req.body.vitalsWindow,
        medicalHistory,
        symptoms: req.body.symptoms,
        aiOutput: analysis.data!,
        processingTimeMs: analysis.processingTimeMs,
      });

      // Trigger emergency workflow if necessary
      if (analysis.data!.immediate_emergency) {
        setImmediate(async () => {
          try {
            const emergencyResult = await triggerEmergencyWorkflow({
              userId: req.user!.id,
              aiEvent,
            });

            // Broadcast emergency via WebSocket
            wss.clients.forEach((client) => {
              if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({
                  type: 'emergency_alert',
                  userId: req.user!.id,
                  aiAnalysis: analysis.data,
                  emergencyResponse: emergencyResult,
                  timestamp: new Date().toISOString(),
                }));
              }
            });
          } catch (emergencyError) {
            console.error("Emergency workflow error:", emergencyError);
          }
        });
      }

      res.json({
        analysis: analysis.data,
        fallbackUsed: analysis.fallbackUsed,
        processingTimeMs: analysis.processingTimeMs,
        aiEventId: aiEvent.id,
      });
    } catch (error: any) {
      console.error("AI analysis error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Google Fit integration routes
  app.get('/api/auth/googlefit', requireAuth, async (req, res) => {
    try {
      const authUrl = getAuthUrl(req.user!.id);
      res.json({ authUrl });
    } catch (error: any) {
      console.error("Google Fit auth URL error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get('/api/auth/googlefit/callback', validateQuery(z.object({
    code: z.string(),
    state: z.string().uuid(),
  })), async (req, res) => {
    try {
      const { code, state: userId } = req.query as any;
      
      const result = await exchangeCodeForTokens(code, userId);
      
      if (!result.success) {
        return res.redirect(`${process.env.APP_URL || 'http://localhost:5000'}/devices?error=${encodeURIComponent(result.error || 'Unknown error')}`);
      }

      res.redirect(`${process.env.APP_URL || 'http://localhost:5000'}/devices?success=googlefit_connected`);
    } catch (error: any) {
      console.error("Google Fit callback error:", error);
      res.redirect(`${process.env.APP_URL || 'http://localhost:5000'}/devices?error=callback_failed`);
    }
  });

  app.post('/api/sync/googlefit', requireAuth, async (req, res) => {
    try {
      const result = await syncGoogleFitData(req.user!.id);
      
      if (!result.success) {
        return res.status(400).json({ message: result.error });
      }

      res.json({ 
        message: "Sync completed", 
        synced: result.synced 
      });
    } catch (error: any) {
      console.error("Google Fit sync error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Emergency routes
  app.post('/api/emergency/trigger', requireAuth, async (req, res) => {
    try {
      const result = await triggerEmergencyWorkflow({
        userId: req.user!.id,
        manualTrigger: true,
      });

      if (!result.success) {
        return res.status(500).json({ 
          message: "Failed to trigger emergency workflow", 
          error: result.error 
        });
      }

      // Broadcast emergency via WebSocket
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'emergency_alert',
            userId: req.user!.id,
            manualTrigger: true,
            emergencyResponse: result,
            timestamp: new Date().toISOString(),
          }));
        }
      });

      res.json(result);
    } catch (error: any) {
      console.error("Manual emergency trigger error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post('/api/emergency/:eventId/resolve', requireAuth, validateParams(z.object({
    eventId: commonSchemas.uuid
  })), async (req, res) => {
    try {
      const result = await resolveEmergencyEvent(req.params.eventId, req.user!.id);
      
      if (!result.success) {
        return res.status(400).json({ message: result.error });
      }

      res.json({ message: "Emergency resolved" });
    } catch (error: any) {
      console.error("Emergency resolution error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Health check route
  app.get('/api/health', (req, res) => {
    res.json({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      services: {
        database: 'connected',
        gemini: !!process.env.GEMINI_API_KEY,
        sendgrid: !!process.env.SENDGRID_API_KEY,
        twilio: !!(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN),
        googleFit: !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
        googlePlaces: !!process.env.GOOGLE_PLACES_API_KEY,
      }
    });
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws' 
  });

  wss.on('connection', (ws, req) => {
    console.log('WebSocket client connected');
    
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle different message types
        switch (data.type) {
          case 'subscribe_vitals':
            // In a real implementation, you might associate the connection with a user ID
            ws.send(JSON.stringify({
              type: 'subscription_confirmed',
              channel: 'vitals',
              timestamp: new Date().toISOString(),
            }));
            break;
            
          case 'heartbeat':
            ws.send(JSON.stringify({
              type: 'heartbeat_ack',
              timestamp: new Date().toISOString(),
            }));
            break;
            
          default:
            console.log('Unknown WebSocket message type:', data.type);
        }
      } catch (error) {
        console.error('WebSocket message parsing error:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });

    // Send initial connection confirmation
    ws.send(JSON.stringify({
      type: 'connection_established',
      timestamp: new Date().toISOString(),
    }));
  });

  // Store wss reference for use in routes
  (app as any).wss = wss;

  return httpServer;
}

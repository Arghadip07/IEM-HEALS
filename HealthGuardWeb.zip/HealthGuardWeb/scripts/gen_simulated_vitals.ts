import { apiRequest } from "../server/routes";
import { VitalsPayload } from "@shared/schema";

interface SimulationConfig {
  userId: string;
  deviceId: string;
  duration: number; // minutes
  interval: number; // seconds between readings
  scenario: 'normal' | 'elevated_risk' | 'immediate_emergency';
  enableRealTimeMode?: boolean; // Send to WebSocket if true
}

interface VitalRanges {
  heartRate: { min: number; max: number; emergency?: number };
  systolic: { min: number; max: number; emergency?: number };
  diastolic: { min: number; max: number; emergency?: number };
  spO2: { min: number; max: number; emergency?: number };
}

const SCENARIOS: Record<string, VitalRanges> = {
  normal: {
    heartRate: { min: 60, max: 100 },
    systolic: { min: 110, max: 140 },
    diastolic: { min: 70, max: 90 },
    spO2: { min: 95, max: 100 },
  },
  elevated_risk: {
    heartRate: { min: 100, max: 120 },
    systolic: { min: 140, max: 160 },
    diastolic: { min: 90, max: 100 },
    spO2: { min: 90, max: 95 },
  },
  immediate_emergency: {
    heartRate: { min: 150, max: 180, emergency: 200 },
    systolic: { min: 200, max: 250, emergency: 80 },
    diastolic: { min: 120, max: 140, emergency: 50 },
    spO2: { min: 70, max: 85, emergency: 75 },
  },
};

class VitalsSimulator {
  private config: SimulationConfig;
  private isRunning: boolean = false;
  private intervalId: NodeJS.Timeout | null = null;
  private startTime: Date = new Date();

  constructor(config: SimulationConfig) {
    this.config = config;
  }

  private getRandomValue(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  private addVariation(value: number, variationPercent: number = 5): number {
    const variation = value * (variationPercent / 100);
    const randomVariation = (Math.random() - 0.5) * 2 * variation;
    return Math.round(value + randomVariation);
  }

  private generateVitals(): VitalsPayload['vitals'] {
    const ranges = SCENARIOS[this.config.scenario];
    const elapsedMinutes = (Date.now() - this.startTime.getTime()) / (1000 * 60);
    
    let vitals: VitalsPayload['vitals'] = {};

    // Generate heart rate
    let heartRate = this.getRandomValue(ranges.heartRate.min, ranges.heartRate.max);
    
    // Add emergency spikes for emergency scenario
    if (this.config.scenario === 'immediate_emergency' && Math.random() < 0.3) {
      heartRate = ranges.heartRate.emergency || heartRate;
    }
    
    // Add some realistic variation
    heartRate = this.addVariation(heartRate, 3);
    vitals.heartRate = Math.max(30, Math.min(220, heartRate));

    // Generate blood pressure
    let systolic = this.getRandomValue(ranges.systolic.min, ranges.systolic.max);
    let diastolic = this.getRandomValue(ranges.diastolic.min, ranges.diastolic.max);
    
    // Emergency scenario adjustments
    if (this.config.scenario === 'immediate_emergency' && Math.random() < 0.4) {
      if (Math.random() < 0.5) {
        // Hypertensive crisis
        systolic = ranges.systolic.emergency || systolic;
      } else {
        // Hypotensive shock
        systolic = ranges.systolic.emergency || 80;
        diastolic = ranges.diastolic.emergency || 50;
      }
    }
    
    systolic = this.addVariation(systolic, 4);
    diastolic = this.addVariation(diastolic, 4);
    
    // Ensure diastolic is lower than systolic
    if (diastolic >= systolic) {
      diastolic = systolic - 20;
    }
    
    vitals.bloodPressure = {
      systolic: Math.max(60, Math.min(300, systolic)),
      diastolic: Math.max(40, Math.min(200, diastolic)),
    };

    // Generate SpO2
    let spO2 = this.getRandomValue(ranges.spO2.min, ranges.spO2.max);
    
    // Emergency drops
    if (this.config.scenario === 'immediate_emergency' && Math.random() < 0.25) {
      spO2 = ranges.spO2.emergency || spO2;
    }
    
    spO2 = this.addVariation(spO2, 2);
    vitals.spO2 = Math.max(70, Math.min(100, spO2));

    // Generate sleep data occasionally (simulate overnight readings)
    if (Math.random() < 0.1) {
      const sleepHours = this.config.scenario === 'normal' ? 
        this.getRandomValue(6, 9) : 
        this.getRandomValue(3, 6);
      
      const totalMinutes = sleepHours * 60;
      const deepMinutes = Math.floor(totalMinutes * 0.25);
      const remMinutes = Math.floor(totalMinutes * 0.20);
      const lightMinutes = totalMinutes - deepMinutes - remMinutes;
      
      const now = new Date();
      const sleepStart = new Date(now.getTime() - (sleepHours * 60 * 60 * 1000));
      
      vitals.sleep = {
        start: sleepStart.toISOString(),
        end: now.toISOString(),
        stages: {
          deep: deepMinutes,
          light: lightMinutes,
          rem: remMinutes,
        },
      };
    }

    return vitals;
  }

  private async sendVitals(vitals: VitalsPayload['vitals']): Promise<void> {
    const payload: VitalsPayload = {
      userId: this.config.userId,
      deviceId: this.config.deviceId,
      timestamp: new Date().toISOString(),
      vitals,
      source: 'simulated',
    };

    try {
      const response = await fetch('/api/vitals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ vitals: [payload] }),
      });

      if (!response.ok) {
        throw new Error(`Failed to send vitals: ${response.statusText}`);
      }

      console.log(`📊 Sent ${this.config.scenario} vitals:`, {
        heartRate: vitals.heartRate,
        bloodPressure: vitals.bloodPressure,
        spO2: vitals.spO2,
        timestamp: payload.timestamp,
      });

    } catch (error) {
      console.error('Failed to send simulated vitals:', error);
    }
  }

  public start(): void {
    if (this.isRunning) {
      console.log('Simulator is already running');
      return;
    }

    this.isRunning = true;
    this.startTime = new Date();
    
    console.log(`🚀 Starting vitals simulation:`);
    console.log(`   Scenario: ${this.config.scenario}`);
    console.log(`   Duration: ${this.config.duration} minutes`);
    console.log(`   Interval: ${this.config.interval} seconds`);
    console.log(`   Device ID: ${this.config.deviceId}`);

    // Send initial reading
    this.sendVitals(this.generateVitals());

    // Set up recurring readings
    this.intervalId = setInterval(() => {
      const elapsedMinutes = (Date.now() - this.startTime.getTime()) / (1000 * 60);
      
      if (elapsedMinutes >= this.config.duration) {
        this.stop();
        return;
      }

      this.sendVitals(this.generateVitals());
    }, this.config.interval * 1000);
  }

  public stop(): void {
    if (!this.isRunning) {
      return;
    }

    this.isRunning = false;
    
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    console.log('⏹️  Vitals simulation stopped');
  }

  public getStatus(): { isRunning: boolean; elapsedMinutes: number; scenario: string } {
    const elapsedMinutes = this.isRunning ? 
      (Date.now() - this.startTime.getTime()) / (1000 * 60) : 0;
    
    return {
      isRunning: this.isRunning,
      elapsedMinutes: Math.round(elapsedMinutes * 100) / 100,
      scenario: this.config.scenario,
    };
  }
}

// Export for use in other modules
export { VitalsSimulator, SimulationConfig, SCENARIOS };

// CLI usage when run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.log(`
Usage: tsx scripts/gen_simulated_vitals.ts <userId> <scenario> [duration] [interval]

Parameters:
  userId    - UUID of the user to generate vitals for
  scenario  - Simulation scenario: normal | elevated_risk | immediate_emergency
  duration  - Duration in minutes (default: 10)
  interval  - Interval between readings in seconds (default: 30)

Examples:
  tsx scripts/gen_simulated_vitals.ts user-123 normal 5 15
  tsx scripts/gen_simulated_vitals.ts user-123 immediate_emergency 2 10
  tsx scripts/gen_simulated_vitals.ts user-123 elevated_risk
    `);
    process.exit(1);
  }

  const [userId, scenario, durationStr = '10', intervalStr = '30'] = args;
  
  if (!['normal', 'elevated_risk', 'immediate_emergency'].includes(scenario)) {
    console.error('Invalid scenario. Must be: normal | elevated_risk | immediate_emergency');
    process.exit(1);
  }

  const config: SimulationConfig = {
    userId,
    deviceId: 'simulated-device-001',
    duration: parseInt(durationStr, 10),
    interval: parseInt(intervalStr, 10),
    scenario: scenario as any,
  };

  const simulator = new VitalsSimulator(config);
  
  // Handle graceful shutdown
  process.on('SIGINT', () => {
    console.log('\n📋 Received SIGINT, stopping simulation...');
    simulator.stop();
    process.exit(0);
  });

  simulator.start();
}

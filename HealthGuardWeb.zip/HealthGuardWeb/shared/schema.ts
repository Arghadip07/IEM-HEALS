import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, timestamp, integer, jsonb, uuid, decimal, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const genderEnum = pgEnum("gender", ["male", "female", "other", "prefer_not_to_say"]);
export const deviceTypeEnum = pgEnum("device_type", ["google_fit", "web_bluetooth", "simulated"]);
export const vitalTypeEnum = pgEnum("vital_type", ["heart_rate", "blood_pressure", "spO2", "sleep"]);
export const emergencyActionEnum = pgEnum("emergency_action", ["call_ambulance", "go_er", "see_gp", "self_care", "follow_up"]);

// Users table
export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  emailVerified: boolean("email_verified").default(false),
  emailVerificationCode: text("email_verification_code"),
  emailVerificationExpires: timestamp("email_verification_expires"),
  phone: text("phone"),
  phoneVerified: boolean("phone_verified").default(false),
  phoneVerificationCode: text("phone_verification_code"),
  phoneVerificationExpires: timestamp("phone_verification_expires"),
  refreshToken: text("refresh_token"),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User profiles table
export const userProfiles = pgTable("user_profiles", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  fullName: text("full_name").notNull(),
  preferredName: text("preferred_name"),
  gender: genderEnum("gender"),
  dateOfBirth: timestamp("date_of_birth"),
  heightCm: decimal("height_cm", { precision: 5, scale: 2 }),
  weightKg: decimal("weight_kg", { precision: 5, scale: 2 }),
  allergies: jsonb("allergies").$type<string[]>().default([]),
  medicalHistory: jsonb("medical_history").$type<{conditions: string[], notes: string}>().default({conditions: [], notes: ""}),
  medications: jsonb("medications").$type<{name: string, dosage: string, frequency: string}[]>().default([]),
  emergencyContacts: jsonb("emergency_contacts").$type<{name: string, relationship: string, phone: string, email: string}[]>().default([]),
  consent: jsonb("consent").$type<{healthDataCollection: {granted: boolean, timestamp: string}, locationSharing: {granted: boolean, timestamp: string}, emergencyContactNotification: {granted: boolean, timestamp: string}}>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Devices table
export const devices = pgTable("devices", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  deviceType: deviceTypeEnum("device_type").notNull(),
  deviceId: text("device_id").notNull(),
  deviceName: text("device_name"),
  lastSeen: timestamp("last_seen"),
  isActive: boolean("is_active").default(true),
  metadata: jsonb("metadata").$type<Record<string, any>>().default({}),
  createdAt: timestamp("created_at").defaultNow(),
});

// Vitals table
export const vitals = pgTable("vitals", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  deviceId: uuid("device_id").references(() => devices.id),
  timestamp: timestamp("timestamp").notNull(),
  vitalType: vitalTypeEnum("vital_type").notNull(),
  value: jsonb("value").$type<{
    heartRate?: number;
    bloodPressure?: {systolic: number, diastolic: number};
    spO2?: number;
    sleep?: {start: string, end: string, stages: {deep: number, light: number, rem: number}};
  }>().notNull(),
  source: deviceTypeEnum("source").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// AI Events table
export const aiEvents = pgTable("ai_events", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  vitalsSnapshot: jsonb("vitals_snapshot").$type<any[]>().notNull(),
  medicalHistory: jsonb("medical_history").$type<any>(),
  symptoms: text("symptoms"),
  aiOutput: jsonb("ai_output").$type<{
    immediateEmergency: boolean;
    riskScore: number;
    recommendedAction: string;
    confidence: number;
    explanation: string;
    contributingFactors: string[];
    structuredAlertText: string;
  }>().notNull(),
  aiModel: text("ai_model").default("gemini-2.5-flash"),
  processingTimeMs: integer("processing_time_ms"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Emergency Events table
export const emergencyEvents = pgTable("emergency_events", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  aiEventId: uuid("ai_event_id").references(() => aiEvents.id),
  triggerType: text("trigger_type").notNull(), // "ai" or "manual"
  actionsTaken: jsonb("actions_taken").$type<{
    browserAlert: {sent: boolean, timestamp: string};
    emailsSent: {contact: string, status: string, timestamp: string}[];
    smsSent: {contact: string, status: string, timestamp: string}[];
    hospitalsFound: {name: string, distance: number, address: string}[];
  }>().notNull(),
  resolved: boolean("resolved").default(false),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Email logs table
export const emailLogs = pgTable("email_logs", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id),
  to: text("to").notNull(),
  subject: text("subject").notNull(),
  template: text("template"),
  status: text("status").notNull(), // "sent", "failed", "pending"
  provider: text("provider").default("sendgrid"),
  providerId: text("provider_id"),
  error: text("error"),
  createdAt: timestamp("created_at").defaultNow(),
});

// SMS logs table
export const smsLogs = pgTable("sms_logs", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id),
  to: text("to").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull(), // "sent", "failed", "pending"
  provider: text("provider").default("twilio"),
  providerId: text("provider_id"),
  error: text("error"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Audit logs table
export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id),
  action: text("action").notNull(),
  resourceType: text("resource_type"),
  resourceId: text("resource_id"),
  oldValues: jsonb("old_values"),
  newValues: jsonb("new_values"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(userProfiles),
  devices: many(devices),
  vitals: many(vitals),
  aiEvents: many(aiEvents),
  emergencyEvents: many(emergencyEvents),
}));

export const userProfilesRelations = relations(userProfiles, ({ one }) => ({
  user: one(users, { fields: [userProfiles.userId], references: [users.id] }),
}));

export const devicesRelations = relations(devices, ({ one, many }) => ({
  user: one(users, { fields: [devices.userId], references: [users.id] }),
  vitals: many(vitals),
}));

export const vitalsRelations = relations(vitals, ({ one }) => ({
  user: one(users, { fields: [vitals.userId], references: [users.id] }),
  device: one(devices, { fields: [vitals.deviceId], references: [devices.id] }),
}));

export const aiEventsRelations = relations(aiEvents, ({ one, many }) => ({
  user: one(users, { fields: [aiEvents.userId], references: [users.id] }),
  emergencyEvents: many(emergencyEvents),
}));

export const emergencyEventsRelations = relations(emergencyEvents, ({ one }) => ({
  user: one(users, { fields: [emergencyEvents.userId], references: [users.id] }),
  aiEvent: one(aiEvents, { fields: [emergencyEvents.aiEventId], references: [aiEvents.id] }),
}));

// Zod schemas
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  passwordHash: true,
}).extend({
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export const insertUserProfileSchema = createInsertSchema(userProfiles).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDeviceSchema = createInsertSchema(devices).omit({
  id: true,
  userId: true,
  createdAt: true,
});

export const insertVitalsSchema = createInsertSchema(vitals).omit({
  id: true,
  userId: true,
  createdAt: true,
});

export const vitalsPayloadSchema = z.object({
  userId: z.string().uuid(),
  deviceId: z.string(),
  timestamp: z.string().datetime(),
  vitals: z.object({
    heartRate: z.number().int().min(30).max(220).optional(),
    bloodPressure: z.object({
      systolic: z.number().int().min(70).max(300),
      diastolic: z.number().int().min(40).max(200),
    }).optional(),
    spO2: z.number().int().min(70).max(100).optional(),
    sleep: z.object({
      start: z.string().datetime(),
      end: z.string().datetime(),
      stages: z.object({
        deep: z.number().min(0),
        light: z.number().min(0),
        rem: z.number().min(0),
      }),
    }).optional(),
  }),
  source: z.enum(["googlefit", "webbluetooth", "simulated"]),
});

export const geminiOutputSchema = z.object({
  immediate_emergency: z.boolean(),
  risk_score: z.number().min(0).max(100),
  recommended_action: z.enum(["call_ambulance", "go_er", "see_gp", "self_care", "follow_up"]),
  confidence: z.number().min(0).max(1),
  explanation: z.string(),
  contributing_factors: z.array(z.string()),
  structured_alert_text: z.string(),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type Device = typeof devices.$inferSelect;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;
export type Vitals = typeof vitals.$inferSelect;
export type InsertVitals = z.infer<typeof insertVitalsSchema>;
export type VitalsPayload = z.infer<typeof vitalsPayloadSchema>;
export type AiEvent = typeof aiEvents.$inferSelect;
export type EmergencyEvent = typeof emergencyEvents.$inferSelect;
export type GeminiOutput = z.infer<typeof geminiOutputSchema>;
export type EmailLog = typeof emailLogs.$inferSelect;
export type SmsLog = typeof smsLogs.$inferSelect;
export type AuditLog = typeof auditLogs.$inferSelect;

import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useWebBluetooth } from "@/hooks/use-web-bluetooth";
import { Navigation } from "@/components/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { apiRequest, queryClient } from "@/lib/api";
import { 
  Bluetooth, 
  Smartphone, 
  RefreshCw, 
  Plus, 
  AlertCircle, 
  CheckCircle, 
  Wifi,
  Settings 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Devices() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isConnectingGoogleFit, setIsConnectingGoogleFit] = useState(false);

  // Web Bluetooth hook
  const {
    isSupported: bluetoothSupported,
    isScanning,
    connectedDevice,
    lastReading,
    error: bluetoothError,
    scanForDevices,
    disconnect: disconnectBluetooth,
  } = useWebBluetooth({
    onVitalReading: (reading) => {
      toast({
        title: "New Vital Reading",
        description: `Heart Rate: ${reading.heartRate || 'N/A'} bpm`,
      });
    },
    onConnectionChange: (connected, device) => {
      if (connected && device) {
        toast({
          title: "Device Connected",
          description: `Successfully connected to ${device.name}`,
        });
        queryClient.invalidateQueries({ queryKey: ['/api/devices'] });
      }
    },
  });

  // Fetch devices
  const { data: devices = [], isLoading } = useQuery({
    queryKey: ['/api/devices'],
    enabled: !!user,
  });

  // Google Fit auth mutation
  const googleFitAuthMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('GET', '/api/auth/googlefit');
      const data = await response.json();
      return data.authUrl;
    },
    onSuccess: (authUrl) => {
      window.location.href = authUrl;
    },
    onError: (error: any) => {
      toast({
        title: "Google Fit Connection Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Sync Google Fit mutation
  const syncGoogleFitMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/sync/googlefit');
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Sync Complete",
        description: `Synced ${data.synced} vital readings from Google Fit`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/vitals'] });
    },
    onError: (error: any) => {
      toast({
        title: "Sync Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleConnectGoogleFit = () => {
    setIsConnectingGoogleFit(true);
    googleFitAuthMutation.mutate();
  };

  const handleSyncGoogleFit = () => {
    syncGoogleFitMutation.mutate();
  };

  const googleFitDevice = devices.find(d => d.deviceType === 'google_fit');
  const bluetoothDevices = devices.filter(d => d.deviceType === 'web_bluetooth');

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex items-center justify-center h-96">
          <RefreshCw className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground" data-testid="text-devices-title">
            Device Management
          </h1>
          <p className="mt-2 text-muted-foreground">
            Connect and manage your health monitoring devices
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Google Fit Integration */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i className="fab fa-google text-blue-600 text-xl"></i>
                  </div>
                  <span>Google Fit Integration</span>
                </CardTitle>
                {googleFitDevice && (
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    Connected
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {googleFitDevice ? (
                <div className="space-y-4">
                  {/* Connection Status */}
                  <div className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div>
                      <p className="font-medium text-green-800">Connected</p>
                      <p className="text-sm text-green-600">
                        Last sync: {googleFitDevice.lastSeen ? 
                          new Date(googleFitDevice.lastSeen).toLocaleString() : 
                          'Never'
                        }
                      </p>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </div>

                  {/* Permissions */}
                  <div>
                    <h4 className="font-medium text-foreground mb-2">Data Permissions</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-foreground">Heart Rate</span>
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-foreground">Blood Pressure</span>
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-foreground">Sleep Data</span>
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      </div>
                    </div>
                  </div>

                  <Button 
                    onClick={handleSyncGoogleFit}
                    disabled={syncGoogleFitMutation.isPending}
                    className="w-full"
                    data-testid="button-sync-googlefit"
                  >
                    <RefreshCw className={`w-4 h-4 mr-2 ${syncGoogleFitMutation.isPending ? 'animate-spin' : ''}`} />
                    {syncGoogleFitMutation.isPending ? 'Syncing...' : 'Sync Now'}
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-muted-foreground">
                    Connect Google Fit to automatically import your health data including heart rate, 
                    blood pressure, and sleep information.
                  </p>

                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-medium text-blue-800 mb-2">Available Data Types:</h4>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>• Heart Rate measurements</li>
                      <li>• Blood Pressure readings</li>
                      <li>• Sleep duration and stages</li>
                      <li>• Activity and workout data</li>
                    </ul>
                  </div>

                  <Button 
                    onClick={handleConnectGoogleFit}
                    disabled={isConnectingGoogleFit || googleFitAuthMutation.isPending}
                    className="w-full"
                    data-testid="button-connect-googlefit"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    {googleFitAuthMutation.isPending ? 'Connecting...' : 'Connect Google Fit'}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Web Bluetooth Devices */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Bluetooth className="w-5 h-5 text-purple-600" />
                  </div>
                  <span>Bluetooth Devices</span>
                </CardTitle>
                {connectedDevice && (
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    Connected
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              
              {/* Browser Support Warning */}
              {!bluetoothSupported && (
                <Alert variant="destructive">
                  <AlertCircle className="w-4 h-4" />
                  <AlertDescription>
                    Web Bluetooth is only supported in Chrome and Edge browsers. Please switch browsers to use this feature.
                  </AlertDescription>
                </Alert>
              )}

              {bluetoothSupported && bluetoothError && (
                <Alert variant="destructive">
                  <AlertCircle className="w-4 h-4" />
                  <AlertDescription>{bluetoothError}</AlertDescription>
                </Alert>
              )}

              {/* Connected Device */}
              {connectedDevice && (
                <div className="flex items-center justify-between p-4 bg-purple-50 border border-purple-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Bluetooth className="w-5 h-5 text-purple-600" />
                    <div>
                      <p className="font-medium text-purple-800">{connectedDevice.name}</p>
                      <p className="text-sm text-purple-600">
                        {connectedDevice.services.join(', ')} • Connected
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={disconnectBluetooth}
                      data-testid="button-disconnect-bluetooth"
                    >
                      Disconnect
                    </Button>
                  </div>
                </div>
              )}

              {/* Latest Reading */}
              {lastReading && (
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium text-foreground mb-2">Latest Reading</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    {lastReading.heartRate && (
                      <div>
                        <span className="text-muted-foreground">Heart Rate:</span>
                        <span className="ml-2 font-medium text-foreground">{lastReading.heartRate} bpm</span>
                      </div>
                    )}
                    {lastReading.bloodPressure && (
                      <div>
                        <span className="text-muted-foreground">Blood Pressure:</span>
                        <span className="ml-2 font-medium text-foreground">
                          {lastReading.bloodPressure.systolic}/{lastReading.bloodPressure.diastolic} mmHg
                        </span>
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    {lastReading.timestamp.toLocaleString()}
                  </p>
                </div>
              )}

              {/* Scan for Devices */}
              {bluetoothSupported && (
                <Button 
                  onClick={scanForDevices}
                  disabled={isScanning}
                  variant={connectedDevice ? "outline" : "default"}
                  className="w-full"
                  data-testid="button-scan-bluetooth"
                >
                  {isScanning ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Scanning...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      {connectedDevice ? 'Scan for More Devices' : 'Scan for Devices'}
                    </>
                  )}
                </Button>
              )}

              {/* Device Requirements */}
              <div className="p-4 bg-muted rounded-lg">
                <h4 className="font-medium text-foreground mb-2">Supported Devices</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Heart Rate monitors (BLE Heart Rate Service)</li>
                  <li>• Blood Pressure monitors (BLE Blood Pressure Service)</li>
                  <li>• Compatible fitness trackers</li>
                  <li>• Medical-grade BLE devices</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Device History */}
        {bluetoothDevices.length > 0 && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Device History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {bluetoothDevices.map((device) => (
                  <div key={device.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                        <Bluetooth className="w-5 h-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{device.deviceName}</p>
                        <p className="text-sm text-muted-foreground">
                          Last seen: {device.lastSeen ? 
                            new Date(device.lastSeen).toLocaleString() : 
                            'Never'
                          }
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={device.isActive ? "default" : "secondary"}>
                        {device.isActive ? "Active" : "Inactive"}
                      </Badge>
                      <Button variant="outline" size="sm">
                        <Settings className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}

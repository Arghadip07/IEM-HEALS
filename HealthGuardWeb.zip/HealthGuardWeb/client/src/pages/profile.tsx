import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Navigation } from "@/components/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest, queryClient } from "@/lib/api";
import { insertUserProfileSchema, type InsertUserProfile } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { 
  User, 
  Mail, 
  Phone, 
  Shield, 
  Heart, 
  Pill, 
  UserPlus, 
  Check, 
  X, 
  AlertCircle,
  Plus,
  Trash2
} from "lucide-react";
import { z } from "zod";

const phoneVerificationSchema = z.object({
  phone: z.string().regex(/^\+?[\d\s\-\(\)]+$/, "Invalid phone number format"),
});

const phoneConfirmationSchema = z.object({
  code: z.string().length(4, "Code must be 4 digits"),
});

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isVerifyingPhone, setIsVerifyingPhone] = useState(false);
  const [phoneToVerify, setPhoneToVerify] = useState("");

  // Fetch user profile
  const { data: profile, isLoading } = useQuery({
    queryKey: ['/api/profile'],
    enabled: !!user,
  });

  // Profile form
  const profileForm = useForm<InsertUserProfile>({
    resolver: zodResolver(insertUserProfileSchema),
    defaultValues: {
      fullName: "",
      preferredName: "",
      gender: undefined,
      dateOfBirth: undefined,
      heightCm: "",
      weightKg: "",
      allergies: [],
      medicalHistory: { conditions: [], notes: "" },
      medications: [],
      emergencyContacts: [],
      consent: {
        healthDataCollection: { granted: false, timestamp: "" },
        locationSharing: { granted: false, timestamp: "" },
        emergencyContactNotification: { granted: false, timestamp: "" },
      },
    },
  });

  // Phone verification form
  const phoneForm = useForm({
    resolver: zodResolver(phoneVerificationSchema),
    defaultValues: { phone: "" },
  });

  const phoneConfirmForm = useForm({
    resolver: zodResolver(phoneConfirmationSchema),
    defaultValues: { code: "" },
  });

  // Medications field array
  const { fields: medicationFields, append: addMedication, remove: removeMedication } = useFieldArray({
    control: profileForm.control,
    name: "medications",
  });

  // Emergency contacts field array
  const { fields: contactFields, append: addContact, remove: removeContact } = useFieldArray({
    control: profileForm.control,
    name: "emergencyContacts",
  });

  // Load profile data when available
  React.useEffect(() => {
    if (profile) {
      profileForm.reset({
        fullName: profile.fullName || "",
        preferredName: profile.preferredName || "",
        gender: profile.gender,
        dateOfBirth: profile.dateOfBirth ? new Date(profile.dateOfBirth) : undefined,
        heightCm: profile.heightCm?.toString() || "",
        weightKg: profile.weightKg?.toString() || "",
        allergies: profile.allergies || [],
        medicalHistory: profile.medicalHistory || { conditions: [], notes: "" },
        medications: profile.medications || [],
        emergencyContacts: profile.emergencyContacts || [],
        consent: profile.consent || {
          healthDataCollection: { granted: false, timestamp: "" },
          locationSharing: { granted: false, timestamp: "" },
          emergencyContactNotification: { granted: false, timestamp: "" },
        },
      });
    }
  }, [profile, profileForm]);

  // Save profile mutation
  const saveProfileMutation = useMutation({
    mutationFn: async (data: InsertUserProfile) => {
      const response = await apiRequest('POST', '/api/profile', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile Updated",
        description: "Your medical profile has been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
    },
    onError: (error: any) => {
      toast({
        title: "Save Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Phone verification mutation
  const verifyPhoneMutation = useMutation({
    mutationFn: async (data: { phone: string }) => {
      const response = await apiRequest('POST', '/api/verify-phone', data);
      return response.json();
    },
    onSuccess: (_, variables) => {
      setIsVerifyingPhone(true);
      setPhoneToVerify(variables.phone);
      toast({
        title: "Verification Code Sent",
        description: "Please check your phone for the 4-digit verification code.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Verification Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Phone confirmation mutation
  const confirmPhoneMutation = useMutation({
    mutationFn: async (data: { code: string }) => {
      const response = await apiRequest('POST', '/api/confirm-phone', data);
      return response.json();
    },
    onSuccess: () => {
      setIsVerifyingPhone(false);
      setPhoneToVerify("");
      toast({
        title: "Phone Verified",
        description: "Your phone number has been verified successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
    },
    onError: (error: any) => {
      toast({
        title: "Verification Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSaveProfile = (data: InsertUserProfile) => {
    // Update consent timestamps
    const updatedData = {
      ...data,
      consent: {
        healthDataCollection: {
          granted: data.consent?.healthDataCollection?.granted || false,
          timestamp: data.consent?.healthDataCollection?.granted ? new Date().toISOString() : "",
        },
        locationSharing: {
          granted: data.consent?.locationSharing?.granted || false,
          timestamp: data.consent?.locationSharing?.granted ? new Date().toISOString() : "",
        },
        emergencyContactNotification: {
          granted: data.consent?.emergencyContactNotification?.granted || false,
          timestamp: data.consent?.emergencyContactNotification?.granted ? new Date().toISOString() : "",
        },
      },
    };
    saveProfileMutation.mutate(updatedData);
  };

  const onVerifyPhone = (data: { phone: string }) => {
    verifyPhoneMutation.mutate(data);
  };

  const onConfirmPhone = (data: { code: string }) => {
    confirmPhoneMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading profile...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground" data-testid="text-profile-title">
            Medical Profile
          </h1>
          <p className="mt-2 text-muted-foreground">
            Manage your personal information, medical history, and emergency contacts
          </p>
        </div>

        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="personal" data-testid="tab-personal">Personal Info</TabsTrigger>
            <TabsTrigger value="medical" data-testid="tab-medical">Medical History</TabsTrigger>
            <TabsTrigger value="emergency" data-testid="tab-emergency">Emergency Contacts</TabsTrigger>
            <TabsTrigger value="security" data-testid="tab-security">Security & Privacy</TabsTrigger>
          </TabsList>

          <Form {...profileForm}>
            <form onSubmit={profileForm.handleSubmit(onSaveProfile)} className="space-y-6">
              
              {/* Personal Information */}
              <TabsContent value="personal" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <User className="w-5 h-5" />
                      <span>Basic Information</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={profileForm.control}
                        name="fullName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name *</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Enter your full name"
                                data-testid="input-full-name"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={profileForm.control}
                        name="preferredName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Preferred Name</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="What should we call you?"
                                data-testid="input-preferred-name"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <FormField
                        control={profileForm.control}
                        name="gender"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Gender</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-gender">
                                  <SelectValue placeholder="Select gender" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="male">Male</SelectItem>
                                <SelectItem value="female">Female</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                                <SelectItem value="prefer_not_to_say">Prefer not to say</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={profileForm.control}
                        name="heightCm"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Height (cm)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="175"
                                data-testid="input-height"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={profileForm.control}
                        name="weightKg"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Weight (kg)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="70"
                                data-testid="input-weight"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={profileForm.control}
                      name="dateOfBirth"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date of Birth</FormLabel>
                          <FormControl>
                            <Input 
                              type="date"
                              data-testid="input-date-of-birth"
                              value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''}
                              onChange={(e) => field.onChange(e.target.value ? new Date(e.target.value) : undefined)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Medical History */}
              <TabsContent value="medical" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Heart className="w-5 h-5" />
                      <span>Medical Conditions & Allergies</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={profileForm.control}
                      name="medicalHistory.notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Medical History Notes</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe any significant medical history, conditions, or concerns..."
                              className="min-h-24"
                              data-testid="textarea-medical-history"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Pill className="w-5 h-5" />
                        <span>Current Medications</span>
                      </div>
                      <Button 
                        type="button"
                        variant="outline" 
                        size="sm"
                        onClick={() => addMedication({ name: "", dosage: "", frequency: "" })}
                        data-testid="button-add-medication"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Medication
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {medicationFields.map((field, index) => (
                      <div key={field.id} className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 border rounded-lg">
                        <FormField
                          control={profileForm.control}
                          name={`medications.${index}.name`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Medication Name</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g., Lisinopril"
                                  data-testid={`input-medication-name-${index}`}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={profileForm.control}
                          name={`medications.${index}.dosage`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Dosage</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g., 10mg"
                                  data-testid={`input-medication-dosage-${index}`}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={profileForm.control}
                          name={`medications.${index}.frequency`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Frequency</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g., Daily"
                                  data-testid={`input-medication-frequency-${index}`}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="flex items-end">
                          <Button 
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => removeMedication(index)}
                            data-testid={`button-remove-medication-${index}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    {medicationFields.length === 0 && (
                      <p className="text-muted-foreground text-center py-4">
                        No medications added yet. Click "Add Medication" to start.
                      </p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Emergency Contacts */}
              <TabsContent value="emergency" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <UserPlus className="w-5 h-5" />
                        <span>Emergency Contacts</span>
                      </div>
                      <Button 
                        type="button"
                        variant="outline" 
                        size="sm"
                        onClick={() => addContact({ name: "", relationship: "", phone: "", email: "" })}
                        data-testid="button-add-emergency-contact"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Contact
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {contactFields.map((field, index) => (
                      <div key={field.id} className="grid grid-cols-1 md:grid-cols-5 gap-4 p-4 border rounded-lg">
                        <FormField
                          control={profileForm.control}
                          name={`emergencyContacts.${index}.name`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Name</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Contact name"
                                  data-testid={`input-contact-name-${index}`}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={profileForm.control}
                          name={`emergencyContacts.${index}.relationship`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Relationship</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g., Spouse"
                                  data-testid={`input-contact-relationship-${index}`}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={profileForm.control}
                          name={`emergencyContacts.${index}.phone`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="+1 (555) 123-4567"
                                  data-testid={`input-contact-phone-${index}`}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={profileForm.control}
                          name={`emergencyContacts.${index}.email`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input 
                                  type="email"
                                  placeholder="contact@email.com"
                                  data-testid={`input-contact-email-${index}`}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="flex items-end">
                          <Button 
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => removeContact(index)}
                            data-testid={`button-remove-contact-${index}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    {contactFields.length === 0 && (
                      <p className="text-muted-foreground text-center py-4">
                        No emergency contacts added yet. Click "Add Contact" to start.
                      </p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Security & Privacy */}
              <TabsContent value="security" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Mail className="w-5 h-5" />
                      <span>Email Verification</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Check className="w-5 h-5 text-green-600" />
                        <div>
                          <p className="font-medium text-green-800">Email Verified</p>
                          <p className="text-sm text-green-600">{user?.email}</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        Verified
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Phone className="w-5 h-5" />
                      <span>Phone Verification</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {user?.phoneVerified ? (
                      <div className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Check className="w-5 h-5 text-green-600" />
                          <div>
                            <p className="font-medium text-green-800">Phone Verified</p>
                            <p className="text-sm text-green-600">{user.phone}</p>
                          </div>
                        </div>
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          Verified
                        </Badge>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {!isVerifyingPhone ? (
                          <Form {...phoneForm}>
                            <form onSubmit={phoneForm.handleSubmit(onVerifyPhone)} className="space-y-4">
                              <div className="flex items-center justify-between p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                                <div className="flex items-center space-x-3">
                                  <AlertCircle className="w-5 h-5 text-yellow-600" />
                                  <div>
                                    <p className="font-medium text-yellow-800">Phone Verification Recommended</p>
                                    <p className="text-sm text-yellow-600">Add phone for SMS emergency alerts</p>
                                  </div>
                                </div>
                              </div>
                              <FormField
                                control={phoneForm.control}
                                name="phone"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Phone Number</FormLabel>
                                    <FormControl>
                                      <Input 
                                        placeholder="+1 (555) 123-4567"
                                        data-testid="input-phone-verification"
                                        {...field} 
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <Button 
                                type="submit" 
                                disabled={verifyPhoneMutation.isPending}
                                data-testid="button-verify-phone"
                              >
                                {verifyPhoneMutation.isPending ? "Sending Code..." : "Send Verification Code"}
                              </Button>
                            </form>
                          </Form>
                        ) : (
                          <Form {...phoneConfirmForm}>
                            <form onSubmit={phoneConfirmForm.handleSubmit(onConfirmPhone)} className="space-y-4">
                              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                                <p className="text-sm text-blue-800">
                                  We sent a 4-digit verification code to <strong>{phoneToVerify}</strong>
                                </p>
                              </div>
                              <FormField
                                control={phoneConfirmForm.control}
                                name="code"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Verification Code</FormLabel>
                                    <FormControl>
                                      <Input 
                                        placeholder="Enter 4-digit code"
                                        maxLength={4}
                                        data-testid="input-phone-confirmation-code"
                                        {...field} 
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <div className="flex space-x-2">
                                <Button 
                                  type="submit" 
                                  disabled={confirmPhoneMutation.isPending}
                                  data-testid="button-confirm-phone"
                                >
                                  {confirmPhoneMutation.isPending ? "Verifying..." : "Verify Code"}
                                </Button>
                                <Button 
                                  type="button" 
                                  variant="outline"
                                  onClick={() => setIsVerifyingPhone(false)}
                                  data-testid="button-cancel-phone-verification"
                                >
                                  Cancel
                                </Button>
                              </div>
                            </form>
                          </Form>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Shield className="w-5 h-5" />
                      <span>Privacy Consents</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={profileForm.control}
                      name="consent.healthDataCollection.granted"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              data-testid="checkbox-health-data-consent"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Health data collection and analysis</FormLabel>
                            <p className="text-sm text-muted-foreground">
                              Allow HealthGuard to collect and analyze your health data for insights and emergency detection.
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={profileForm.control}
                      name="consent.locationSharing.granted"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              data-testid="checkbox-location-consent"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Location sharing for emergency services</FormLabel>
                            <p className="text-sm text-muted-foreground">
                              Share your location with emergency contacts and services during emergency situations.
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={profileForm.control}
                      name="consent.emergencyContactNotification.granted"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              data-testid="checkbox-emergency-contact-consent"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Emergency contact notifications</FormLabel>
                            <p className="text-sm text-muted-foreground">
                              Automatically notify your emergency contacts during health emergencies.
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              </TabsContent>

              <div className="flex justify-end space-x-4">
                <Button 
                  type="submit" 
                  disabled={saveProfileMutation.isPending}
                  data-testid="button-save-profile"
                >
                  {saveProfileMutation.isPending ? "Saving..." : "Save Profile"}
                </Button>
              </div>
            </form>
          </Form>
        </Tabs>
      </main>
    </div>
  );
}

import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Navigation } from "@/components/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { VitalsChart } from "@/components/vitals-chart";
import { 
  Activity,
  Calendar as CalendarIcon,
  Download,
  Filter,
  Heart,
  Gauge,
  Moon,
  Brain,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Search
} from "lucide-react";
import { format, subDays, subMonths, subWeeks } from "date-fns";

const VITAL_TYPES = [
  { value: "heart_rate", label: "Heart Rate", icon: Heart, color: "text-red-500" },
  { value: "blood_pressure", label: "Blood Pressure", icon: Gauge, color: "text-blue-500" },
  { value: "spO2", label: "Blood Oxygen", icon: Activity, color: "text-cyan-500" },
  { value: "sleep", label: "Sleep", icon: Moon, color: "text-indigo-500" },
];

const TIME_RANGES = [
  { value: "7d", label: "Last 7 days", getDates: () => ({ from: subDays(new Date(), 7), to: new Date() }) },
  { value: "30d", label: "Last 30 days", getDates: () => ({ from: subDays(new Date(), 30), to: new Date() }) },
  { value: "3m", label: "Last 3 months", getDates: () => ({ from: subMonths(new Date(), 3), to: new Date() }) },
  { value: "6m", label: "Last 6 months", getDates: () => ({ from: subMonths(new Date(), 6), to: new Date() }) },
  { value: "custom", label: "Custom range", getDates: () => null },
];

export default function History() {
  const { user } = useAuth();
  const [selectedVitalType, setSelectedVitalType] = useState<string>("all");
  const [selectedTimeRange, setSelectedTimeRange] = useState("30d");
  const [customDateRange, setCustomDateRange] = useState<{ from?: Date; to?: Date }>({});
  const [searchTerm, setSearchTerm] = useState("");

  // Calculate date range
  const dateRange = useMemo(() => {
    if (selectedTimeRange === "custom") {
      return customDateRange.from && customDateRange.to 
        ? { from: customDateRange.from, to: customDateRange.to }
        : null;
    }
    const range = TIME_RANGES.find(r => r.value === selectedTimeRange);
    return range?.getDates() || null;
  }, [selectedTimeRange, customDateRange]);

  // Fetch vitals data
  const { data: vitals = [], isLoading } = useQuery({
    queryKey: ['/api/vitals', { 
      type: selectedVitalType !== "all" ? selectedVitalType : undefined,
      from: dateRange?.from?.toISOString(),
      to: dateRange?.to?.toISOString(),
    }],
    enabled: !!user && !!dateRange,
  });

  // Fetch AI events
  const { data: aiEvents = [] } = useQuery({
    queryKey: ['/api/ai/events'],
    enabled: !!user,
  });

  // Process vitals data for statistics
  const vitalStats = useMemo(() => {
    const stats: Record<string, any> = {};
    
    VITAL_TYPES.forEach(({ value: type }) => {
      const typeVitals = vitals.filter(v => v.vitalType === type);
      
      if (typeVitals.length > 0) {
        let values: number[] = [];
        
        typeVitals.forEach(vital => {
          if (type === "heart_rate" && vital.value.heartRate) {
            values.push(vital.value.heartRate);
          } else if (type === "spO2" && vital.value.spO2) {
            values.push(vital.value.spO2);
          } else if (type === "blood_pressure" && vital.value.bloodPressure) {
            // Use systolic for trends
            values.push(vital.value.bloodPressure.systolic);
          } else if (type === "sleep" && vital.value.sleep) {
            // Calculate total sleep duration in hours
            const { deep, light, rem } = vital.value.sleep.stages;
            values.push((deep + light + rem) / 60);
          }
        });

        if (values.length > 0) {
          stats[type] = {
            count: values.length,
            min: Math.min(...values),
            max: Math.max(...values),
            avg: values.reduce((a, b) => a + b, 0) / values.length,
            latest: values[values.length - 1],
            trend: values.length > 1 ? 
              (values[values.length - 1] > values[values.length - 2] ? "up" : "down") : 
              "stable",
          };
        }
      }
    });
    
    return stats;
  }, [vitals]);

  const handleExportData = () => {
    const csvData = vitals.map(vital => ({
      timestamp: new Date(vital.timestamp).toISOString(),
      type: vital.vitalType,
      value: JSON.stringify(vital.value),
      source: vital.source,
    }));

    const csvContent = [
      ["Timestamp", "Type", "Value", "Source"],
      ...csvData.map(row => [row.timestamp, row.type, row.value, row.source])
    ].map(row => row.join(",")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `healthguard-vitals-${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading health history...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground" data-testid="text-history-title">
                Health History & Reports
              </h1>
              <p className="mt-2 text-muted-foreground">
                View trends, analyze patterns, and export your health data
              </p>
            </div>
            <div className="mt-4 sm:mt-0 flex items-center space-x-3">
              <Button variant="outline" onClick={handleExportData} data-testid="button-export-data">
                <Download className="w-4 h-4 mr-2" />
                Export Data
              </Button>
            </div>
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-medium">Filters:</span>
              </div>
              
              <Select value={selectedVitalType} onValueChange={setSelectedVitalType}>
                <SelectTrigger className="w-48" data-testid="select-vital-type">
                  <SelectValue placeholder="Select vital type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Vitals</SelectItem>
                  {VITAL_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
                <SelectTrigger className="w-48" data-testid="select-time-range">
                  <SelectValue placeholder="Select time range" />
                </SelectTrigger>
                <SelectContent>
                  {TIME_RANGES.map(range => (
                    <SelectItem key={range.value} value={range.value}>
                      {range.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedTimeRange === "custom" && (
                <div className="flex items-center space-x-2">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" data-testid="button-from-date">
                        <CalendarIcon className="w-4 h-4 mr-2" />
                        {customDateRange.from ? format(customDateRange.from, "MMM dd, yyyy") : "From date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={customDateRange.from}
                        onSelect={(date) => setCustomDateRange(prev => ({ ...prev, from: date }))}
                      />
                    </PopoverContent>
                  </Popover>
                  
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" data-testid="button-to-date">
                        <CalendarIcon className="w-4 h-4 mr-2" />
                        {customDateRange.to ? format(customDateRange.to, "MMM dd, yyyy") : "To date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={customDateRange.to}
                        onSelect={(date) => setCustomDateRange(prev => ({ ...prev, to: date }))}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              )}

              <div className="flex items-center space-x-2 flex-1 max-w-xs">
                <Search className="w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="Search events..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  data-testid="input-search-events"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="vitals" data-testid="tab-vitals">Vital Signs</TabsTrigger>
            <TabsTrigger value="ai-analysis" data-testid="tab-ai-analysis">AI Analysis</TabsTrigger>
            <TabsTrigger value="trends" data-testid="tab-trends">Trends</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Statistics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {VITAL_TYPES.map(({ value: type, label, icon: Icon, color }) => {
                const stats = vitalStats[type];
                return (
                  <Card key={type}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-medium text-muted-foreground">{label}</h3>
                          {stats ? (
                            <>
                              <div className="text-2xl font-bold text-foreground mt-1">
                                {type === "sleep" ? `${stats.avg.toFixed(1)}h` :
                                 type === "blood_pressure" ? `${stats.avg.toFixed(0)}` :
                                 `${stats.avg.toFixed(0)}`}
                              </div>
                              <div className="flex items-center mt-1">
                                {stats.trend === "up" ? (
                                  <TrendingUp className="w-3 h-3 text-green-500 mr-1" />
                                ) : stats.trend === "down" ? (
                                  <TrendingDown className="w-3 h-3 text-red-500 mr-1" />
                                ) : null}
                                <span className="text-xs text-muted-foreground">
                                  {stats.count} readings
                                </span>
                              </div>
                            </>
                          ) : (
                            <div className="text-2xl font-bold text-muted-foreground mt-1">--</div>
                          )}
                        </div>
                        <Icon className={`w-8 h-8 ${color}`} />
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Chart */}
            <VitalsChart dateRange={dateRange} vitalType={selectedVitalType !== "all" ? selectedVitalType : undefined} />
          </TabsContent>

          {/* Vitals Tab */}
          <TabsContent value="vitals" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Vital Signs Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {vitals.length > 0 ? (
                    vitals.slice(0, 50).map((vital) => (
                      <div key={vital.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                            {(() => {
                              const vitalType = VITAL_TYPES.find(t => t.value === vital.vitalType);
                              const Icon = vitalType?.icon || Activity;
                              return <Icon className={`w-5 h-5 ${vitalType?.color || "text-muted-foreground"}`} />;
                            })()}
                          </div>
                          <div>
                            <p className="font-medium text-foreground">
                              {VITAL_TYPES.find(t => t.value === vital.vitalType)?.label || vital.vitalType}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(vital.timestamp).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-foreground">
                            {vital.vitalType === "heart_rate" && vital.value.heartRate ? 
                              `${vital.value.heartRate} bpm` :
                             vital.vitalType === "blood_pressure" && vital.value.bloodPressure ?
                              `${vital.value.bloodPressure.systolic}/${vital.value.bloodPressure.diastolic} mmHg` :
                             vital.vitalType === "spO2" && vital.value.spO2 ?
                              `${vital.value.spO2}%` :
                             vital.vitalType === "sleep" && vital.value.sleep ?
                              `${((vital.value.sleep.stages.deep + vital.value.sleep.stages.light + vital.value.sleep.stages.rem) / 60).toFixed(1)}h` :
                              "N/A"
                            }
                          </p>
                          <Badge variant="outline" className="text-xs">
                            {vital.source}
                          </Badge>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      No vital signs data found for the selected period.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* AI Analysis Tab */}
          <TabsContent value="ai-analysis" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="w-5 h-5" />
                  <span>AI Health Analysis History</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {aiEvents.length > 0 ? (
                    aiEvents.map((event) => (
                      <div key={event.id} className="p-4 border rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                              event.aiOutput.immediateEmergency ? "bg-red-100" :
                              event.aiOutput.riskScore > 70 ? "bg-yellow-100" :
                              "bg-green-100"
                            }`}>
                              {event.aiOutput.immediateEmergency ? (
                                <AlertTriangle className="w-5 h-5 text-red-600" />
                              ) : (
                                <Brain className="w-5 h-5 text-blue-600" />
                              )}
                            </div>
                            <div>
                              <p className="font-medium text-foreground">
                                Risk Score: {event.aiOutput.riskScore}/100
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {new Date(event.createdAt).toLocaleString()}
                              </p>
                            </div>
                          </div>
                          <Badge variant={
                            event.aiOutput.immediateEmergency ? "destructive" :
                            event.aiOutput.riskScore > 70 ? "default" :
                            "secondary"
                          }>
                            {event.aiOutput.recommendedAction.replace("_", " ").toUpperCase()}
                          </Badge>
                        </div>
                        
                        <div className="space-y-2">
                          <p className="text-sm text-foreground">{event.aiOutput.explanation}</p>
                          
                          {event.aiOutput.contributingFactors.length > 0 && (
                            <div>
                              <span className="text-xs text-muted-foreground">Contributing factors: </span>
                              <span className="text-xs text-foreground">
                                {event.aiOutput.contributingFactors.join(", ")}
                              </span>
                            </div>
                          )}
                          
                          <div className="flex justify-between items-center text-xs text-muted-foreground">
                            <span>Confidence: {(event.aiOutput.confidence * 100).toFixed(1)}%</span>
                            <span>Processing: {event.processingTimeMs}ms</span>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      No AI analysis events found.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Trends Tab */}
          <TabsContent value="trends" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {VITAL_TYPES.map(({ value: type, label, icon: Icon, color }) => {
                const stats = vitalStats[type];
                return (
                  <Card key={type}>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Icon className={`w-5 h-5 ${color}`} />
                        <span>{label} Trends</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {stats ? (
                        <div className="space-y-4">
                          <div className="grid grid-cols-3 gap-4">
                            <div className="text-center">
                              <p className="text-2xl font-bold text-foreground">
                                {type === "sleep" ? `${stats.min.toFixed(1)}h` : stats.min.toFixed(0)}
                              </p>
                              <p className="text-xs text-muted-foreground">Minimum</p>
                            </div>
                            <div className="text-center">
                              <p className="text-2xl font-bold text-foreground">
                                {type === "sleep" ? `${stats.avg.toFixed(1)}h` : stats.avg.toFixed(0)}
                              </p>
                              <p className="text-xs text-muted-foreground">Average</p>
                            </div>
                            <div className="text-center">
                              <p className="text-2xl font-bold text-foreground">
                                {type === "sleep" ? `${stats.max.toFixed(1)}h` : stats.max.toFixed(0)}
                              </p>
                              <p className="text-xs text-muted-foreground">Maximum</p>
                            </div>
                          </div>
                          
                          <div className="pt-4 border-t">
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-muted-foreground">
                                {stats.count} readings over {selectedTimeRange}
                              </span>
                              <div className="flex items-center space-x-1">
                                {stats.trend === "up" ? (
                                  <TrendingUp className="w-4 h-4 text-green-500" />
                                ) : stats.trend === "down" ? (
                                  <TrendingDown className="w-4 h-4 text-red-500" />
                                ) : null}
                                <span className="text-sm font-medium text-foreground capitalize">
                                  {stats.trend}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-8 text-muted-foreground">
                          No data available for {label.toLowerCase()} in the selected period.
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

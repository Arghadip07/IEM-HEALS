import { useState, useCallback, useRef, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

export interface BluetoothDevice {
  id: string;
  name: string;
  connected: boolean;
  services: string[];
  lastSeen?: Date;
}

export interface VitalReading {
  heartRate?: number;
  bloodPressure?: {
    systolic: number;
    diastolic: number;
  };
  timestamp: Date;
}

export interface UseWebBluetoothOptions {
  onVitalReading?: (reading: VitalReading) => void;
  onConnectionChange?: (connected: boolean, device?: BluetoothDevice) => void;
  autoReconnect?: boolean;
}

const HEART_RATE_SERVICE = 0x180D;
const HEART_RATE_CHARACTERISTIC = 0x2A37;
const BLOOD_PRESSURE_SERVICE = 0x1810;
const BLOOD_PRESSURE_CHARACTERISTIC = 0x2A35;

export function useWebBluetooth(options: UseWebBluetoothOptions = {}) {
  const { onVitalReading, onConnectionChange, autoReconnect = true } = options;
  const { toast } = useToast();

  const [isSupported, setIsSupported] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [connectedDevice, setConnectedDevice] = useState<BluetoothDevice | null>(null);
  const [lastReading, setLastReading] = useState<VitalReading | null>(null);
  const [error, setError] = useState<string | null>(null);

  const deviceRef = useRef<BluetoothDevice | null>(null);
  const characteristicRef = useRef<BluetoothRemoteGATTCharacteristic | null>(null);
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;

  // Check browser support
  useEffect(() => {
    const supported = 'bluetooth' in navigator;
    setIsSupported(supported);
    
    if (!supported) {
      setError('Web Bluetooth is not supported in this browser. Please use Chrome or Edge.');
    }
  }, []);

  // Load last connected device from IndexedDB
  useEffect(() => {
    loadLastDevice();
  }, []);

  const saveDeviceToStorage = useCallback(async (device: BluetoothDevice) => {
    try {
      // Store in IndexedDB for persistence
      const request = indexedDB.open('HealthGuardBluetooth', 1);
      
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('devices')) {
          db.createObjectStore('devices', { keyPath: 'id' });
        }
      };
      
      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction(['devices'], 'readwrite');
        const store = transaction.objectStore('devices');
        store.put(device);
      };
    } catch (error) {
      console.warn('Failed to save device to storage:', error);
    }
  }, []);

  const loadLastDevice = useCallback(async () => {
    try {
      const request = indexedDB.open('HealthGuardBluetooth', 1);
      
      request.onsuccess = () => {
        const db = request.result;
        if (db.objectStoreNames.contains('devices')) {
          const transaction = db.transaction(['devices'], 'readonly');
          const store = transaction.objectStore('devices');
          const getAllRequest = store.getAll();
          
          getAllRequest.onsuccess = () => {
            const devices = getAllRequest.result;
            if (devices.length > 0 && autoReconnect) {
              // Try to reconnect to the last device
              const lastDevice = devices[devices.length - 1];
              reconnectToDevice(lastDevice.id);
            }
          };
        }
      };
    } catch (error) {
      console.warn('Failed to load last device:', error);
    }
  }, [autoReconnect]);

  const scanForDevices = useCallback(async () => {
    if (!isSupported) {
      setError('Web Bluetooth not supported');
      return;
    }

    setIsScanning(true);
    setError(null);

    try {
      const device = await navigator.bluetooth.requestDevice({
        filters: [
          { services: [HEART_RATE_SERVICE] },
          { services: [BLOOD_PRESSURE_SERVICE] }
        ],
        optionalServices: [HEART_RATE_SERVICE, BLOOD_PRESSURE_SERVICE]
      });

      if (device) {
        await connectToDevice(device);
      }
    } catch (error: any) {
      console.error('Device scan error:', error);
      
      if (error.name === 'NotFoundError') {
        setError('No compatible devices found. Make sure your device is in pairing mode.');
      } else if (error.name === 'NotAllowedError') {
        setError('Bluetooth access denied. Please allow Bluetooth permissions.');
      } else {
        setError('Failed to scan for devices: ' + error.message);
      }
      
      toast({
        title: "Scan Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsScanning(false);
    }
  }, [isSupported, toast]);

  const connectToDevice = useCallback(async (bluetoothDevice: BluetoothDevice) => {
    try {
      const gatt = await bluetoothDevice.gatt?.connect();
      if (!gatt) throw new Error('Failed to connect to GATT server');

      const device: BluetoothDevice = {
        id: bluetoothDevice.id,
        name: bluetoothDevice.name || 'Unknown Device',
        connected: true,
        services: [],
        lastSeen: new Date(),
      };

      // Try to get heart rate service
      try {
        const heartRateService = await gatt.getPrimaryService(HEART_RATE_SERVICE);
        const heartRateCharacteristic = await heartRateService.getCharacteristic(HEART_RATE_CHARACTERISTIC);
        
        device.services.push('heart_rate');
        characteristicRef.current = heartRateCharacteristic;

        // Subscribe to heart rate notifications
        await heartRateCharacteristic.startNotifications();
        heartRateCharacteristic.addEventListener('characteristicvaluechanged', handleHeartRateData);
      } catch (error) {
        console.log('Heart rate service not available:', error);
      }

      // Try to get blood pressure service
      try {
        const bpService = await gatt.getPrimaryService(BLOOD_PRESSURE_SERVICE);
        const bpCharacteristic = await bpService.getCharacteristic(BLOOD_PRESSURE_CHARACTERISTIC);
        
        device.services.push('blood_pressure');
        
        await bpCharacteristic.startNotifications();
        bpCharacteristic.addEventListener('characteristicvaluechanged', handleBloodPressureData);
      } catch (error) {
        console.log('Blood pressure service not available:', error);
      }

      deviceRef.current = device;
      setConnectedDevice(device);
      setError(null);
      reconnectAttempts.current = 0;
      
      onConnectionChange?.(true, device);
      await saveDeviceToStorage(device);

      // Handle disconnection
      bluetoothDevice.addEventListener('gattserverdisconnected', handleDisconnection);

      toast({
        title: "Device Connected",
        description: `Successfully connected to ${device.name}`,
      });

    } catch (error: any) {
      console.error('Connection error:', error);
      setError('Failed to connect to device: ' + error.message);
      toast({
        title: "Connection Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  }, [onConnectionChange, toast, saveDeviceToStorage]);

  const handleHeartRateData = useCallback((event: Event) => {
    const characteristic = event.target as BluetoothRemoteGATTCharacteristic;
    const value = characteristic.value;
    
    if (!value) return;

    const heartRate = value.getUint16(1, true); // Little endian
    
    const reading: VitalReading = {
      heartRate,
      timestamp: new Date(),
    };

    setLastReading(reading);
    onVitalReading?.(reading);

    // Send to backend
    sendVitalToBackend(reading);
  }, [onVitalReading]);

  const handleBloodPressureData = useCallback((event: Event) => {
    const characteristic = event.target as BluetoothRemoteGATTCharacteristic;
    const value = characteristic.value;
    
    if (!value || value.byteLength < 7) return;

    const systolic = value.getUint16(1, true);
    const diastolic = value.getUint16(3, true);
    
    const reading: VitalReading = {
      bloodPressure: { systolic, diastolic },
      timestamp: new Date(),
    };

    setLastReading(reading);
    onVitalReading?.(reading);

    // Send to backend
    sendVitalToBackend(reading);
  }, [onVitalReading]);

  const sendVitalToBackend = useCallback(async (reading: VitalReading) => {
    try {
      const vitalsPayload = {
        vitals: [{
          userId: '', // Will be set by backend from authenticated user
          deviceId: deviceRef.current?.id || 'unknown',
          timestamp: reading.timestamp.toISOString(),
          vitals: {
            ...(reading.heartRate && { heartRate: reading.heartRate }),
            ...(reading.bloodPressure && { bloodPressure: reading.bloodPressure }),
          },
          source: 'webbluetooth' as const,
        }]
      };

      await apiRequest('POST', '/api/vitals', vitalsPayload);
    } catch (error) {
      console.error('Failed to send vital to backend:', error);
    }
  }, []);

  const handleDisconnection = useCallback(() => {
    setConnectedDevice(null);
    deviceRef.current = null;
    characteristicRef.current = null;
    onConnectionChange?.(false);

    toast({
      title: "Device Disconnected",
      description: "Bluetooth device has been disconnected",
      variant: "destructive",
    });

    // Auto-reconnect with exponential backoff
    if (autoReconnect && reconnectAttempts.current < maxReconnectAttempts) {
      const delay = Math.pow(2, reconnectAttempts.current) * 1000; // Exponential backoff
      setTimeout(() => {
        reconnectAttempts.current++;
        // Try to reconnect to the last device
        if (deviceRef.current) {
          reconnectToDevice(deviceRef.current.id);
        }
      }, delay);
    }
  }, [onConnectionChange, toast, autoReconnect]);

  const reconnectToDevice = useCallback(async (deviceId: string) => {
    try {
      // In a real implementation, you'd need to store the BluetoothDevice reference
      // For now, we'll just prompt the user to reconnect manually
      toast({
        title: "Reconnection Required",
        description: "Please manually reconnect your Bluetooth device",
      });
    } catch (error) {
      console.error('Reconnection failed:', error);
    }
  }, [toast]);

  const disconnect = useCallback(async () => {
    if (connectedDevice && characteristicRef.current) {
      try {
        await characteristicRef.current.stopNotifications();
        // Note: There's no direct way to disconnect GATT in Web Bluetooth API
        // The connection will be closed when the page is closed or device goes out of range
        
        setConnectedDevice(null);
        deviceRef.current = null;
        characteristicRef.current = null;
        onConnectionChange?.(false);
        
        toast({
          title: "Device Disconnected",
          description: "Successfully disconnected from Bluetooth device",
        });
      } catch (error: any) {
        console.error('Disconnection error:', error);
        toast({
          title: "Disconnection Failed",
          description: error.message,
          variant: "destructive",
        });
      }
    }
  }, [connectedDevice, onConnectionChange, toast]);

  return {
    isSupported,
    isScanning,
    connectedDevice,
    lastReading,
    error,
    scanForDevices,
    disconnect,
    reconnectToDevice,
  };
}

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { LucideIcon, TrendingUp, TrendingDown, Minus } from "lucide-react";

interface VitalsCardProps {
  title: string;
  value: string | number;
  unit: string;
  icon: LucideIcon;
  trend?: string;
  trendType?: "positive" | "negative" | "neutral";
  className?: string;
  "data-testid"?: string;
}

export function VitalsCard({
  title,
  value,
  unit,
  icon: Icon,
  trend,
  trendType = "neutral",
  className,
  "data-testid": dataTestId,
}: VitalsCardProps) {
  const getTrendIcon = () => {
    switch (trendType) {
      case "positive":
        return <TrendingUp className="w-3 h-3 text-green-500" />;
      case "negative":
        return <TrendingDown className="w-3 h-3 text-red-500" />;
      default:
        return <Minus className="w-3 h-3 text-muted-foreground" />;
    }
  };

  const getTrendColor = () => {
    switch (trendType) {
      case "positive":
        return "text-green-600";
      case "negative":
        return "text-red-600";
      default:
        return "text-muted-foreground";
    }
  };

  return (
    <Card 
      className="vital-card hover:shadow-lg transition-all duration-200 hover:-translate-y-1"
      data-testid={dataTestId}
    >
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h3 className="text-sm font-medium text-muted-foreground mb-2">
              {title}
            </h3>
            <div className="flex items-baseline space-x-1">
              <span className="text-3xl font-bold text-foreground">
                {value}
              </span>
              <span className="text-sm text-muted-foreground">
                {unit}
              </span>
            </div>
            {trend && (
              <div className={cn("flex items-center space-x-1 mt-2", getTrendColor())}>
                {getTrendIcon()}
                <span className="text-xs">
                  {trend}
                </span>
              </div>
            )}
          </div>
          <div className={cn("text-2xl", className)}>
            <Icon className="w-8 h-8" />
          </div>
        </div>
        
        {/* Progress indicator */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
            <span>Last 24h</span>
            <Badge variant="outline" className="text-xs">
              {trendType === "positive" ? "Normal" : trendType === "negative" ? "Alert" : "Stable"}
            </Badge>
          </div>
          <div className="h-2 bg-muted rounded overflow-hidden">
            <div 
              className={cn(
                "h-full transition-all duration-300",
                trendType === "positive" ? "bg-gradient-to-r from-green-500 to-green-400" :
                trendType === "negative" ? "bg-gradient-to-r from-red-500 to-red-400" :
                "bg-gradient-to-r from-primary to-accent"
              )}
              style={{ width: "75%" }}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

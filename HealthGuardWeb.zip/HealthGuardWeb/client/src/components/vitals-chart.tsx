import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { format, subDays, subWeeks, subMonths } from "date-fns";
import { Activity, Calendar, TrendingUp } from "lucide-react";

interface VitalsChartProps {
  dateRange?: { from: Date; to: Date } | null;
  vitalType?: string;
}

export function VitalsChart({ dateRange, vitalType }: VitalsChartProps) {
  const [selectedPeriod, setSelectedPeriod] = useState("7D");

  const periods = [
    { label: "7D", value: "7D", days: 7 },
    { label: "30D", value: "30D", days: 30 },
    { label: "3M", value: "3M", days: 90 },
  ];

  // Calculate date range based on period if not provided
  const calculatedDateRange = dateRange || {
    from: subDays(new Date(), periods.find(p => p.value === selectedPeriod)?.days || 7),
    to: new Date(),
  };

  // Fetch vitals data for chart
  const { data: vitals = [], isLoading } = useQuery({
    queryKey: ['/api/vitals', {
      type: vitalType,
      from: calculatedDateRange.from.toISOString(),
      to: calculatedDateRange.to.toISOString(),
    }],
    enabled: !!calculatedDateRange,
  });

  // Process data for chart
  const chartData = vitals
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .map(vital => {
      const timestamp = new Date(vital.timestamp);
      let dataPoint: any = {
        timestamp: timestamp.getTime(),
        date: format(timestamp, "MMM dd"),
        time: format(timestamp, "HH:mm"),
      };

      if (vital.vitalType === "heart_rate" && vital.value.heartRate) {
        dataPoint.heartRate = vital.value.heartRate;
      } else if (vital.vitalType === "blood_pressure" && vital.value.bloodPressure) {
        dataPoint.systolic = vital.value.bloodPressure.systolic;
        dataPoint.diastolic = vital.value.bloodPressure.diastolic;
      } else if (vital.vitalType === "spO2" && vital.value.spO2) {
        dataPoint.spO2 = vital.value.spO2;
      } else if (vital.vitalType === "sleep" && vital.value.sleep) {
        const { deep, light, rem } = vital.value.sleep.stages;
        dataPoint.totalSleep = (deep + light + rem) / 60; // Convert to hours
        dataPoint.deepSleep = deep / 60;
        dataPoint.lightSleep = light / 60;
        dataPoint.remSleep = rem / 60;
      }

      return dataPoint;
    })
    .filter(point => {
      // Filter out points that don't have the data we need
      if (vitalType === "heart_rate") return point.heartRate !== undefined;
      if (vitalType === "blood_pressure") return point.systolic !== undefined;
      if (vitalType === "spO2") return point.spO2 !== undefined;
      if (vitalType === "sleep") return point.totalSleep !== undefined;
      return true;
    });

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="text-sm font-medium text-foreground">
            {format(new Date(data.timestamp), "MMM dd, yyyy 'at' HH:mm")}
          </p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value}
              {entry.dataKey === "heartRate" && " bpm"}
              {(entry.dataKey === "systolic" || entry.dataKey === "diastolic") && " mmHg"}
              {entry.dataKey === "spO2" && "%"}
              {entry.dataKey.includes("Sleep") && "h"}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const renderChart = () => {
    if (isLoading) {
      return (
        <div className="h-64 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-sm text-muted-foreground">Loading chart data...</p>
          </div>
        </div>
      );
    }

    if (chartData.length === 0) {
      return (
        <div className="h-64 flex items-center justify-center">
          <div className="text-center">
            <Activity className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-sm text-muted-foreground">No data available for the selected period</p>
            <p className="text-xs text-muted-foreground mt-1">
              Connect a device or add manual readings to see trends
            </p>
          </div>
        </div>
      );
    }

    return (
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
          <XAxis 
            dataKey="date" 
            tick={{ fontSize: 12 }}
            tickLine={false}
            axisLine={false}
          />
          <YAxis 
            tick={{ fontSize: 12 }}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend />
          
          {/* Heart Rate */}
          {vitalType === "heart_rate" && (
            <Line
              type="monotone"
              dataKey="heartRate"
              stroke="hsl(var(--chart-1))"
              strokeWidth={2}
              dot={{ fill: "hsl(var(--chart-1))", strokeWidth: 2, r: 4 }}
              name="Heart Rate"
            />
          )}
          
          {/* Blood Pressure */}
          {vitalType === "blood_pressure" && (
            <>
              <Line
                type="monotone"
                dataKey="systolic"
                stroke="hsl(var(--chart-1))"
                strokeWidth={2}
                dot={{ fill: "hsl(var(--chart-1))", strokeWidth: 2, r: 4 }}
                name="Systolic"
              />
              <Line
                type="monotone"
                dataKey="diastolic"
                stroke="hsl(var(--chart-2))"
                strokeWidth={2}
                dot={{ fill: "hsl(var(--chart-2))", strokeWidth: 2, r: 4 }}
                name="Diastolic"
              />
            </>
          )}
          
          {/* SpO2 */}
          {vitalType === "spO2" && (
            <Line
              type="monotone"
              dataKey="spO2"
              stroke="hsl(var(--chart-3))"
              strokeWidth={2}
              dot={{ fill: "hsl(var(--chart-3))", strokeWidth: 2, r: 4 }}
              name="Blood Oxygen"
            />
          )}
          
          {/* Sleep */}
          {vitalType === "sleep" && (
            <>
              <Line
                type="monotone"
                dataKey="totalSleep"
                stroke="hsl(var(--chart-1))"
                strokeWidth={2}
                dot={{ fill: "hsl(var(--chart-1))", strokeWidth: 2, r: 4 }}
                name="Total Sleep"
              />
              <Line
                type="monotone"
                dataKey="deepSleep"
                stroke="hsl(var(--chart-4))"
                strokeWidth={1}
                dot={{ fill: "hsl(var(--chart-4))", strokeWidth: 1, r: 2 }}
                name="Deep Sleep"
              />
              <Line
                type="monotone"
                dataKey="remSleep"
                stroke="hsl(var(--chart-5))"
                strokeWidth={1}
                dot={{ fill: "hsl(var(--chart-5))", strokeWidth: 1, r: 2 }}
                name="REM Sleep"
              />
            </>
          )}
          
          {/* All vitals combined view */}
          {!vitalType && (
            <>
              <Line
                type="monotone"
                dataKey="heartRate"
                stroke="hsl(var(--chart-1))"
                strokeWidth={2}
                dot={false}
                name="Heart Rate"
              />
              <Line
                type="monotone"
                dataKey="spO2"
                stroke="hsl(var(--chart-3))"
                strokeWidth={2}
                dot={false}
                name="SpO2"
              />
            </>
          )}
        </LineChart>
      </ResponsiveContainer>
    );
  };

  return (
    <Card className="chart-container">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5" />
            <span>Vital Trends</span>
          </CardTitle>
          {!dateRange && (
            <div className="flex items-center space-x-2">
              {periods.map((period) => (
                <Button
                  key={period.value}
                  variant={selectedPeriod === period.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedPeriod(period.value)}
                  data-testid={`button-period-${period.value}`}
                >
                  {period.label}
                </Button>
              ))}
            </div>
          )}
        </div>
        
        {vitalType && (
          <div className="flex items-center space-x-2">
            <Badge variant="outline">
              {vitalType === "heart_rate" ? "Heart Rate" :
               vitalType === "blood_pressure" ? "Blood Pressure" :
               vitalType === "spO2" ? "Blood Oxygen" :
               vitalType === "sleep" ? "Sleep" : "All Vitals"}
            </Badge>
            <span className="text-sm text-muted-foreground">
              {chartData.length} data points
            </span>
          </div>
        )}
      </CardHeader>
      <CardContent>
        {renderChart()}
      </CardContent>
    </Card>
  );
}

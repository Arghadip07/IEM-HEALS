import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useWebBluetooth } from "@/hooks/use-web-bluetooth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest, queryClient } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, 
  Bluetooth, 
  Smartphone, 
  AlertCircle, 
  CheckCircle, 
  RefreshCw,
  Settings,
  Trash2
} from "lucide-react";

export function DeviceManager() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Web Bluetooth hook
  const {
    isSupported: bluetoothSupported,
    isScanning,
    connectedDevice,
    error: bluetoothError,
    scanForDevices,
    disconnect: disconnectBluetooth,
  } = useWebBluetooth({
    onVitalReading: (reading) => {
      toast({
        title: "New Vital Reading",
        description: `Heart Rate: ${reading.heartRate || 'N/A'} bpm`,
      });
    },
    onConnectionChange: (connected, device) => {
      if (connected && device) {
        toast({
          title: "Device Connected",
          description: `Successfully connected to ${device.name}`,
        });
        queryClient.invalidateQueries({ queryKey: ['/api/devices'] });
        setIsDialogOpen(false);
      }
    },
  });

  // Fetch devices
  const { data: devices = [] } = useQuery({
    queryKey: ['/api/devices'],
  });

  // Google Fit auth mutation
  const googleFitAuthMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('GET', '/api/auth/googlefit');
      const data = await response.json();
      return data.authUrl;
    },
    onSuccess: (authUrl) => {
      window.location.href = authUrl;
    },
    onError: (error: any) => {
      toast({
        title: "Google Fit Connection Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const googleFitDevice = devices.find(d => d.deviceType === 'google_fit');

  return (
    <>
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" data-testid="button-add-device">
            <Plus className="w-4 h-4 mr-2" />
            Add Device
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Connect Health Devices</DialogTitle>
            <DialogDescription>
              Connect your health monitoring devices to start tracking your vitals
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            
            {/* Google Fit */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i className="fab fa-google text-blue-600 text-sm"></i>
                  </div>
                  <span>Google Fit</span>
                  {googleFitDevice && (
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Connected
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {googleFitDevice ? (
                  <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <div>
                        <p className="font-medium text-green-800">Connected</p>
                        <p className="text-sm text-green-600">
                          Importing heart rate, sleep, and activity data
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      Import your health data from Google Fit including heart rate, 
                      blood pressure, and sleep information.
                    </p>
                    <Button 
                      onClick={() => googleFitAuthMutation.mutate()}
                      disabled={googleFitAuthMutation.isPending}
                      data-testid="button-connect-googlefit-modal"
                    >
                      <Smartphone className="w-4 h-4 mr-2" />
                      {googleFitAuthMutation.isPending ? 'Connecting...' : 'Connect Google Fit'}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Web Bluetooth */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center space-x-2 text-lg">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Bluetooth className="w-5 h-5 text-purple-600" />
                  </div>
                  <span>Bluetooth Devices</span>
                  {connectedDevice && (
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Connected
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                
                {/* Browser Support Warning */}
                {!bluetoothSupported && (
                  <Alert variant="destructive">
                    <AlertCircle className="w-4 h-4" />
                    <AlertDescription>
                      Web Bluetooth is only supported in Chrome and Edge browsers.
                    </AlertDescription>
                  </Alert>
                )}

                {bluetoothSupported && bluetoothError && (
                  <Alert variant="destructive">
                    <AlertCircle className="w-4 h-4" />
                    <AlertDescription>{bluetoothError}</AlertDescription>
                  </Alert>
                )}

                {/* Connected Device */}
                {connectedDevice && (
                  <div className="flex items-center justify-between p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Bluetooth className="w-5 h-5 text-purple-600" />
                      <div>
                        <p className="font-medium text-purple-800">{connectedDevice.name}</p>
                        <p className="text-sm text-purple-600">
                          {connectedDevice.services.join(', ')} • Active
                        </p>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={disconnectBluetooth}
                      data-testid="button-disconnect-bluetooth-modal"
                    >
                      Disconnect
                    </Button>
                  </div>
                )}

                {/* Scan Button */}
                {bluetoothSupported && (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      Scan for nearby Bluetooth heart rate monitors and blood pressure devices.
                    </p>
                    <Button 
                      onClick={scanForDevices}
                      disabled={isScanning}
                      variant={connectedDevice ? "outline" : "default"}
                      data-testid="button-scan-bluetooth-modal"
                    >
                      {isScanning ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Scanning...
                        </>
                      ) : (
                        <>
                          <Bluetooth className="w-4 h-4 mr-2" />
                          {connectedDevice ? 'Scan for More' : 'Scan for Devices'}
                        </>
                      )}
                    </Button>
                  </div>
                )}

                {/* Supported Devices Info */}
                <div className="p-3 bg-muted rounded-lg">
                  <h4 className="font-medium text-foreground mb-2">Supported Devices</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Bluetooth Heart Rate monitors (Polar, Garmin, etc.)</li>
                    <li>• Bluetooth Blood Pressure monitors</li>
                    <li>• Fitness trackers with BLE support</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Manual Entry Note */}
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-start space-x-2">
                <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                <div className="text-sm text-blue-800">
                  <p className="font-medium">Manual Entry</p>
                  <p>
                    You can also manually enter vital signs from your profile page 
                    if you don't have compatible devices.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

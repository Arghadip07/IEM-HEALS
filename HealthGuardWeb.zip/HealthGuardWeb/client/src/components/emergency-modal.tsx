import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { 
  Dialog, 
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { apiRequest } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { 
  AlertTriangle, 
  Phone, 
  CheckCircle, 
  Clock, 
  MapPin, 
  Heart,
  Mail,
  MessageSquare
} from "lucide-react";

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  emergencyData?: {
    vitals?: any;
    aiAnalysis?: any;
    emergencyResponse?: any;
  };
}

export function EmergencyModal({ isOpen, onClose, emergencyData }: EmergencyModalProps) {
  const { toast } = useToast();
  const [isResolving, setIsResolving] = useState(false);

  const resolveEmergencyMutation = useMutation({
    mutationFn: async (eventId: string) => {
      const response = await apiRequest('POST', `/api/emergency/${eventId}/resolve`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Emergency Resolved",
        description: "The emergency event has been marked as resolved.",
      });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Resolution Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleResolveEmergency = () => {
    if (emergencyData?.emergencyResponse?.emergencyEventId) {
      setIsResolving(true);
      resolveEmergencyMutation.mutate(emergencyData.emergencyResponse.emergencyEventId);
    }
  };

  const handleCallEmergency = () => {
    // In a real implementation, this would initiate a call
    window.open("tel:911", "_self");
  };

  const mockEmergencyResponse = {
    actionsTaken: {
      browserAlert: { sent: true, timestamp: new Date().toISOString() },
      emailsSent: [
        { contact: "Jane Doe (jane@example.com)", status: "sent", timestamp: new Date().toISOString() },
        { contact: "Dr. Smith (doctor@clinic.com)", status: "sent", timestamp: new Date().toISOString() }
      ],
      smsSent: [
        { contact: "Jane Doe (+1-555-123-4567)", status: "sent", timestamp: new Date().toISOString() }
      ],
      hospitalsFound: [
        { name: "City General Hospital", distance: 2.3, address: "123 Medical Center Dr" },
        { name: "St. Mary's Medical Center", distance: 3.7, address: "456 Healthcare Blvd" },
        { name: "Regional Emergency Hospital", distance: 4.1, address: "789 Emergency Way" }
      ]
    }
  };

  const responseData = emergencyData?.emergencyResponse || mockEmergencyResponse;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="emergency-modal">
        <DialogHeader className="text-center">
          <div className="w-20 h-20 bg-destructive rounded-full flex items-center justify-center mx-auto mb-4 emergency-pulse">
            <AlertTriangle className="w-10 h-10 text-destructive-foreground" />
          </div>
          <DialogTitle className="text-2xl text-destructive">
            Emergency Alert Triggered
          </DialogTitle>
          <DialogDescription>
            Emergency contacts have been notified and emergency services located
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          
          {/* Alert Summary */}
          {emergencyData?.aiAnalysis && (
            <Card className="border-destructive">
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <Heart className="w-5 h-5 text-destructive mt-1" />
                  <div>
                    <h3 className="font-semibold text-foreground">Health Alert</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {emergencyData.aiAnalysis.explanation}
                    </p>
                    <div className="flex items-center space-x-4 mt-2">
                      <Badge variant="destructive">
                        Risk Score: {emergencyData.aiAnalysis.riskScore}/100
                      </Badge>
                      <Badge variant="outline">
                        {emergencyData.aiAnalysis.recommendedAction.replace("_", " ").toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Vital Signs */}
          {emergencyData?.vitals && (
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold text-foreground mb-3">Latest Vital Signs</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  {emergencyData.vitals.heartRate && (
                    <div>
                      <span className="text-muted-foreground">Heart Rate:</span>
                      <span className="ml-2 font-medium text-foreground">
                        {emergencyData.vitals.heartRate} bpm
                      </span>
                    </div>
                  )}
                  {emergencyData.vitals.bloodPressure && (
                    <div>
                      <span className="text-muted-foreground">Blood Pressure:</span>
                      <span className="ml-2 font-medium text-foreground">
                        {emergencyData.vitals.bloodPressure.systolic}/{emergencyData.vitals.bloodPressure.diastolic} mmHg
                      </span>
                    </div>
                  )}
                  {emergencyData.vitals.spO2 && (
                    <div>
                      <span className="text-muted-foreground">Blood Oxygen:</span>
                      <span className="ml-2 font-medium text-foreground">
                        {emergencyData.vitals.spO2}%
                      </span>
                    </div>
                  )}
                  <div>
                    <span className="text-muted-foreground">Timestamp:</span>
                    <span className="ml-2 font-medium text-foreground">
                      {new Date().toLocaleString()}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Actions Taken */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold text-foreground mb-3">Actions Taken</h3>
              <div className="space-y-3">
                
                {/* Browser Alert */}
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className="text-sm text-foreground">Emergency alert displayed</span>
                  <Badge variant="outline" className="text-xs">
                    {new Date(responseData.actionsTaken.browserAlert.timestamp).toLocaleTimeString()}
                  </Badge>
                </div>

                {/* Email Notifications */}
                {responseData.actionsTaken.emailsSent.map((email, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    {email.status === "sent" ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-red-500" />
                    )}
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm text-foreground">
                      Email sent to {email.contact}
                    </span>
                    <Badge variant={email.status === "sent" ? "default" : "destructive"} className="text-xs">
                      {email.status}
                    </Badge>
                  </div>
                ))}

                {/* SMS Notifications */}
                {responseData.actionsTaken.smsSent.map((sms, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    {sms.status === "sent" ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-red-500" />
                    )}
                    <MessageSquare className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm text-foreground">
                      SMS sent to {sms.contact}
                    </span>
                    <Badge variant={sms.status === "sent" ? "default" : "destructive"} className="text-xs">
                      {sms.status}
                    </Badge>
                  </div>
                ))}

                {/* Location Shared */}
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-foreground">Current location shared</span>
                </div>

              </div>
            </CardContent>
          </Card>

          {/* Nearest Hospitals */}
          {responseData.actionsTaken.hospitalsFound.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold text-foreground mb-3">Nearest Hospitals</h3>
                <div className="space-y-3">
                  {responseData.actionsTaken.hospitalsFound.slice(0, 3).map((hospital, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div>
                        <p className="font-medium text-foreground">{hospital.name}</p>
                        <p className="text-sm text-muted-foreground">{hospital.address}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-foreground">
                          {hospital.distance} miles
                        </p>
                        <Badge variant="outline" className="text-xs">
                          Emergency Room
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="flex space-x-3">
            <Button 
              className="flex-1 bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleCallEmergency}
              data-testid="button-call-911"
            >
              <Phone className="w-4 h-4 mr-2" />
              Call 911
            </Button>
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={handleResolveEmergency}
              disabled={isResolving}
              data-testid="button-im-ok"
            >
              {isResolving ? (
                <>
                  <Clock className="w-4 h-4 mr-2" />
                  Resolving...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  I'm OK
                </>
              )}
            </Button>
          </div>

          {/* Important Notice */}
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-start space-x-2">
              <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
              <div className="text-sm text-yellow-800">
                <p className="font-medium">Important Notice</p>
                <p>
                  This is an automated emergency alert from HealthGuard. If this is a life-threatening emergency, 
                  please call 911 immediately or go to the nearest emergency room.
                </p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

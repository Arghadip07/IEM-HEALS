import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { 
  Heart, 
  LayoutDashboard, 
  Smartphone, 
  History, 
  User, 
  Settings, 
  LogOut, 
  AlertTriangle,
  ChevronDown,
  Menu,
  Bell
} from "lucide-react";
import { apiRequest } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Devices', href: '/devices', icon: Smartphone },
  { name: 'History', href: '/history', icon: History },
  { name: 'Profile', href: '/profile', icon: User },
];

export function Navigation() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleEmergencyTrigger = async () => {
    try {
      await apiRequest('POST', '/api/emergency/trigger');
      toast({
        title: "Emergency Alert Triggered",
        description: "Emergency contacts have been notified.",
        variant: "destructive",
      });
    } catch (error) {
      console.error('Emergency trigger failed:', error);
      toast({
        title: "Emergency Alert Failed",
        description: "Unable to trigger emergency alert. Please call 911 directly.",
        variant: "destructive",
      });
    }
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const isCurrentPage = (href: string) => {
    return location === href || (href === '/dashboard' && location === '/');
  };

  return (
    <nav className="bg-card border-b border-border shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          
          {/* Logo and Brand */}
          <div className="flex items-center space-x-4">
            <div className="flex-shrink-0">
              <button 
                onClick={() => setLocation('/dashboard')}
                className="flex items-center space-x-2 hover:opacity-80 transition-opacity"
                data-testid="logo-healthguard"
              >
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Heart className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold text-foreground">HealthGuard</span>
              </button>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.name}
                      onClick={() => setLocation(item.href)}
                      className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        isCurrentPage(item.href)
                          ? 'bg-primary text-primary-foreground'
                          : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                      }`}
                      data-testid={`nav-${item.name.toLowerCase()}`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{item.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right side items */}
          <div className="flex items-center space-x-4">
            
            {/* Emergency Button */}
            <Button 
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90 emergency-pulse hidden sm:flex"
              onClick={handleEmergencyTrigger}
              data-testid="button-emergency-nav"
            >
              <AlertTriangle className="w-4 h-4 mr-2" />
              EMERGENCY
            </Button>

            {/* Notifications */}
            <Button variant="ghost" size="sm" data-testid="button-notifications">
              <Bell className="w-5 h-5" />
            </Button>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  className="flex items-center space-x-2"
                  data-testid="button-user-menu"
                >
                  <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center">
                    <User className="w-4 h-4" />
                  </div>
                  <div className="hidden sm:block text-left">
                    <p className="text-sm font-medium text-foreground">
                      {user?.email?.split('@')[0] || 'User'}
                    </p>
                    <div className="flex items-center space-x-1">
                      {user?.emailVerified ? (
                        <Badge variant="secondary" className="text-xs bg-green-100 text-green-800">
                          Verified
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="text-xs bg-yellow-100 text-yellow-800">
                          Unverified
                        </Badge>
                      )}
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 py-1.5">
                  <p className="text-sm font-medium text-foreground">{user?.email}</p>
                  <p className="text-xs text-muted-foreground">
                    {user?.emailVerified ? 'Email verified' : 'Email not verified'}
                  </p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setLocation('/profile')} data-testid="menu-profile">
                  <User className="w-4 h-4 mr-2" />
                  Profile & Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLocation('/devices')} data-testid="menu-devices">
                  <Smartphone className="w-4 h-4 mr-2" />
                  Device Management
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLocation('/history')} data-testid="menu-history">
                  <History className="w-4 h-4 mr-2" />
                  Health History
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={handleLogout}
                  className="text-destructive focus:text-destructive"
                  data-testid="menu-logout"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mobile Menu */}
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden" data-testid="button-mobile-menu">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                <div className="flex flex-col space-y-4 mt-6">
                  
                  {/* User Info */}
                  <div className="flex items-center space-x-3 p-4 bg-accent rounded-lg">
                    <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                      <User className="w-5 h-5 text-primary-foreground" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{user?.email}</p>
                      {user?.emailVerified ? (
                        <Badge variant="secondary" className="text-xs bg-green-100 text-green-800">
                          Verified
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="text-xs bg-yellow-100 text-yellow-800">
                          Unverified
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Emergency Button */}
                  <Button 
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90 emergency-pulse"
                    onClick={() => {
                      handleEmergencyTrigger();
                      setIsMobileMenuOpen(false);
                    }}
                    data-testid="button-emergency-mobile"
                  >
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    EMERGENCY
                  </Button>

                  {/* Navigation Items */}
                  <div className="space-y-2">
                    {navigation.map((item) => {
                      const Icon = item.icon;
                      return (
                        <button
                          key={item.name}
                          onClick={() => {
                            setLocation(item.href);
                            setIsMobileMenuOpen(false);
                          }}
                          className={`w-full flex items-center space-x-3 px-4 py-3 rounded-md text-sm font-medium transition-colors ${
                            isCurrentPage(item.href)
                              ? 'bg-primary text-primary-foreground'
                              : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                          }`}
                          data-testid={`mobile-nav-${item.name.toLowerCase()}`}
                        >
                          <Icon className="w-5 h-5" />
                          <span>{item.name}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Logout */}
                  <div className="pt-4 border-t">
                    <button
                      onClick={() => {
                        handleLogout();
                        setIsMobileMenuOpen(false);
                      }}
                      className="w-full flex items-center space-x-3 px-4 py-3 rounded-md text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors"
                      data-testid="mobile-logout"
                    >
                      <LogOut className="w-5 h-5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
